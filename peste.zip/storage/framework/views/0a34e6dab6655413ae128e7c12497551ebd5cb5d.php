<?php $__env->startComponent('mail::message'); ?>
<h1 style="text-align: right">
    RppcShop.ir
</h1>
<h4 style="text-align: right">
    <?php echo e($order->getOrderId()); ?>

    سفارش

</h4>
<h4 style="text-align: right">
    در تاریخ
    <?php echo e($order->Created_at); ?>

</h4>
<h4 style="text-align: right">
    برای کاربر
    <?php echo e($user->name . ' ' . $user->last_name); ?>

</h4>
<h4 style="text-align: right">
    با شماره همراه
    <?php echo e($user->phone); ?>

</h4>
<h4 style="text-align: right ; color: green">
    ثبت شد
</h4>
<h4 style="text-align: right ; color: blue">
    وضعیت سفارش
    <?php echo e($order->getStep()); ?>

</h4>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\peste\resources\views/emails/order/created.blade.php ENDPATH**/ ?>