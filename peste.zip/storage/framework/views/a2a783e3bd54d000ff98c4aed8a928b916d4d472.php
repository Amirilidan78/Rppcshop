<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <meta property=”article:tag” content="<?php echo e($article['tag']); ?>" />
    <meta property=”article:section” content="<?php echo e($article['section']); ?>" />
    <meta property=”article:published_time” content="<?php echo e($article['published_time']); ?>" />
    <meta property=”article:modified_time” content="<?php echo e($article['modified_time']); ?>" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="container mt-5 pt-5">

        <!--Grid row-->
        <div class="row pt-3">

            <!--Grid column-->
            <div class="col-md-6 mb-4">

                <!--Section: Intro-->
                <section>

                    <!-- Featured image -->
                    <div class="view overlay rounded z-depth-1-half mb-4" >
                        <img src="<?php echo e(( $post->image ) ? asset("{$post->image}") : asset("images/5.jpg")); ?>" class="img-fluid " alt="<?php echo e($post->title); ?>">
                        <a href="">
                            <div class="mask rgba-white-slight waves-effect waves-light"></div>
                        </a>
                    </div>
                    <!-- Featured image -->

                </section>
                <!--Section: Intro-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-6 mb-4 px-5">

                <!--Section: Intro-->
                <section>
                    <!-- Post data -->
                    <div class="post-data d-flex justify-content-between my-4 mb-2">

                        <h1 class="ml-1 h3 black-text">
                            <?php echo $post->title; ?>

                        </h1>
                        <!-- Author -->

                    </div>
                    <!-- Post data -->

                </section>
                <!--Section: Intro-->

                <hr>

                <!-- Text -->
                <section class="text-justify">
                    <p>
                        <?php echo $post->text; ?>

                    </p>
                </section>
                <!-- Text -->


            </div>
            <!--Grid column-->


        </div>
        <!--Grid row-->

        <div class="row">
            <div class="col-12" style="height: 150px"></div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.layout.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/blog/post.blade.php ENDPATH**/ ?>