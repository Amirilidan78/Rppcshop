<tr>
<td class="header">
<a href="http://rppcshop.ir/" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://www.rppcshop.ir/img/logo.PNG" class="logo" alt="Laravel Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\wamp64\www\peste\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>