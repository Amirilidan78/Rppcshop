<?php $__env->startComponent('mail::message'); ?>

<h1 style="text-align: right">
    RppcShop.ir
</h1>
<h4 style="text-align: right">
    ورود ادمین
    <?php echo e($name); ?>

</h4>
<h4 style="text-align: right">
    در تاریخ
    <?php echo e($date); ?>

</h4>
<h4 style="text-align: right">
    ip :
    <?php echo e($ip); ?>

</h4>





<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\peste\resources\views/emails/user-loggedin.blade.php ENDPATH**/ ?>