<div class="col-lg-3">
    <div class="card card-cascade wider">
        <!-- Card content -->
        <div class="card-body card-body-cascade text-center">

            <h5 class="text-center text-black-50 mb-4 animated fadeInDown ">حساب کاربری شما</h5>


            <div class="card py-3 px-2 my-2" >
                <a href="<?php echo e(route('user.dashboard')); ?>" class="animated fadeInDown ">
                    <i class="fas fa-user-alt mr-2 text-primary"></i>
                    <span class="text-black-50">پروفایل</span>
                    <?php if(request()->routeIs('user.dashboard')): ?>
                        <img src="<?php echo e(asset('images/IconSecondary.png')); ?>" style="width: 25px ; height: 25px" class="animated  flipInY infinite" alt="">
                    <?php endif; ?>
                </a>
            </div>

    
    
    
    
    
    
    
    
    

            <div class="card py-3 px-2 my-2" >
                <a href="<?php echo e(route('user.orders')); ?>" class="animated fadeInDown ">
                    <i class="far fa-file-alt mr-2 text-success"></i>
                    <span class="text-black-50">سفارش ها</span>
                    <?php if(request()->routeIs('user.orders')): ?>
                        <img src="<?php echo e(asset('images/IconSecondary.png')); ?>" style="width: 25px ; height: 25px" class="animated  flipInY infinite" alt="">
                    <?php endif; ?>
                </a>
            </div>

            <div  class="card py-3 px-2 my-2">
                <a href="<?php echo e(route('user.comments')); ?>" class="animated fadeInDown ">
                    <i class="fas fa-pen mr-2 text-secondary"></i>
                    <span class="text-black-50 text">دیدگاه ها</span>
                    <?php if(request()->routeIs('user.comments')): ?>
                        <img src="<?php echo e(asset('images/IconSecondary.png')); ?>" style="width: 25px ; height: 25px" class="animated  flipInY infinite" alt="">
                    <?php endif; ?>
                </a>
            </div>

            <div class="card py-3 px-2 my-2" >
                <a href="<?php echo e(route('user.logout')); ?>" class="animated fadeInDown ">
                    <i class="fas fa-door-open mr-2 text-danger"></i>
                    <span class="text-black-50">خروج</span>
                </a>
            </div>

        </div>
        <!-- Card content -->

    </div>
</div>
<?php /**PATH C:\wamp64\www\peste\resources\views/home/user/components/nav.blade.php ENDPATH**/ ?>