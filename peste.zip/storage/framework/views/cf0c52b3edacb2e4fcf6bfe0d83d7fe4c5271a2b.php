<?php ($array = mb_str_split(strrev($price),3)); ?>
<?php ($count = count($array)); ?>

<?php if($count == 1): ?>
    <?php echo e(strrev($array[0])); ?>

<?php elseif($count == 2): ?>
    <?php echo e(strrev($array[0].','.$array[1])); ?>

<?php elseif($count == 3): ?>
    <?php echo e(strrev($array[0].','.$array[1].','.$array[2])); ?>

<?php elseif($count == 4): ?>
    <?php echo e(strrev($array[0].','.$array[1].','.$array[2].','.$array[3])); ?>

<?php endif; ?>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/price.blade.php ENDPATH**/ ?>