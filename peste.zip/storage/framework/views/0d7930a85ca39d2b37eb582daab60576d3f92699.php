<!-- DataTables CSS -->
<link href="<?php echo e(asset('Home/css/addons/datatables.min.css')); ?>" rel="stylesheet">
<!-- DataTables JS -->
<script src="<?php echo e(asset('Home/js/addons/datatables.js')); ?>" type="text/javascript"></script>

<!-- DataTables Select CSS -->
<link href="<?php echo e(asset('Home/css/addons/datatables-select.min.css')); ?>" rel="stylesheet">
<!-- DataTables Select JS -->
<script src="<?php echo e(asset('Home/js/addons/datatables-select.js')); ?>" type="text/javascript"></script>

<style>
    tr,td{
        text-align: center;
    }
</style>

<script>
    $(document).ready(function () {
        $('#dtBasicExample').DataTable();
        $('.dataTables_length').addClass('bs-select');
    });
</script>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/db-table-config.blade.php ENDPATH**/ ?>