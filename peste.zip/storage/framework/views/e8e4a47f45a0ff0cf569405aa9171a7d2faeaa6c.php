<div class="col-lg-<?php echo e($size ?? '3'); ?> product_cols" onclick="goToProductPage('<?php echo e($product->english_name); ?>')" style="cursor: pointer">
        <div class="card hoverable mb-4" >
            <div class="card-body" >
                <div class="row align-items-center">
                    <div class="col-6 px-0">
                        <a>
                            <img src="<?php echo e(asset($product->pic1 ?? 'images/placeHolder.jpg')); ?>" class="img-fluid" alt="<?php echo e($product->Name); ?>" title="<?php echo e($product->Name); ?>پسته ">
                        </a>
                    </div>
                    <div class="col-6">

                       <h2 class="h6 py-0 my-0">
                            <a class="py-0">
                                <strong>
                                    <?php echo e($product->Name); ?>

                                </strong>
                            </a>
                       </h2>
                        <h6 class="d-none"><b> پسته <?php echo e($product->Name); ?> </b></h6>
                        <h3 class="d-none"><b> پسته <?php echo e($product->Name); ?> </b></h3>
                        <br>

                        <h3 class="h6 py-0 my-0">
                            <a class="py-0">
                                <?php echo e($product->group->name); ?>

                                <?php echo e($product->getPersianSalty()); ?>

                            </a>
                        </h3>

                        <br>


                        <span class="h6-responsive font-weight-bold dark-grey-text mt-2">
                            <?php if($product->price_off): ?>

                                <strong class="text-success">
                                    <span  class="Bkoodak">
                                             <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price_off]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </span>
                                    تومان
                                </strong>

                                <span class="grey-text">
                                    </br>
                                <small>
                              <s class="Bkoodak"> <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </s>
                            </small>

                        <?php else: ?>
                            <strong class="text-success">
                                <span  class="Bkoodak">
                                         <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </span>
                                تومان
                            </strong>

                                    </br>
                                    </br>


                                    <?php endif; ?>

                        </span>
                        </span>

                    </div>
                </div>
            </div>
        </div>
</div>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/dashboardProduct.blade.php ENDPATH**/ ?>