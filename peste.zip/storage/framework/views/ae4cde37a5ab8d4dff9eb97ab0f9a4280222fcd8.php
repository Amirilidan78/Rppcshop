<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>- پسته -</title>


    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(url('awesome/css/all.css')); ?>">


    
    <link href="<?php echo e(asset('home/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('home/css/mdb.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('home/font/bkoodak/Bkoodak.css')); ?>" rel="stylesheet">

    <script type="text/javascript" src="<?php echo e(asset('home/js/jquery-3.4.1.min.js')); ?>"></script>




    <style>

        .Bkoodak{
            font-family: "B Koodak" !important;
            /*font-size: 20px;*/
        }

        .collapsible-header{
            font-size: 15px !important;
            margin-top: 4px !important;
            margin-bottom: 4px !important;
        }


        .white-skin{
            background:  white;
        }

        .md-outline.select-wrapper+label {
            top: .6em !important;
            z-index: 2 !important;
        }

        * {direction: rtl;}
        div{
            text-align: right
        }

        @font-face {
            font-family: "IRANSansDN";
            src: url(<?php echo e(url('home/font/iransansdn.ttf')); ?>) format('truetype');
        }

        div,b,h1,h2,h3,h4,h5,h6,a,span,p{
            font-family: "IRANSansDN" !important;
        }


    </style>

    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="coworking-page">

<!-- Main navigation -->
<header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg scrolling-navbar navbar-light z-depth-0 fixed-top white ml-md-4 mr-md-3" style="direction: ltr">
        <a class="navbar-brand text-info" >
            <strong>پنل <br><span class="font-weight-bold ">مدیریت</span></strong>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
                aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
            <ul class="navbar-nav ml-auto text-uppercase smooth-scroll">
                <li class="nav-item">
                    <a class="nav-link <?php if(!request()->routeIs('admin.dashboard')): ?> heather-color <?php endif; ?>"  href="<?php echo e(route('admin.dashboard')); ?> " data-offset="100">
                        <i class="fas fa-home"></i>
                        <strong>پیشخوان</strong>
                    </a>
                </li>




                <?php if($access_products): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(!request()->routeIs('admin.products')): ?> heather-color <?php endif; ?>" href="<?php echo e(route('admin.products')); ?>" data-offset="100">
                            <i class="fas fa-box"></i>
                            <strong>محصولات</strong>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($access_orders): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(!request()->routeIs('admin.orders')): ?> heather-color <?php endif; ?>" href="<?php echo e(route('admin.orders')); ?>" data-offset="100">
                            <i class="fas fa-clipboard-list"></i>
                            <strong>سفارش ها</strong>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($access_users): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(!request()->routeIs('admin.users')): ?> heather-color <?php endif; ?>" href="<?php echo e(route('admin.users')); ?>" data-offset="100">
                            <i class="fas fa-users"></i>
                            <strong>کاربران</strong>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($access_posts): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(!request()->routeIs('admin.blog')): ?> heather-color <?php endif; ?>" href="<?php echo e(route('admin.blog')); ?>" data-offset="100">
                            <i class="fas fa-chart-line"></i>
                            <strong>وبلاگ</strong>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($access_tags): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if(!request()->routeIs('admin.tags')): ?> heather-color <?php endif; ?>" href="<?php echo e(route('admin.tags')); ?>" data-offset="100">
                            <i class="fas fa-tags"></i>
                            <strong>تگ ها</strong>
                        </a>
                    </li>
                <?php endif; ?>


                <li class="nav-item">
                    <a class="nav-link heather-color" href="<?php echo e(url('/logout')); ?>" data-offset="100">
                        <i class="fas fa-door-open"></i>
                        <strong>خروج</strong>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- Navbar -->

    <?php echo $__env->yieldContent('intro'); ?>


</header>
<!-- Main navigation -->

<!-- Main layout -->
<main>

    <div class="container-fluid">

       <div class="row">
           <div class="col-12 pt-5 mt-5"></div>
       </div>

        <?php echo $__env->yieldContent('body'); ?>

        <div class="row">
            <div class="col-12 pt-5 mt-5"></div>
        </div>

    </div>

</main>
<!-- Main layout -->

<!-- Footer -->

















































<!-- Footer -->



<script type="text/javascript" src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('home/js/bootstrap.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('home/js/mdb.js')); ?>"></script>


<?php echo $__env->yieldContent('script'); ?>
<script>
    <?php if(session('adminAlert')): ?>
        <?php if(session('adminAlert')[0] == false): ?>
        toastr.error("<?php echo e(session('adminAlert')[1]); ?>",'خطا') ;
        <?php elseif(session('adminAlert')[0] == true): ?>
        toastr.success("<?php echo e(session('adminAlert')[1]); ?>",'اطلاعیه') ;
        <?php else: ?>
        toastr.info("<?php echo e(session('adminAlert')[1]); ?>",'اطلاعیه') ;
        <?php endif; ?>
    <?php endif; ?>
</script>

</body>

</html>
<?php /**PATH C:\wamp64\www\peste\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>