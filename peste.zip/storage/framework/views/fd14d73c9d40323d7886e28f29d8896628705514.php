<?php $__env->startSection('style'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>


    <div class="row justify-content-center mt-5">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">
                        سفارش
                        <?php echo e($order->getOrderId()); ?>

                    </h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <div class="card px-3 py-3 my-4">
                        <div class="row">


                            <div class="col-lg-12 text-center py-3">
                                <span>وضعیت سفارش</span>
                                :
                                <span class="h6 text-success"><?php echo e($order->getStep()); ?></span>
                            </div>


                        </div>
                    </div>

                    <div class="card px-3 py-3 my-4">
                        <div class="row">


                            <div class="col-lg-6 text-center py-3">
                                <span>خریدار</span>
                                :
                                <span class="h6"><?php echo e($user->name.' '.$user->last_name); ?></span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شماره همراه</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($user->phone); ?></span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>استان</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($post->ostan); ?></span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شهر</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($post->city); ?></span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>کد پستی</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($post->post_code); ?></span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شماره ثابت</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($post->number); ?></span>
                            </div>


                            <div class="col-lg-12 text-center py-3">
                                <span>آدرس</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($post->address); ?></span>
                            </div>

                            <div class="col-lg-12 text-center py-3">
                                <span>نوع ارسال</span>
                                :
                                <span class=" Bkoodak h6 "><?php echo e($order->getSendType()); ?></span>
                            </div>


                        </div>
                    </div>

                    <?php if($factor): ?>
                        <div class="card px-3 py-3 mt-3">
                            <div class="row">
                                <div class="col-lg-12 text-center py-3">
                                    <span>سریال پرداخت</span>
                                    :
                                    <span class=" Bkoodak h6 "><?php echo e($factor->ref_id); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($order->post_rahgiri): ?>
                        <div class="card px-3 py-3 mt-3">
                            <div class="row">
                                <div class="col-lg-12 text-center py-3">
                                    <span> شماره رهگیری پست</span>
                                    :
                                    <span class=" Bkoodak h6 "><?php echo e($order->post_rahgiri); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive mt-3">
                        <table class="table product-table table-cart-v-1">

                        <!-- Table head -->
                        <thead>

                        <tr>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>شماره محصول</strong>
                            </th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>محصول</strong>
                            </th>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>تعداد</strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت کل
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                        </tr>

                        </thead>
                        <!-- Table head -->

                        <!-- Table body -->
                        <tbody>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>


                                <td><span><?php echo e($product->product_id); ?></span></td>

                                <td> <h6 class="mt-3 animated fadeInDown"> <strong class=""><?php echo e($product->product->Name); ?></strong> </h6>  </td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span>
                                </td>

                                <td></td>

                                <td class=" animated fadeInDown"> <span class="Bkoodak"><?php echo e($product->count); ?></span>  </td>

                                <td></td>

                                <td > <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $product->total_price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span> </td>

                                <td></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <!-- Table body -->

                    </table>
                    </div>


                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>