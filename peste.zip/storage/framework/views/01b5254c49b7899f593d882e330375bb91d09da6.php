<table <?php if($id): ?> id="<?php echo e($id); ?>" <?php else: ?> id="dtBasicExample" <?php endif; ?> class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
    <thead>
        <tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th >
                    <?php echo e($item); ?>

                </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </thead>
    <tbody>

        <?php echo e($slot); ?>


    </tbody>
</table>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/dbTable.blade.php ENDPATH**/ ?>