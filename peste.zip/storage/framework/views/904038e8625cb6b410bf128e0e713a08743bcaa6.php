<?php $__env->startSection('style'); ?>
    <style>
        th,td{
            text-align: center ;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('home/css/addons-pro/stepper.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>




    <div class="container-fluid pt-5" <?php if( $is_login ): ?> style="display: none"  <?php endif; ?> >
        <section class="section  pb-5">


            <div class="row justify-content-around mt-5 pt-5">

                <div class="col-lg-4 my-5">
                    <!-- Central Modal Medium Success -->
                    <form  action="<?php echo e(route('loginUser')); ?>" method="post" id="formCart2Login"> <?php echo csrf_field(); ?>
                        <div class="card  animated fadeInDown" data-wow-delay="0.3s">
                            <div class="card-body">

                                <!--Header-->
                                <div class="form-header success-color">
                                    <h3>
                                        ورود
                                    </h3>
                                </div>

                                <!--Body-->
                                <div class="row justify-content-around">
                                    <div class="col-lg-8 col-md-10">
                                        <div class="text-center">

                                            <div class="text-center" style="color: #757575;">

                                                <div class="md-form">
                                                    <input type="text" id="phoneCart2Login" name="phone" class="form-control text-left Bkoodak">
                                                    <label for="phoneCart2Login">شماره همراه</label>
                                                </div>

                                                <div class="md-form">
                                                    <input type="password" id="passwordCart2Login" name="password" class="form-control text-left Bkoodak">
                                                    <label for="passwordCart2Login">رمز عبور</label>
                                                </div>

                                                <p>
                                                    رمز عبور خود را
                                                    <a href="<?php echo e(url('/forgotPassword')); ?>">فراموش</a>
                                                    کرده اید!؟
                                                </p>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-success">
                                        ورود
                                        <i class="fas fa- ml-1 mr-1 text-white"></i>
                                    </button>
                                </div>

                            </div>

                        </div>
                    </form>
                    <!-- Central Modal Medium Success-->
                </div>

                <div class="col-lg-5 my-5">
                    <div class="card  animated fadeInDown" data-wow-delay="0.3s">
                        <div class="card-body">

                            <!-- Header -->
                            <div class="form-header primary-color">
                                <h3 class="font-weight-500 my-2 py-1">ثبت نام</h3>
                            </div>

                            <form action="<?php echo e(url('/register')); ?>" method="post" id="formCart2Register">
                                <!-- Body --><?php echo csrf_field(); ?>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نام</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="name">
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نام خانوادگی</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="last_name">
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >شماره همراه</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="phone" id="phoneCart2Register">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12 text-center ">
                                        <br>
                                        <p>
                                            <i class="fas fa-star pt-2 text-danger"></i>
                                            <span class="text-danger"> رمز عبور پس از ثبت نام به شماره همراه شما ارسال خواهد شد </span>
                                        </p>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <div class="text-center">
                                        <button class="btn btn-success btn-rounded btn-lg" type="submit">ثبت نام</button>
                                    </div>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>

        </section>
        <section>
            <div class="row">
                <?php if(count($cartDetail) > 0): ?>
                    <div class="col-12" style="height: 250px"></div>
                <?php else: ?>
                    <div class="col-12" style="height: 400px"></div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <div class="container-fluid" <?php if( !$is_login ): ?> style="display: none"  <?php endif; ?> >
        <section class="section my-5 pb-5">


            <div class="row justify-content-center">
                <div class="col-md-10">

                    <!-- Stepers Wrapper -->
                    <ul class="stepper stepper-horizontal">

                        <!-- First Step -->
                        <li >
                            <a href="#!" >
                                <h6 id="step1" class="circle success-color">1</h6>
                                <br>
                                <h6 class="label">اطلاعات تکمیلی</h6>
                            </a>
                        </li>

                        <!-- Second Step -->
                        <li >
                            <a href="#!" >
                                <h6 id="step2" class="circle gray-color">2</h6>
                                <br>
                                <h6 class="label">ثبت سفارش</h6>
                            </a>
                        </li>

                        <!-- Third Step -->
                        <li >
                            <a href="#!" >
                                <h6 id="step3" class="circle gray-color"><i class="fas fa-exclamation"></i></h6>
                                <br>
                                <h6 class="label">پرداخت</h6>
                            </a>
                        </li>

                    </ul>
                    <!-- /.Stepers Wrapper -->

                </div>
            </div>

            <div class="row justify-content-center" id="products">
                <div class="col-lg-7">
                    <div class="table-responsive mt-5 pt-5">

                        <table class="table product-table table-cart-v-1">

                            <!-- Table head -->
                            <thead>

                            <tr>


                                <th class="font-weight-bold animated fadeInDown">
                                    <strong>محصول</strong>
                                </th>


                                <th class="font-weight-bold animated fadeInDown">
                                    <strong>
                                        قیمت
                                        (تومان)
                                    </strong>
                                </th>

                                <th></th>

                                <th class="font-weight-bold animated fadeInDown">
                                    <strong>تعداد</strong>
                                </th>

                                <th></th>

                                <th class="font-weight-bold animated fadeInDown">
                                    <strong>
                                        قیمت کل
                                        (تومان)
                                    </strong>
                                </th>

                                <th></th>

                            </tr>

                            </thead>
                            <!-- Table head -->

                            <!-- Table body -->
                            <tbody>

                            <?php $__currentLoopData = $cartDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>



                                    <td>

                                        <h5 class="mt-3 animated fadeInDown">

                                            <strong class=""><?php echo e($i[1]); ?></strong>

                                        </h5>

                                        

                                    </td>

                                    <td >
                                        <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $i[2]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span>
                                    </td>

                                    <td></td>

                                    <td class="Bkoodak animated fadeInDown">
                                        <?php echo e($i[3]); ?>

                                    </td>

                                    <td></td>

                                    <td >
                                <span class="Bkoodak animated fadeInDown">
                                     <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $i[2]*$i[3]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </span>
                                    </td>

                                    <td></td>




                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <!-- Table body -->

                        </table>

                    </div>
                </div>
            </div>

            <div class="row justify-content-center" id="cartStep1">
                <div class="col-lg-7 pt-5 mt-5">
                    <div class="card  animated fadeInDown"  data-wow-delay="0.3s">
                        <div class="card-body">

                            <!-- Header -->
                            <div class="form-header success-color">
                                <h5 class="font-weight-500 my-2 py-1"> اطلاعات تکمیلی</h5>
                            </div>



                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="col-12">
                                            <h6 class="text-muted">
                                                شماره تلفن همراه گیرنده *
                                            </h6>
                                        </div>
                                        <div class="col-12">
                                            <input type="text" class="form-control Bkoodak  text-right pr-5"  name="number" id="numberHome">
                                            <div class="valid-feedback">
                                                 شماره همراه معتبر
                                            </div>
                                            <div class="invalid-feedback">
                                                لطفا شماره همراه معتبری را وارد کنید ...
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="form-group col-lg-12 ">

                                            <div class="input-group-prepend">
                                                <span class="input-group-text md-addon text-muted animated fadeInDown "  > استان *</span>
                                            </div>
                                            <select id="ostan"  class=" mdb-select md-form pt-1 mt-0" searchable="جستجو ...">
                                                <option value="" disabled selected>استان مورد نظر را انتخاب کنید ...</option>
                                                <option value="41" >آذربايجان شرقي</option>
                                                <option value="44" >آذربايجان غربي</option>
                                                <option value="45" >اردبيل</option>
                                                <option value="31" >اصفهان</option>
                                                <option value="26" >البرز</option>
                                                <option value="84" >ايلام</option>
                                                <option value="77" >بوشهر</option>
                                                <option value="21" >تهران</option>
                                                <option value="38" >چهارمحال بختياري</option>
                                                <option value="56" >خراسان جنوبي</option>
                                                <option value="51" >خراسان رضوي</option>
                                                <option value="58" >خراسان شمالي</option>
                                                <option value="61" >خوزستان</option>
                                                <option value="24" >زنجان</option>
                                                <option value="23" >سمنان</option>
                                                <option value="54" >سيستان و بلوچستان</option>
                                                <option value="71" >فارس</option>
                                                <option value="28" >قزوين</option>
                                                <option value="25" >قم</option>
                                                <option value="87" >کردستان</option>
                                                <option value="34" selected>کرمان</option>
                                                <option value="83" >کرمانشاه</option>
                                                <option value="74" >کهکیلویه و بويراحمد</option>
                                                <option value="17" >گلستان</option>
                                                <option value="13" >گیلان</option>
                                                <option value="66" >لرستان</option>
                                                <option value="15" >مازندران</option>
                                                <option value="86" >مرکزی</option>
                                                <option value="76" >هرمزگان</option>
                                                <option value="81" >همدان</option>
                                                <option value="35" >یزد</option>
                                            </select>
                                            <input type="hidden" id="ostanValidator" class="form-control ">
                                            <div class="valid-feedback">
                                                استان  معتبر
                                            </div>
                                            <div class="invalid-feedback">
                                                لطفا استان  معتبری را انتخاب کنید ...
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="form-group col-lg-12 ">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text md-addon  animated fadeInDown text-muted "  > شهر *</span>
                                            </div>
                                            <select id="city_id"  class="mdb-select md-form pt-1 mt-0 " disabled searchable="جستجو ...">
                                                <option value="" disabled selected>لطفا ابتدا استان را انتخاب کنید</option>
                                            </select>
                                            <input type="hidden" id="cityValidator" class="form-control ">
                                            <div class="valid-feedback">
                                                شهر  معتبر
                                            </div>
                                            <div class="invalid-feedback">
                                                لطفا شهر معتبری را انتخاب کنید ...
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="col-12">
                                            <h6 class="text-muted">
                                                کد پستی *
                                            </h6>
                                        </div>
                                        <div class="col-12">
                                            <input type="text" class="form-control Bkoodak  text-right pr-5"  name="post_code" id="post_code">
                                            <div class="valid-feedback">
                                                 کد پستی  معتبر
                                            </div>
                                            <div class="invalid-feedback">
                                                لطفا کد پستی معتبری را وارد کنید ...
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="col-12">
                                            <h6 class="text-muted">
                                                آدرس *
                                            </h6>
                                        </div>
                                        <div class="col-12">
                                            <input type="text" class="form-control Bkoodak  text-right pr-5"  name="address" id="address">
                                            <div class="valid-feedback">
                                                 آدرس  معتبر
                                            </div>
                                            <div class="invalid-feedback">
                                                لطفا آدرس معتبری بیشتر از
                                                <span class="Bkoodak">15</span>
                                                حرف وارد کنید
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="mt-3">
                                    <div class="text-center">
                                        <button class="btn btn-success btn-rounded btn-lg"  onclick="showStep2()">ثبت </button>
                                    </div>
                                </div>


                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center d-none" id="cartStep2">
                <div class="col-lg-7 pt-5 mt-5">
                    <div class="card  animated fadeInDown"  data-wow-delay="0.3s">
                        <div class="card-body">

                                <div class="justify-content-center row py-3 px-4">

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">نام خریدار</h6>
                                        <h6 id="number2"><?php echo e(( $user ) ? $user->name.' '.$user->last_name : ""); ?></h6>
                                    </div>

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">شماره همراه</h6>
                                        <h6 id="number2" class="Bkoodak"><?php echo e(( $user ) ?  $user->phone : ""); ?></h6>
                                    </div>

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">شماره تلفن همراه گیرنده</h6>
                                        <h6 id="numberHome2" class="Bkoodak"></h6>

                                    </div>

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">کد پستی</h6>
                                        <h6 id="code_post2" class="Bkoodak"></h6>
                                    </div>

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">استان</h6>
                                        <h6 id="ostan2" class="Bkoodak"></h6>
                                    </div>

                                    <div class="col-lg-6   py-3">
                                        <h6 class="text-muted ">شهر</h6>
                                        <h6 id="city2" class="Bkoodak"></h6>
                                    </div>

                                    <div class="col-lg-12  py-3">
                                        <h6 class="text-muted ">آدرس</h6>
                                        <h6 id="address2"></h6>
                                    </div>

                                    <div class="col-12 text-center">

                                        <hr>

                                        <div class="col-12 py-3">
                                            <h6 class="text-center">لطفا یکی از روش های ارسال مرسوله را انتخاب کنید</h6>
                                        </div>

                                        <!-- Material unchecked -->
                                        <div class="form-check form-check-inline text-center">
                                            <input type="radio" class="form-check-input" id="typax"  name="send_type">
                                            <label class="form-check-label" for="typax">
                                                <i class="fas fa-truck"></i>
                                                تیپاکس
                                            </label>
                                        </div>

                                        <!-- Material checked -->
                                        <div class="form-check form-check-inline text-center">
                                            <input type="radio" class="form-check-input" id="post" name="send_type"  checked>
                                            <label class="form-check-label" for="post">
                                                <i class="fas fa-dolly"></i>
                                                پست
                                            </label>
                                        </div>
                                    </div>

                                </div>

                        </div>
                    </div>
                </div>



                <div class="col-12 mt-3">
                    <div class="mt-3">
                        <div class="text-center">
                            <button class="btn btn-success btn-rounded btn-lg"  onclick="showStep3()">ثبت سفارش </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center d-none" id="cartStep3">
                <div class="col-lg-7 pt-5 mt-5">
                    <div class="card  animated fadeInDown"  data-wow-delay="0.3s">
                        <div class="card-body">

                                <div class="justify-content-center row py-3 px-4">

                                        <h6>
                                            سفارش شما ثبت شد
                                            برای تکمیل و پرداخت سفارش با شماره
                                            <?php echo e($offline_phone_number); ?>

                                            تماس حاصل فرمایید
                                            یا میتوانید از طریق درگاه پرداخت کنید
                                        </h6>

                                </div>

                        </div>
                    </div>
                </div>

                <div class="col-12 mt-3">
                    <div class="mt-3">
                        <div class="text-center">
                            <button class="btn btn-success btn-rounded btn-lg"  onclick="goToPay()">پرداخت آنلاین</button>
                        </div>
                    </div>
                </div>
            </div>


        </section>

        <div class="row">
            <div class="col-12" style="height: 200px"></div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


    <script src="<?php echo e(asset('home/js/addons-pro/stepper.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.stepper').mdbStepper();
        })
    </script>
    <script>

        $( "#formCart2Login" ).submit(function( event ) {

            if( Mobile_Check($("#phoneCart2Login").val()) == false ){
                event.preventDefault();
                toastr.warning('لطفا شماره همراه معتبری را وارد نمایید','هشدار');
            }

            if( $('#passwordCart2Login').val().length < 8 ){
                event.preventDefault();
                toastr.warning('رمز عبور نمیتواند کمتر از 8 حرف باشد','هشدار');
            }

        });

        $( "#formCart2Register" ).submit(function( event ) {

            if( Mobile_Check($("#phoneCart2Register").val()) == false ){
                event.preventDefault();
                toastr.warning('لطفا شماره همراه معتبری را وارد نمایید','هشدار');
            }

        });


        function cart3() {

            if($("#next").is(":disabled"))
                return 1 ;

            window.location.href="<?php echo e(url('cart3')); ?>";
        }

        $("#next").attr("disabled", true);

    </script>

    <script>
        function remove_valid_and_invalid(input) {

            if( input.hasClass( "is-valid" ) )
                input.removeClass( 'is-valid');

            if( input.hasClass( "is-invalid" ) )
                input.removeClass( 'is-invalid');
        }
        function set_valid(input) {

            remove_valid_and_invalid(input);
            input.addClass('is-valid')
        }
        function set_invalid(input) {

            remove_valid_and_invalid(input);
            input.addClass('is-invalid')
        }
        function is_null(input) { return !input.val(); }
    </script>

    <script>


        function validate_phone() {
            let input = $("#numberHome") ;
            if ( is_null(input) || Mobile_Check(input.val()) == false ){
                set_invalid(input) ;
                return  false ;
            }
            set_valid(input);
            return true ;
        }
        function validate_ostan() {
            let input = $("#ostan") ;
            let inputValid = $("#ostanValidator");
            if ( is_null(input) ){
                set_invalid(inputValid) ;
                return  false ;
            }
            set_valid(inputValid);
            return true ;
        }
        function validate_city() {
            let input = $("#city_id") ;
            let inputValid = $("#cityValidator");
            if ( is_null(input) ){
                set_invalid(inputValid);
                return  false ;
            }
            set_valid(inputValid);
            return true ;
        }
        function validate_post_code() {
            let input = $("#post_code") ;
            if ( is_null(input) || input.val().length < 10 ){
                set_invalid(input);
                return  false ;
            }
            set_valid(input);
            return true ;
        }
        function validate_address() {
            let input = $("#address") ;
            if ( is_null(input) || input.val().length < 15 ){
                set_invalid(input);
                return  false ;
            }
            set_valid(input);
            return true ;
        }

        var bool = [] ;
        var logic = true ;
        var send_type = 1 ;

        function showStep2() {

            bool = [] ;
            logic = true ;

            bool.push(validate_phone()) ;
            bool.push(validate_ostan()) ;
            bool.push(validate_city()) ;
            bool.push(validate_address()) ;
            bool.push(validate_post_code()) ;

            bool.forEach(function (i) {
                if( i == false) logic = false;
            });

            if(logic == false)
                return 1 ;

            $("#step1").removeClass("success-color");
            $("#step1").addClass("info-color");

            $("#step2").removeClass("gray-color");
            $("#step2").addClass("success-color");

            $("#cartStep1").addClass("d-none");
            $("#cartStep2").removeClass("d-none");
            $("#cartStep2").addClass("animated fadeInUp");


            $("#numberHome2").html($("#numberHome").val());
            $("#ostan2").html($( "#ostan option:selected" ).text());
            $("#city2").html($( "#city_id option:selected" ).text());
            $("#code_post2").html($("#post_code").val());
            $("#address2").html($("#address").val());


        }

        function showStep3() {

            var typax = $("input[id=typax]");
            var post = $("input[id=post]");

            if ( typax.is(':checked') == true){
                send_type = 2 ;
            }else if ( post.is(':checked') == true){
                send_type = 1 ;
            }else{
                send_type = 1 ;
            }

            var number = $("#numberHome").val() ;
            var code_post = $("#post_code").val() ;
            var address = $("#address").val() ;
            var ostan = $( "#ostan option:selected" ).text() ;
            var city = $( "#city_id option:selected" ).text() ;


            $.ajax({
                type: 'post',
                url: "<?php echo e(url('/insertOrderAndOrderPost')); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    number: number ,
                    code_post: code_post ,
                    address: address ,
                    ostan: ostan ,
                    city: city ,
                    send_type: send_type ,
                },
                dataType: 'json',
                success: function (data) {

                    if(data['response']==1){

                        toastr.info('سفارش ثبت شد', 'اعلامیه');

                        $("#step2").removeClass("success-color");
                        $("#step2").addClass("info-color");

                        $("#step3").removeClass("gray-color");
                        $("#step3").addClass("success-color");

                        $("#products").addClass("d-none");
                        $("#cartStep2").addClass("d-none");

                        $("#cartStep3").removeClass("d-none");
                        $("#cartStep3").addClass("animated fadeInTop");
                        order_id = data['id'];

                    }else if(data['response']==2){

                        toastr.warning('لطفا سفارش قبلی خود را پرداخت کنید', 'خطا');
                    }else if(data['response']==3){

                        toastr.warning('موجودی انبار برای ثبت سفارش کافی نیست', 'خطا');
                    }else {

                        toastr.warning('خطا در ارتباط با سامانه', 'اعلامیه');
                    }
                },
                error: function (xhr, statustext, error) {

                    toastr.warning('خطا در ارتباط با سامانه', 'خطا');
                }


            });



        }

        var order_id ;

        function goToPay() {
            window.location.href =  "<?php echo e(url('/transaction/')); ?>/"+order_id
        }

    </script>



    <script src="<?php echo e(asset("js/city/city.js")); ?>"></script>
    <script>

        $("#ostan ").change(function () {
            city($("#ostan option:selected").val());
            $('#city_id').prop( "disabled", false );
            $(".caret").hide();
        });

        // Material Select Initialization
        $(document).ready(function() {
            $('.mdb-select').materialSelect();
            $(".caret").hide();

        });

    </script>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/cart/index2.blade.php ENDPATH**/ ?>