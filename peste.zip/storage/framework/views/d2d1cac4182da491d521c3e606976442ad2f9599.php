<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('intro'); ?>
    <div class="jumbotron jumbotron-image color-grey-light m-0 p-0" style="background: url('<?php echo e(asset('img/logo.PNG')); ?>') center center no-repeat; height: 400px;">
        <div class="mask rgba-black-strong d-flex align-items-center h-100 m-0 p-0" >
            <div class="container-fluid text-center white-text py-5 m-0 p-0 text-center">
                <h1 class="mb-3">وبلاگ</h1>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container mt-5 mb-4">

        <section>

            <div class="row">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-4">

                        <!-- Card -->
                        <div class="">

                            <div class="view overlay z-depth-2 rounded">
                                <img class="img-fluid w-100" src="<?php echo e(( $post->image ) ? asset("{$post->image}") : asset("images/5.jpg")); ?>" alt="Sample">
                                <a href="#!">
                                    <div class="mask rgba-white-slight waves-effect waves-light"></div>
                                </a>
                            </div>

                            <div class="text-center pt-4">

                                <h2><?php echo e($post->title); ?></h2>
                                <p>
                                    <?php echo \Illuminate\Support\Str::substr($post->text , 0 , 200); ?>

                                    ...
                                </p>
                                <a href="<?php echo e(url("/blog/post/{$post->id}")); ?>"  class="btn btn-primary btn-rounded btn-md mr-1 mb-2 waves-effect waves-light">نمایش</a>

                            </div>

                        </div>
                        <!-- Card -->

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <div class="col-12">
                        <?php echo e($posts->links('components.paginate.index')); ?>

                    </div>


            </div>



        </section>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('blog.layout.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/blog/index.blade.php ENDPATH**/ ?>