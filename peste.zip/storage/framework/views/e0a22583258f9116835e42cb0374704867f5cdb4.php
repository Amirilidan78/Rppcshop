<?php if($form == true): ?> <form action="<?php echo e($formAction); ?>" method="<?php echo e($formMethod); ?>"> <?php echo csrf_field(); ?>  <?php endif; ?>

    <div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog  modal-notify <?php echo e($modalSize); ?> modal-<?php echo e($modalColor); ?> " role="document">
            <div class="modal-content text-center">
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading"> <?php echo e($title); ?> </p>
                </div>

                <div class="modal-body text-center">

                    <?php echo e($slot); ?>


                </div>

                <div class="modal-footer flex-center">

                    <?php if($form == true): ?>

                        <a  class="btn btn-outline-<?php echo e($modalColor); ?>" data-dismiss="modal">بستن</a>
                        <button type="submit"  class="btn btn-<?php echo e($modalColor); ?>" >
                            <?php if($formSubmitText): ?>
                                <?php echo e($formSubmitText); ?>

                            <?php else: ?>
                                ثبت
                            <?php endif; ?>
                        </button>

                    <?php else: ?>

                        <?php if($footer): ?>
                            <?php echo e($footer); ?>

                        <?php else: ?>
                            <a  class="btn  btn-outine-<?php echo e($modalColor); ?>" data-dismiss="modal">بستن</a>
                        <?php endif; ?>

                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

<?php if($form == true): ?> </form>  <?php endif; ?>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/modals/special.blade.php ENDPATH**/ ?>