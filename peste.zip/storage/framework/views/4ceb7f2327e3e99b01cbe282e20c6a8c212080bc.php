<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="container-fluid grey lighten-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 mb-3">
                <nav>
                    <h3 class="text-right text-muted h6">
                        <span >
                            فروشگاه اینترنتی شرکت تعاونی پسته رفسنجان / محصولات
                            /
                            <?php echo e($product->Name); ?>

                        </span>
                    </h3>
                </nav>
            </div>
            <div class="col-lg-8">
                <section id="productDetails" class="pb-5 pt-5">

                    <!--News card-->
                    <div class="card mt-5 hoverable">
                        <div class="row mt-5">

                            <div class="col-lg-6">
                                <div class="row mx-2">
                                    <!--Carousel Wrapper-->
                                    <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails mb-5 pb-4" data-ride="carousel">

                                        <!--Slides-->
                                        <div class="carousel-inner justify-content-center text-center text-md-left" role="listbox">

                                            <div class="carousel-item active">
                                                <img src="<?php echo e(($product->pic1) ? asset("{$product->pic1}") : asset('images/placeHolder.jpg')); ?>" alt=" <?php echo e($product->group->name); ?>  <?php echo e($product->Name); ?> " class="img-fluid" style="max-height: 400px ; width: 500px" title="<?php echo e($product->Name); ?>پسته ">
                                            </div>

                                            <div class="carousel-item ">
                                                <img src="<?php echo e(($product->pic2) ? asset("{$product->pic2}") : asset('images/placeHolder.jpg')); ?>" alt="<?php echo e($product->getPersianPacking()); ?> <?php echo e($product->Name); ?>" class="img-fluid" style="max-height: 400px ; width: 500px" title="<?php echo e($product->Name); ?>پسته ">
                                            </div>

                                            <div class="carousel-item ">
                                                <img src="<?php echo e(($product->pic3) ? asset("{$product->pic3}") : asset('images/placeHolder.jpg')); ?>" alt="<?php echo e($product->price); ?> <?php echo e($product->Name); ?>" class="img-fluid" style="max-height: 400px ; width: 500px" title="<?php echo e($product->Name); ?>پسته ">
                                            </div>
                                        </div>
                                        <!--/.Slides-->

                                        <!--Thumbnails-->
                                        <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev" >
                                            <span class="carousel-control-prev-icon" aria-hidden="true" ></span>
                                            <span class="sr-only text-dark" >Previous</span>
                                        </a>
                                        <style>
                                            .rotateAmir{
                                                -webkit-transform: rotate(180deg);  /* to support Safari and Android browser */
                                                -ms-transform: rotate(180deg);      /* to support IE 9 */
                                                transform: rotate(180deg);
                                            }
                                        </style>
                                        <a class="carousel-control-next rotateAmir" href="#carousel-thumb" role="button" data-slide="next">
                                            <span class="carousel-control-prev-icon" aria-hidden="true" ></span>
                                            <span class="sr-only text-dark " >Previous</span>
                                        </a>
                                        <!--/.Thumbnails-->

                                    </div>
                                    <!--/.Carousel Wrapper-->
                                </div>

                                <!--Grid row-->
                                <div class="row mb-4">

                                    <div class="col-md-12">

                                        <div id="mdb-lightbox-ui"><!-- Root element of PhotoSwipe. Must have class pswp. -->
                                            <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

                                                <!-- Background of PhotoSwipe.
                                                             It's a separate element, as animating opacity is faster than rgba(). -->
                                                <div class="pswp__bg"></div>

                                                <!-- Slides wrapper with overflow:hidden. -->
                                                <div class="pswp__scroll-wrap">

                                                    <!-- Container that holds slides. PhotoSwipe keeps only 3 slides in DOM to save memory. -->
                                                    <!-- don't modify these 3 pswp__item elements, data is added later on. -->
                                                    <div class="pswp__container">
                                                        <div class="pswp__item"></div>
                                                        <div class="pswp__item"></div>
                                                        <div class="pswp__item"></div>
                                                    </div>

                                                    <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
                                                    <div class="pswp__ui pswp__ui--hidden">

                                                        <div class="pswp__top-bar">

                                                            <!--  Controls are self-explanatory. Order can be changed. -->

                                                            <div class="pswp__counter"></div>

                                                            <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                                                            <!--<button class="pswp__button pswp__button--share" title="Share"></button>-->

                                                            <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                                                            <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                                                            <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
                                                            <!-- element will get class pswp__preloader--active when preloader is running -->
                                                            <div class="pswp__preloader">
                                                                <div class="pswp__preloader__icn">
                                                                    <div class="pswp__preloader__cut">
                                                                        <div class="pswp__preloader__donut"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!--
                                                                <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                                                                    <div class="pswp__share-tooltip"></div>
                                                                </div>
                                                                   -->

                                                        <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
                                                        </button>

                                                        <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
                                                        </button>

                                                        <div class="pswp__caption">
                                                            <div class="pswp__caption__center"></div>
                                                        </div>

                                                    </div>

                                                </div>

                                            </div></div>

                                        <div class="mdb-lightbox no-margin d-none d-lg-block" data-pswp-uid="1">

                                            <!--Grid column-->
                                            <figure class="col-md-4">
                                                <a href="<?php echo e(($product->pic1) ? asset("{$product->pic1}") : asset('images/placeHolder.jpg')); ?>" data-size="1600x1067">
                                                    <!-- Thumbnail-->
                                                    <img src="<?php echo e(($product->pic1) ? asset("{$product->pic1}") : asset('images/placeHolder.jpg')); ?>" class="img-fluid" style=" width: 150px !important  ; max-height: 120px" alt="اولین عکس <?php echo e($product->Name); ?>" title="<?php echo e($product->Name); ?> ">
                                                </a>
                                            </figure>
                                            <!--Grid column-->

                                            <!--Grid column-->
                                            <figure class="col-md-4">
                                                <a href="<?php echo e(($product->pic2) ? asset("{$product->pic2}") : asset('images/placeHolder.jpg')); ?>" data-size="1600x1067">
                                                    <!-- Thumbnail-->
                                                    <img src="<?php echo e(($product->pic2) ? asset("{$product->pic2}") : asset('images/placeHolder.jpg')); ?>" class="img-fluid" style=" width: 150px !important  ; max-height: 120px" alt="دومین عکس <?php echo e($product->Name); ?>" title="<?php echo e($product->Name); ?> ">
                                                </a>
                                            </figure>
                                            <!--Grid column-->

                                            <!--Grid column-->
                                            <figure class="col-md-4 pr-2">
                                                <a href="<?php echo e(($product->pic3) ? asset("{$product->pic3}") : asset('images/placeHolder.jpg')); ?>" data-size="1600x1067">
                                                    <!-- Thumbnail-->
                                                    <img src="<?php echo e(($product->pic3) ? asset("{$product->pic3}") : asset('images/placeHolder.jpg')); ?>" class="img-fluid" style=" width: 150px !important  ; max-height: 120px" alt="سومین عکس <?php echo e($product->Name); ?>" title="<?php echo e($product->Name); ?> ">
                                                </a>
                                            </figure>
                                            <!--Grid column-->
                                        </div>
                                    </div>
                                </div>
                                <!--Grid row-->
                            </div>

                            <div class="col-lg-5 mr-3 text-center text-md-right">
                                <h1 class="h3-responsive text-center text-md-right product-name font-weight-bold dark-grey-text mb-1 ml-xl-0 ml-4">
                                    <b><?php echo e($product->Name); ?></b>
                                </h1>
                                <h6 class="d-none"><b>پسته</b></h6>

                                <h4 class="h5-responsive mt-2 mb-3">
                                    <span class="product mb-2  ml-2">
                                        دسته بندی :
                                        <span class="pr-2">
                                            <?php echo e($product->group->name); ?>

                                        </span>
                                    </span>
                                </h4>
                                <h4 class="h5-responsive mt-2 mb-3">
                                    <span class="product mb-2  ml-2">
                                        بسته بندی :
                                        <span class="pr-2">
                                            <?php echo e($product->getPersianPacking()); ?>

                                        </span>
                                    </span>
                                </h4>
                                <h4 class="h5-responsive">
                                    <span class="product mb-4 ml-2">
                                        وزن :
                                            <span class="pr-2 Bkoodak">
                                                <?php echo e($product->weight); ?>

                                            </span>
                                          گرم
                                    </span>
                                </h4>

                                <h4 class="h3-responsive text-center text-md-right mb-5 ml-xl-0 ml-4 mt-3">

                                    <?php if($product->price_off): ?>
                                        <span class="red-text font-weight-bold">
                                            <strong class="Bkoodak"> <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price_off]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </strong>
                                            تومان
                                        </span>
                                        <span class="grey-text">
                                            <small>
                                                <s class="Bkoodak"> <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </s>
                                            </small>
                                        </span>
                                    <?php else: ?>
                                        <span class="red-text font-weight-bold">
                                            <strong class="Bkoodak"> <?php if (isset($component)) { $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a)): ?>
<?php $component = $__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a; ?>
<?php unset($__componentOriginal85d42e9379e021bcea48631987eebdd98eb6546a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </strong>
                                            تومان
                                        </span>
                                    <?php endif; ?>
                                </h4>

                                <h2 class="ml-xl-0 ml-4 h6" style="line-height: 27px">
                                    <?php echo $product->description; ?>

                                </h2>

                                <!-- Add to Cart -->
                                <section class="color">
                                    <div class="mt-5">
                                        <div class="row mt-3 mb-4">
                                            <div class="col-md-12 text-center text-md-left text-md-right">
                                                <?php if($product->count > 0): ?>

                                                    <p class="product mb-4 ml-2">
                                                        موجودی :
                                                        <span class="pr-2">
                                                                <?php echo e($product->count); ?>

                                                                                عدد
                                                            </span>
                                                    </p>

                                                    <input class="form-control" type="number" min="0"
                                                           max="<?php echo e($product->count); ?>" value="1" id="rangeInput"/>

                                                    <button class="btn btn-success btn-rounded waves-effect waves-light mt-3"
                                                            onclick="addToCart()">
                                                        افزودن به سبد خرید
                                                        <i class="fas fa-cart-plus mr-2" aria-hidden="true"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <span class="product mb-4 ml-2 pb-3">
                                                        تمام شد.
                                                    </span>
                                                    <button
                                                        class="btn btn-danger btn-rounded waves-effect waves-light disabled mt-3">
                                                        افزودن به سبد خرید
                                                        <i class="fas fa-cart-plus mr-2" aria-hidden="true"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <!-- /.Add to Cart -->
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

































































































































































    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        function addToCart() {

            $.ajax({
                type: 'post',
                url: "<?php echo e(url('/postAddProductTOShoppingCart')); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    count: $("#rangeInput").val() ,
                    product_id: "<?php echo e($product->id); ?>" ,
                },
                dataType: 'json',
                success: function (data) {

                    if(data['response']==1){
                        $("#cartIndex").html( parseInt(data['count']) );
                        $("#cartButton").addClass('animated');
                        $("#cartButton").addClass('tada');
                        setTimeout(function () {
                            $("#cartButton").removeClass('animated');
                            $("#cartButton").removeClass('tada');
                        }, 1000);


                        toastr.success('سبد خرید به روزرسانی شد','سبد خرید');

                    }else {

                        if(data['response']==-1)
                            toastr.warning('محصول یافت نشد','سبد خرید');

                        if(data['response']==0)
                            toastr.warning('موجودی انبار کافی نیست','سبد خرید');

                    }
                },
                error: function (xhr, statustext, error) {

                    toastr.warning('خطا در ارتباط با سامانه', 'خطا');
                }


            });

        }

        $("#countOrderProducts").html($("#rangeInput").val());
        $("#rangeInput").change(function () {
            $("#countOrderProducts").html($("#rangeInput").val());
        })
    </script>


<?php $__env->stopSection(); ?>





<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/products/show.blade.php ENDPATH**/ ?>