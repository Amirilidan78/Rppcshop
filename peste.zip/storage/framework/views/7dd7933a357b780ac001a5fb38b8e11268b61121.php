<?php $__env->startSection('style'); ?>
    <style>
        th,td{
            text-align: center ;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>

    <?php $__currentLoopData = $cartDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('components.modals.delete' ,[
            'id' => 'delete'.$i['0'] ,
            'title' => "حذف محصول از سبد خرید !؟" ,
            'deleteUrl' => url("/cart/delete/product/{$i['0']}") ,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($cartDetail): ?>
        <?php $__currentLoopData = $cartDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="<?php echo e('modal'.$i['0']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog  modal-notify modal-lg modal-warning " role="document">
                        <div class="modal-content text-center">
                            <div class="modal-header d-flex justify-content-center">
                                <p class="heading"> ویرایش تعداد محصول </p>
                            </div>

                            <div class="modal-body text-center">

                                <div class="d-flex justify-content-center my-4 " style="display: none">
                                    <span class="font-weight-bold blue-text mr-2 mt-1" style="display: none">0</span>
                                    <form class="range-field w-50 " style="display: none">
                                        <input class="border-0" type="range" min="0" max="100" style="display: none"/>
                                    </form>
                                    <span class="font-weight-bold blue-text ml-2 mt-1" style="display: none">100</span>
                                </div>

                                <?php ($count = \App\Product::find($i['0'])->count); ?>

                                <span class="font-weight-bold text-warning mr-2 mt-1">تعداد : </span>
                                <span class="font-weight-bold text-info mr-2 mt-1 Bkoodak " id="countOrderProducts<?php echo e($i['0']); ?>"><?php echo e($i['3']); ?></span>
                                <div class="d-flex justify-content-center my-4 pt-3">
                                    <form class="range-field w-75">
                                        <input class="border-0" type="range" min="0" max="<?php echo e($count); ?>" value="<?php echo e($i['3']); ?>" id="rangeInput<?php echo e($i['0']); ?>"  name="count"/>
                                    </form>
                                </div>


                                <input type="hidden" name="product_id" value="<?php echo e($i['0']); ?>">

                            </div>

                            <div class="modal-footer flex-center">
                                    <a  class="btn btn-outline-warning" data-dismiss="modal">بستن</a>
                                    <button    class="btn btn-warning" onclick="addToCart(<?php echo e($i['0']); ?>)"> ویرایش  </button>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <div class="container">
        <section class="section my-5 pb-5">

            <?php if(count($cartDetail) > 0): ?>

                <div class="table-responsive mt-5 pt-5">

                    <table class="table product-table table-cart-v-1">

                        <!-- Table head -->
                        <thead>

                        <tr>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>محصول</strong>
                            </th>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>تعداد</strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت کل
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th>ویرایش تعداد</th>

                            <th></th>

                            <th class="animated fadeInDown">
                                نمایش
                            </th>


                        </tr>

                        </thead>
                        <!-- Table head -->

                        <!-- Table body -->
                        <tbody>

                        <?php $__currentLoopData = $cartDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td>
                                    <button type="button" class="close text-danger animated fadeInDown" data-toggle="modal" data-target="#delete<?php echo e($i['0']); ?>">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </td>

                                <td>

                                    <h5 class="mt-3 animated fadeInDown">

                                        <strong class=""><?php echo e($i[1]); ?></strong>

                                    </h5>

                                    

                                </td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $i[2]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span>
                                </td>

                                <td></td>

                                <td class="Bkoodak animated fadeInDown">
                                    <?php echo e($i[3]); ?>

                                </td>

                                <td></td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown">
                                         <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $i[2]*$i[3]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </span>
                                </td>

                                <td></td>

                                <td>
                                     <?php if (isset($component)) { $__componentOriginal3b276f5506fcc9bb93ea3a50f548c593db430a67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\but::class, ['color' => 'warning','rounded' => 'true','size' => 'md','fadeIn' => 'true','modalTarget' => 'modal'.$i[0],'text' => 'ویرایش']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('but'); ?>
<?php $component->withAttributes([]); ?> ویرایش   <?php if (isset($__componentOriginal3b276f5506fcc9bb93ea3a50f548c593db430a67)): ?>
<?php $component = $__componentOriginal3b276f5506fcc9bb93ea3a50f548c593db430a67; ?>
<?php unset($__componentOriginal3b276f5506fcc9bb93ea3a50f548c593db430a67); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </td>
                                <td></td>

                                <?php
                                    $product = \App\Product::find($i[0])
                                ?>
                                <td>
                                    <a  class="btn btn-info btn-rounded btn-md animated fadeInDown">نمایش</a>
                                </td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <!-- Table body -->

                    </table>

                </div>

                <div class="col-12 mt-5 pt-5">
                    <div class="row ">

                        <div class="col-lg-4 mt-3 text-center">
                            <div class="card  animated fadeInDown">
                                <div class="card-header text-center info-color">
                            <span class="text-white">
                                قیمت کل
                            </span>
                                </div>
                                <div class="card-body text-center">
                                    <h6 class="Bkoodak text-center">
                                         <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $priceTotal]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </h6>
                                    <h6>
                                        تومان
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mt-3 text-center">
                            <a href="<?php echo e(route('deleteShoppingCart')); ?>" class="btn btn-warning  animated fadeInDown">
                                خالی کردن سبد خرید
                            </a>
                        </div>
                        <div class="col-lg-4 mt-3 text-center">
                            <a href="<?php echo e(url('cart2')); ?>" class="btn btn-success  animated fadeInDown">
                                مرحله بعدی
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-12" style="height: 100px"></div>

                <div class="col-12 text-center mt-5 pt-5">
                    <h4 class="text-center">
                        سبد خرید شما خالی است
                    </h4>
                    <a href="<?php echo e(url('products')); ?>" class="btn  btn-success btn-rounded waves-light">
                    <span>
                        بازگشت به صفحه ی محصولات
                    </span>
                    </a>
                </div>
            <?php endif; ?>




        </section>


        <section>
            <div class="row">
                <?php if(count($cartDetail) > 0): ?>
                    <div class="col-12" style="height: 250px"></div>
                <?php else: ?>
                    <div class="col-12" style="height: 400px"></div>
                <?php endif; ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

    <?php $__currentLoopData = $cartDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $("#rangeInput<?php echo e($i['0']); ?>").change(function () {
                $("#countOrderProducts<?php echo e($i['0']); ?>").html($("#rangeInput<?php echo e($i['0']); ?>").val());
            })
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    function addToCart(id) {

        $.ajax({
            type: 'post',
            url: "<?php echo e(url('/postAddProductTOShoppingCart')); ?>",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                count: $("#rangeInput"+id).val() ,
                product_id: id ,
            },
            dataType: 'json',
            success: function (data) {

                if(data['response']==1){
                    toastr.info('به روز رسانی شد','سبد خرید');
                    $("#cartIndex").html( parseInt(data['count']) );

                }else {

                    if(data['response']==-1)
                        toastr.warning('محصول یافت نشد','سبد خرید');

                    if(data['response']==0)
                        toastr.warning('موجودی انبار کافی نیست','سبد خرید');


                }
                location.reload();
            },
            error: function (xhr, statustext, error) {

                toastr.warning('خطا در ارتباط با سامانه', 'خطا');
            }


        });


    }

    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/cart/index.blade.php ENDPATH**/ ?>