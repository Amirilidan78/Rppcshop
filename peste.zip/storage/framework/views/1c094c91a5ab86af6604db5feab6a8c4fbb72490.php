<?php if($number < 10): ?>
    10+
<?php elseif($number < 20): ?>
    20+
<?php elseif($number < 30): ?>
    30+
<?php elseif($number < 40): ?>
    40+
<?php elseif($number < 50): ?>
    50+
<?php elseif($number < 100): ?>
    100+
<?php elseif($number < 150): ?>
    150+
<?php elseif($number < 200): ?>
    200+
<?php elseif($number < 250): ?>
    250+
<?php elseif($number < 300): ?>
    300+
<?php elseif($number < 350): ?>
    350+
<?php elseif($number < 400): ?>
    400+
<?php elseif($number < 450): ?>
    450+
<?php elseif($number < 500): ?>
    500+
<?php elseif($number < 550): ?>
    550+
<?php elseif($number < 600): ?>
    600+
<?php elseif($number < 650): ?>
    650+
<?php elseif($number < 700): ?>
    700+
<?php elseif($number < 750): ?>
    750+
<?php elseif($number < 800): ?>
    800+
<?php elseif($number < 850): ?>
    850+
<?php elseif($number < 900): ?>
    900+
<?php elseif($number < 950): ?>
    950+
<?php elseif($number < 1000): ?>
    1000+
<?php endif; ?>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/counter.blade.php ENDPATH**/ ?>