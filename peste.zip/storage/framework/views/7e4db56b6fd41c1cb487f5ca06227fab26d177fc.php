<!DOCTYPE html>
<html lang="fa">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>فروشگاه شرکت تعاونی پسته واقع در شهر رفسنجان </title>

    <link rel="canocical" href="<?php echo e($canocical); ?>" />
    <link rel="home" href="<?php echo e($home); ?>" />
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
    
    <meta property=”og:site_name” content="<?php echo e($og['site_name']); ?>" />
    <meta property=”og:locale” content="<?php echo e($og['locale']); ?>" />
    <meta property=”og:url” content=<?php echo e($og['url']); ?> />
    <meta property=”og:type” content="<?php echo e($og['type']); ?>" />
    <meta property=”og:description” content="<?php echo e($og['description']); ?>" />
    <meta property=”og:image” content="<?php echo e($og['image']); ?>" />

    <?php $twitterSpecial ?? $twitterSpecial = null ; ?>
    <?php if($twitterSpecial): ?>
        
        <meta name=”twitter:card” content="<?php echo e($twitterSpecial['card']); ?>" />
        <meta name=”twitter:title” content="<?php echo e($twitterSpecial['title']); ?>" />
        <meta name=”twitter:description” content="<?php echo e($twitterSpecial['description']); ?>" />
        <meta name=”twitter:url” content="<?php echo e($twitterSpecial['url']); ?>" />
        <meta name=”twitter:image” content="<?php echo e($twitterSpecial['image']); ?>" />
        <meta name=”twitter:creator” content="<?php echo e($twitterSpecial['creator']); ?>" />
    <?php else: ?>
        
        <meta name=”twitter:card” content="<?php echo e($twitter['card']); ?>" />
        <meta name=”twitter:title” content="<?php echo e($twitter['title']); ?>" />
        <meta name=”twitter:description” content="<?php echo e($twitter['description']); ?>" />
        <meta name=”twitter:url” content="<?php echo e($twitter['url']); ?>" />
        <meta name=”twitter:image” content="<?php echo e($twitter['image']); ?>" />
        <meta name=”twitter:creator” content="<?php echo e($twitter['creator']); ?>" />
    <?php endif; ?>

    
    <meta NAME="geo.position" CONTENT="<?php echo e($geo['position']); ?>">
    <meta NAME="geo.placename" CONTENT="<?php echo e($geo['placename']); ?>">
    <meta NAME="geo.region" CONTENT="<?php echo e($geo['region']); ?>">


    <?php echo $__env->yieldContent('meta'); ?>

    <meta http-equiv="language" content="fa">
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-164629643-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-164629643-1');
    </script>



    <link rel="stylesheet" href="<?php echo e(url('awesome/css/all.css')); ?>">
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-164629643-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-164629643-1');
    </script>

    <?php echo $__env->yieldContent('meta'); ?>
    <link href="<?php echo e(asset('home/font/bkoodak/Bkoodak.css')); ?>" rel="stylesheet">
    <script>
        function goToProductPage(title) {
            window.location.href = "<?php echo e(url('product')); ?>"+'/'+title ;
        }
    </script>
    <link rel="stylesheet" href="<?php echo e(asset('awesome/css/all.css')); ?>">
    <link href="<?php echo e(asset('home/css/all.min.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>

</head>

<body class="coworking-page">

  <!-- Main navigation -->
  <header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg scrolling-navbar navbar-light z-depth-0 fixed-top white ">
      <a class="navbar-brand text-success" href="<?php echo e(url('')); ?>">
          <img src="<?php echo e(asset('img/logo.PNG')); ?>" alt="پسته" style="width: 60px;">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
        aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
          <ul class="navbar-nav ml-auto text-uppercase smooth-scroll">

              <li class="nav-item">
                  <a class="nav-link heather-color animated fadeInDown" href="<?php echo e(url('')); ?>" data-offset="100">
                      <i class="fas fa-home"></i>
                      <strong>صفحه اصلی</strong>
                  </a>
              </li>

              <li class="nav-item">
                  <a class="nav-link heather-color animated fadeInDown" href="<?php echo e(url('products')); ?>" data-offset="100">
                      <i class="fas fa-box-open"></i>
                      <strong>محصولات</strong>
                  </a>
              </li>


              <li class="nav-item">
                  <a class="nav-link heather-color animated fadeInDown" href="<?php echo e(url('blog')); ?>" data-offset="100">
                      <i class="far fa-list-alt"></i>
                      <strong>وبلاگ</strong>
                  </a>
              </li>

              <li class="nav-item">
                  <a class="nav-link heather-color animated fadeInDown" href="<?php echo e(route('showAboutUs')); ?>" data-offset="100">
                      <i class="far fa-address-card"></i>
                      <strong>درباره ما</strong>
                  </a>
              </li>



          </ul>
          <ul class="navbar-nav mr-auto text-uppercase smooth-scroll">

              <li class="nav-item">

                  <?php if(session('user')): ?>
                      <a class="nav-link heather-color animated fadeInDown" href="<?php echo e(url('/userDashboard')); ?>">
                          <i class="fas fa-user-alt"></i>
                          <strong><?php echo e(session('user')['name'] . ' ' . session('user')['last_name']); ?></strong>
                      </a>
                  <?php else: ?>
                      <a class="nav-link heather-color animated fadeInDown" data-toggle="modal" data-target="#login" data-offset="100">
                          <i class="fas fa-user-alt"></i>
                          <strong>حساب کاربری</strong>
                      </a>
                  <?php endif; ?>

              </li>

              <li class="nav-item">
                  <a class="nav-link pt-0-1" href="<?php echo e(url('cart')); ?>" data-offset="100">
                      <button type="button" class="btn btn-outline-success btn-rounded btn-md z-depth-0 m-0 pt-2">
                          سبد خرید <i class="fas fa-shopping-basket"></i>
                          <span class="badge badge-success rounded" id="cartIndex">
                      <?php if(session("user_basket")): ?>
                                  <?php ($count = 0 ); ?>
                                  <?php $__currentLoopData = session("user_basket"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php ($count += $i['count']); ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php echo e($count); ?>

                              <?php else: ?>
                                  0
                              <?php endif; ?>
                  </span>
                      </button>
                  </a>
              </li>

          </ul>
      </div>
    </nav>
    <!-- Navbar -->

  <?php echo $__env->yieldContent('intro'); ?>


  </header>
  <!-- Main navigation -->

  <!-- Main layout -->
  <main>

    <div class="container">

    <!-- Central Modal Medium Success -->
    <form  action="<?php echo e(route('loginUser')); ?>" method="post"> <?php echo csrf_field(); ?>
        <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-notify modal-success" role="document">
                <!--Content-->
                <div class="modal-content">
                    <!--Header-->
                    <div class="modal-header">
                        <p class="heading lead">
                            <i class="fas fa-user text-white"></i>
                            ورود به حساب کاربری
                        </p>

                    </div>

                    <!--Body-->
                    <div class="modal-body">
                        <div class="text-center">

                            <div class="text-center" style="color: #757575;">
                                <div class="md-form">
                                    <input type="text" id="phone" name="phone" class="form-control text-left Bkoodak">
                                    <label for="phone">شماره همراه</label>
                                </div>
                                <div class="md-form">
                                    <input type="password" id="password" name="password" class="form-control text-left Bkoodak">
                                    <label for="password">رمز عبور</label>
                                </div>

                                <!-- Register -->
                                <p> هنوز
                                    <a href="<?php echo e(url('/register')); ?>">ثبت نام</a>
                                    نکرده اید!؟
                                </p> <!-- Register -->
                                <p>
                                    رمز عبور خود را
                                        <a href="<?php echo e(url('/forgotPassword')); ?>">فراموش</a>
                                    کرده اید!؟
                                </p>

                            </div>

                        </div>
                    </div>

                    <!--Footer-->
                    <div class="modal-footer justify-content-center">
                        <button type="submit" class="btn btn-success">
                            ورود
                            <i class="fas fa- ml-1 mr-1 text-white"></i>
                        </button>
                        <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                    </div>
                </div>
                <!--/.Content-->
            </div>
        </div>
    </form>
    <!-- Central Modal Medium Success-->

    </div>

      <?php echo $__env->yieldContent('body'); ?>
  </main>
  <!-- Main layout -->


  <!-- Footer -->
  <footer class="page-footer font-small unique-color-dark pt-4">

      <!-- Footer Links -->
      <div class="container-fluid text-center text-md-left">

          <!-- Grid row -->
          <div class="row justify-content-center" >

              <div class="col-lg-9">
                  <div class="row">
                      <!-- Grid column -->
                      <div class="col-md-3 mx-auto ">

                          <h5 class="font-weight-bold text-uppercase mt-3 mb-4">فروشگاه اینترنتی پسته رفسنجان</h5>
                          <p>
                              برای خرید حضوری میتوانید با شماره
                              <span class="Bkoodak"><?php echo e($phone_master ?? ''); ?></span>
                              تماس حاصل فرمایید .
                              آدرس دفتر
                              <?php echo e($address_master ?? ''); ?>

                          </p>
                      </div>
                      <!-- Grid column -->

                      <hr class="clearfix w-100 d-md-none">

                      <!-- Grid column -->
                      <div class="col-md-2 mx-auto">

                          <br>
                          <ul class="list-unstyled text-center">
                              <li>
                                  <a href="<?php echo e(url('/contact')); ?>">ارتباط با ما</a>
                              </li>
                              <li>
                                  <a href="<?php echo e(url('/aboutUs')); ?>">درباره ما</a>
                              </li>
                              <li>
                                  <a href="<?php echo e(url('/help')); ?>">راهنما</a>
                              </li>
                              <li>

                              </li>
                          </ul>

                      </div>
                      <!-- Grid column -->

                      <hr class="clearfix w-100 d-md-none">





                      <!-- Grid column -->
                      <div class="col-md-3 text-center">

                          <br>
                          <p>
                              <i class="fas fa-home mr-3"></i> <?php echo e($address_master ?? "شهرک آفتاب , آفتاب 12 , پلاک 17"); ?> </p>
                          <p>
                              <i class="fas fa-envelope mr-3"></i> <?php echo e($email_master ?? "rafila@gmail.com"); ?></p>
                          <p>
                              <i class="fas fa-phone mr-3"></i>  <span class="Bkoodak"><?php echo e($phone_master ?? "034-34242554"); ?></span> </p>

                      </div>

                      <hr class="clearfix w-100 d-md-none">

                      <!-- Grid column -->
                      <div class="col-md-1 mx-auto text-center">

                          <br>

                          <script src="https://cdn.zarinpal.com/trustlogo/v1/trustlogo.js" type="text/javascript"></script>
                      </div>
                  </div>
              </div>

          </div>
          <!-- Grid row -->

      </div>
      <!-- Footer Links -->

      <hr>

  
  
  
  
  
  
  
  
  
  <!-- Call to action -->

  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  <!-- Copyright -->
      <div class="footer-copyright text-center py-3 mt">


          <a href="https://www.instagram.com/corona_national_award/" class="px-3 pt-2">
              <i class="fab fa-instagram " style="font-size: 18px"></i>
          </a>
          <a href="https://t.me/Corona_National_Award" class="px-3 pt-2">
              <i class="fab fa-telegram " style="font-size: 18px"></i>
          </a>




      </div>
      <div class="footer-copyright text-center py-3 -3">
          © 2020 Copyright:
          <a href="https://www.linkedin.com/in/amir-ranjbar-9214b2179/" rel="nofollow">
              <i class="fab fa-linkedin"></i>
              Amir Ranjbar
          </a>
      </div>
      <!-- Copyright -->

  </footer>
  <!-- Footer -->

  <script type="text/javascript" src="<?php echo e(asset('home/js/all.min.js')); ?>"></script>

  

  <?php echo $__env->yieldContent('script'); ?>

  <script>
    <?php if(session('blogAlert')): ?>
        <?php if(session('blogAlert')[0] == false): ?>
            toastr.error("<?php echo e(session('blogAlert')[1]); ?>",'خطا') ;
        <?php elseif(session('blogAlert')[0] == true): ?>
            toastr.success("<?php echo e(session('blogAlert')[1]); ?>",'اطلاعیه') ;
        <?php else: ?>
            toastr.info("<?php echo e(session('blogAlert')[1]); ?>",'اطلاعیه') ;
        <?php endif; ?>
    <?php endif; ?>

        $( document ).ready(function() {
            new WOW().init();
        });

  </script>

</body>


</html>
<?php /**PATH C:\wamp64\www\peste\resources\views/blog/layout/mater.blade.php ENDPATH**/ ?>