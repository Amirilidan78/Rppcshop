<?php $__env->startSection('style'); ?>
    <style>
        th,tr,td{
            text-align: center;
        }
        th{
            border: none !important;
        }
    </style>

    <!-- Timeline CSS -->
    <link href="<?php echo e(asset('home/css/addons-pro/timeline.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('intro'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-fluid my-5 grey lighten-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-12">
                 <div class="row">

                     <?php echo $__env->make('home.user.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                     <div class="col-lg-9 mt-1">


                         <?php
                            $post = $order->post ;
                         ?>
                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-1">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row  px-5">


                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             تحویل گیرنده :
                                         </span>
                                         <h6>
                                             <?php echo e($order->user->name.' '.$order->user->last_name); ?>

                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             آدرس:
                                         </span>
                                         <h6>
                                             <?php echo e($post->address); ?>

                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                            کد پستی :
                                         </span>

                                         <h6 class="Bkoodak">
                                             <?php echo e($post->post_code); ?>

                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                            تلفن ثابت :
                                         </span>
                                         <h6 class="Bkoodak">
                                             <?php echo e($post->number); ?>

                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                          مبلغ کل :
                                         </span>
                                         <h6 class="Bkoodak">
                                              <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $order->total_price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                             تومان
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                          مبلغ قابل پرداخت :
                                         </span>
                                         <h6 class="Bkoodak">
                                              <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => ($order->status == 0) ? $order->total_price : 0]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                             تومان
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             روش ارسال :
                                         </span>
                                         <h6 class="Bkoodak">
                                             <?php echo e($order->getSendType()); ?>

                                         </h6>
                                     </div>
                                 </div>
                             </div>
                         </div>






                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-5">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row">
                                     <div class="col-12 py-3">
                                             <div class="table-responsive mt-3">
                                                 <table class="table product-table table-cart-v-1">

                                                     <!-- Table head -->
                                                     <thead>

                                                     <tr>


                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>نمایش محصول</strong>
                                                         </th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>محصول</strong>
                                                         </th>


                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>
                                                                 قیمت
                                                                 (تومان)
                                                             </strong>
                                                         </th>

                                                         <th></th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>تعداد</strong>
                                                         </th>

                                                         <th></th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>
                                                                 قیمت کل
                                                                 (تومان)
                                                             </strong>
                                                         </th>

                                                         <th></th>

                                                     </tr>

                                                     </thead>
                                                     <!-- Table head -->

                                                     <!-- Table body -->
                                                     <tbody>

                                                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                         <tr>

                                                             <td><a href="<?php echo e(url( "/product/{$product->product->Name}" )); ?>" class="btn btn-success btn-rounded">نمایش</a></td>

                                                             <td> <h6 class="mt-3 animated fadeInDown"> <strong class=""><?php echo e($product->product->Name); ?></strong> </h6>  </td>

                                                             <td >
                                                                 <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $product->price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span>
                                                             </td>

                                                             <td></td>

                                                             <td class=" animated fadeInDown"> <span class="Bkoodak"><?php echo e($product->count); ?></span>  </td>

                                                             <td></td>

                                                             <td > <span class="Bkoodak animated fadeInDown">  <?php if (isset($component)) { $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\price::class, ['price' => $product->total_price]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('price'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb)): ?>
<?php $component = $__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb; ?>
<?php unset($__componentOriginal89279c87822494a5b61e179bcbe6e125322b83fb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  </span> </td>

                                                             <td></td>

                                                         </tr>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                     </tbody>
                                                     <!-- Table body -->

                                                 </table>
                                             </div>
                                     </div>
                                 </div>
                             </div>
                         </div>






                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-5">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row">
                                     <div class="col-12 py-3">
                                         <style>
                                             span,li,.circle  {direction: ltr;}
                                         </style>
                                         <!-- Timeline -->
                                         <div class="row">
                                             <div class="col-md-12">

                                                 <h3 class="text-center">
                                                     وضعیت مرسوله
                                                 </h3>
                                                 <h4 class="Bkoodak h5 text-center">
                                                     <?php echo e($order->getOrderId()); ?>

                                                 </h4>

                                                 <div class="timeline-main">
                                                     <!-- Timeline Wrapper -->
                                                     <ul class="stepper stepper-vertical timeline timeline-basic pl-0">


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half <?php if($order->status == 0 ): ?> danger-color animated  flipInY infinite  <?php else: ?> success-color <?php endif; ?>">
                                                                    <i class="fas fa-coins "
                                                                      aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5">
                                                                 <h4 class="font-weight-bold text-center">عملیات پرداخت</h4>
                                                                 <div class="text-center">
                                                                     <?php if($order->status == 0 ): ?>
                                                                        <h6 class="text-danger text-center ">
                                                                            منتظر پرداخت
                                                                        </h6>
                                                                         <button class="btn btn-success btn-rounded" onclick="goToPay(<?php echo e($order->id); ?>)">پرداخت</button>
                                                                     <?php else: ?>
                                                                         <span class="text-success">
                                                                             پرداخت موفق
                                                                         </span>
                                                                         <br>
                                                                         <span class="text-success">
                                                                             شماره رهگیری
                                                                             <span class="Bkoodak"><?php echo e($factor->ref_id); ?></span>
                                                                         </span>
                                                                     <?php endif; ?>
                                                                 </div>
                                                             </div>
                                                         </li>


                                                         <li >
                                                             <!--Section Title -->
                                                             <a href="#!" >
                                                                <span class="circle z-depth-1-half <?php if($order->status == 1 ): ?> warning-color animated  flipInY infinite <?php elseif($order->status < 1): ?> gray-color <?php else: ?> success-color <?php endif; ?>">
                                                                    <i class="fas fa-calendar-check"
                                                                           aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 ml-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">تایید سفارش</h4>
                                                                 <?php if($order->status == 1 ): ?>
                                                                     <h6 class="text-warning text-center ">
                                                                         منتظر تایید
                                                                     </h6>
                                                                 <?php elseif($order->status < 1 ): ?>
                                                                     <h6 class="text-muted text-center ">
                                                                         <?php echo e($order->getStep()); ?>

                                                                     </h6>
                                                                 <?php else: ?>
                                                                     <span class="text-success ">
                                                                         تایید شد
                                                                     </span>
                                                                 <?php endif; ?>
                                                             </div>
                                                         </li>


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half <?php if($order->status == 2 ): ?> info-color animated  flipInY infinite <?php elseif($order->status < 2): ?> gray-color <?php else: ?> success-color <?php endif; ?>">
                                                                    <i class="fas fa-dolly" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">آماده سازی سفارش</h4>
                                                                 <?php if($order->status == 2 ): ?>
                                                                     <h6 class="text-info text-center ">
                                                                        در حال آماده سازی
                                                                     </h6>
                                                                 <?php elseif($order->status < 2 ): ?>
                                                                     <h6 class="text-muted text-center ">
                                                                         <?php echo e($order->getStep()); ?>

                                                                     </h6>
                                                                 <?php else: ?>
                                                                     <span class="text-success">
                                                                        آماده سازی
                                                                     </span>
                                                                 <?php endif; ?>
                                                             </div>
                                                         </li>


                                                         <li>
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle z-depth-1-half <?php if($order->status == 3 ): ?> secondary-color animated  flipInY infinite <?php elseif($order->status < 3): ?> gray-color <?php else: ?> success-color <?php endif; ?>">
                                                                     <i class="fas fa-shipping-fast" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 ml-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">خروج از مرکز پردازش</h4>
                                                                 <?php if($order->status == 3 ): ?>
                                                                     <h6 class="text-info text-center ">
                                                                         در حال بارگیری
                                                                     </h6>
                                                                 <?php elseif($order->status < 3 ): ?>
                                                                     <h6 class="text-muted text-center ">
                                                                         <?php echo e($order->getStep()); ?>

                                                                     </h6>
                                                                 <?php else: ?>
                                                                     <span class="text-success">
                                                                        از مرکز خارج شد
                                                                     </span>
                                                                 <?php endif; ?>
                                                             </div>
                                                         </li>


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half <?php if($order->status == 4 ): ?> success-color animated  flipInY infinite <?php elseif($order->status < 4): ?> gray-color <?php endif; ?>">
                                                                    <i class="fas fa-dolly" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5">
                                                                 <h4 class="font-weight-bold text-center">تحویل به اداره پست</h4>
                                                                 <?php if($order->status == 4 ): ?>
                                                                     <h6 class="text-success text-center ">
                                                                         بارکد پستی برای رهگیری :
                                                                         <?php echo e($order->post_rahgiri ?? "ثبت نشده"); ?>

                                                                     </h6>

                                                                 <?php elseif($order->status < 4 ): ?>
                                                                     <h6 class="text-muted text-center ">
                                                                         <?php echo e($order->getStep()); ?>

                                                                     </h6>
                                                                 <?php endif; ?>
                                                             </div>
                                                         </li>



                                                     </ul>
                                                     <!-- Timeline Wrapper -->
                                                 </div>
                                             </div>
                                         </div>
                                         <!-- Timeline -->
                                     </div>
                                 </div>
                             </div>
                         </div>







                     </div>



                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        function goToPay() {
            window.location.href =  "<?php echo e(url('/transaction/')); ?>/<?php echo e($order->id); ?>"
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/user/order.blade.php ENDPATH**/ ?>