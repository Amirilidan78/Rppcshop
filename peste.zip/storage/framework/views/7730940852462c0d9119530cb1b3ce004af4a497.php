<?php $__env->startSection('style'); ?>
    <style>
        .Bkoodak {
            font-size: 22px ;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>



    <div class="row justify-content-center pt-2">


        <div class="col-lg-5">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-header unique-color text-center">
                        <h5 class="text-center text-white">
                            سفارش این هفته
                        </h5>
                    </div>

                    <div class="text-center">
                        <canvas id="myChart" ></canvas>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-lg-5">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-header unique-color text-center">
                        <h5 class="text-center text-white">
                            بازدید سایت در هفته ی گذشته
                        </h5>
                    </div>

                    <div class="text-center">
                        <canvas id="lineChart"></canvas>
                    </div>
                </div>
            </div>
        </div>


    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


    <script>
        //bar
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if( \Morilog\Jalali\Jalalian::fromDateTime($order->date)->isToday() ): ?>
                            "امروز" ,
                        <?php elseif( \Morilog\Jalali\Jalalian::fromDateTime($order->date)->isYesterday() ): ?>
                            "دیروز" ,
                        <?php else: ?>
                            "<?php echo e(explode(' ' , \Morilog\Jalali\Jalalian::fromDateTime($order->date))[0]); ?>",
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                datasets: [{
                    label: 'سفارش',
                    data: [
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            "<?php echo e($order->total); ?>",
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgb(145,255,135)',
                        'rgb(255,244,172)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgb(145,255,135)',
                        'rgb(255,244,172)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>



    <script>
        //line
        var ctxL = document.getElementById("lineChart").getContext('2d');
        var myLineChart = new Chart(ctxL, {
            type: 'line',
            data: {
                labels: [
                    "هفت روز پیش",
                    "شش روز پیش",
                    "پنج روز پیش",
                    "چهار روز پیش",
                    "سه روز پیش",
                    "دو روز پیش",
                    "دیروز",
                    "امروز",
                ],
                datasets: [{
                    label: "بازدید",
                    data: [10, 20, 40, 6, 30, 4, 25 ,4, 25],
                    backgroundColor: [
                        'rgba(105, 0, 132, .2)',
                    ],
                    borderColor: [
                        'rgba(200, 99, 132, .7)',
                    ],
                    borderWidth: 2
                },
                    // {
                    //     label: "My Second dataset",
                    //     data: [28, 48, 40, 19, 86, 27, 90],
                    //     backgroundColor: [
                    //         'rgba(0, 137, 132, .2)',
                    //     ],
                    //     borderColor: [
                    //         'rgba(0, 10, 130, .7)',
                    //     ],
                    //     borderWidth: 2
                    // }
                ]
            },
            options: {
                responsive: true
            }
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>