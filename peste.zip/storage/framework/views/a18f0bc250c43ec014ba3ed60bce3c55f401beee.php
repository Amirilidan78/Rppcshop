<button
    class="btn btn-<?php echo e($color); ?>        <?php if( $rounded == true ): ?>  btn-rounded <?php endif; ?>       <?php if( $size ): ?>  btn-<?php echo e($size); ?>  <?php endif; ?>         <?php if($fadeIn): ?> animated fadeInUp <?php endif; ?>      "
    <?php if( $modalTarget ): ?> data-toggle="modal" data-target="#<?php echo e($modalTarget); ?>" <?php endif; ?> >

    <?php if(!empty($text)): ?> <?php echo e($text); ?> <?php else: ?> <?php echo e($slot); ?> <?php endif; ?>
</button>
<?php /**PATH C:\wamp64\www\peste\resources\views/components/but.blade.php ENDPATH**/ ?>