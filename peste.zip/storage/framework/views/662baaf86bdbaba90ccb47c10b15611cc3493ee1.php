<?php $__env->startSection('style'); ?>
    <link href="https://rppcshop.ir/products" rel="canonical" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .form-check-inline {
            width: 100% !important;
            padding-left: 15px;
        }
        .form-check-label  {
            width: 100% !important;
        }
        .list-group-item-action{
            cursor: default !important ;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- Modal: modalPoll -->
    <div class="modal fade right" id="filter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="false">
        <div class="modal-dialog modal-full-height modal-right modal-notify modal-success" role="document">
            <div class="modal-content">
                <!--Header-->
                <div class="modal-header">
                    <p class="heading lead">
                        فیلتر محصولات
                    </p>

                </div>

                <!--Body-->
                <div class="modal-body">
                    <div class="text-center">

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع فرآورده
                            </a>

                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="sm_is_salid" <?php echo e((in_array("1",$is_salty)) ? "checked" : null); ?> >
                                    <label class="form-check-label" for="sm_is_salid">شور</label>
                                </div>
                            </a>

                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="sm_not_salid" <?php echo e((in_array("0",$is_salty)) ? "checked" : null); ?>>
                                    <label class="form-check-label" for="sm_not_salid">خام</label>
                                </div>
                            </a>

                        </div>

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع بسته بندی
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="1" id="sm_packing1" <?php echo e((in_array("1",$packing)) ? "checked" : null); ?>>
                                    <label class="form-check-label" for="sm_packing1">سلوفون</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="2" id="sm_packing2" <?php echo e((in_array("2",$packing)) ? "checked" : null); ?>>
                                    <label class="form-check-label" for="sm_packing2">قوطی</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="3" id="sm_packing3" <?php echo e((in_array("3",$packing)) ? "checked" : null); ?>>
                                    <label class="form-check-label" for="sm_packing3">جعبه</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="4" id="sm_packing4" <?php echo e((in_array("4",$packing)) ? "checked" : null); ?>>
                                    <label class="form-check-label" for="sm_packing4">کارتون</label>
                                </div>
                            </a>


                        </div>

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع پسته
                            </a>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                    <div class="form-check text-right form-check-inline">
                                        <input type="checkbox" class="form-check-input" id="sm_group<?php echo e($group->id); ?>" value="<?php echo e($group->id); ?>" <?php echo e((in_array("{$group->id}",$filterGroups)) ? "checked" : null); ?>>
                                        <label class="form-check-label" for="sm_group<?php echo e($group->id); ?>"><?php echo e($group->name); ?></label>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                </div>

                <!--Footer-->
                <div class="modal-footer justify-content-center">
                    <a type="button" class="btn btn-success waves-effect waves-light" onclick="filter2()">
                        فیلتر
                    </a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">
                        بستن
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal: modalPoll -->


    <div class="container-fluid grey lighten-5">
        <div class="row justify-content-center">
            <div class="col-lg-10 pt-2">
                <section class="section pt-5">
                    <div class="row pt-5 justify-content-center">


                        <div class="col-12">
                            <div class="row">

                                <div class="col-lg-3 d-none  d-lg-block">
                                    <nav>
                                        <div class="card py-3 px-4 pb-5 ">

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع فرآورده
                                                </a>

                                                <a class="list-group-item list-group-item-action" >
                                                    <div class="form-check text-right form-check-inline" >
                                                        <input type="checkbox" class="form-check-input" id="is_salid"  <?php echo e((in_array("1",$is_salty)) ? "checked" : null); ?> >
                                                        <label class="form-check-label" for="is_salid" >شور</label>
                                                    </div>
                                                </a>

                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="not_salid" <?php echo e((in_array("0",$is_salty)) ? "checked" : null); ?>>
                                                        <label class="form-check-label" for="not_salid">خام</label>
                                                    </div>
                                                </a>

                                            </div>

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع بسته بندی
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="1" id="packing1" <?php echo e((in_array("1",$packing)) ? "checked" : null); ?>>
                                                        <label class="form-check-label" for="packing1">سلوفون</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="2" id="packing2" <?php echo e((in_array("2",$packing)) ? "checked" : null); ?>>
                                                        <label class="form-check-label" for="packing2">قوطی</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="3" id="packing3" <?php echo e((in_array("3",$packing)) ? "checked" : null); ?>>
                                                        <label class="form-check-label" for="packing3">جعبه</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="4" id="packing4" <?php echo e((in_array("4",$packing)) ? "checked" : null); ?>>
                                                        <label class="form-check-label" for="packing4">کارتون</label>
                                                    </div>
                                                </a>


                                            </div>

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع پسته
                                                </a>
                                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a class="list-group-item list-group-item-action" style="cursor: default">
                                                        <div class="form-check text-right form-check-inline">
                                                            <input type="checkbox" class="form-check-input" id="group<?php echo e($group->id); ?>" value="<?php echo e($group->id); ?>" <?php echo e((in_array("{$group->id}",$filterGroups)) ? "checked" : null); ?>>
                                                            <label class="form-check-label" for="group<?php echo e($group->id); ?>"><?php echo e($group->name); ?></label>
                                                        </div>
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <div class="col-12 text-center mt-3">
                                                <a   class="btn btn-success   waves-effect"  onclick="filter()">فیلتر</a>
                                            </div>


                                        </div>
                                    </nav>
                                </div>

                                <div class="col-lg-9">

                                    <div class="row">
                                        <div class="col-lg-6 mb-3">
                                            <nav>
                                                <h1 class="text-right text-muted h6">
                                                <span >
                                                    فروشگاه  شرکت تعاونی پسته رفسنجان / محصولات

                                                    <?php if($groupsName): ?>
                                                        /
                                                        <?php $__currentLoopData = $groupsName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($key != 0): ?>
                                                                ,
                                                            <?php endif; ?>
                                                            <?php echo e($name['name']); ?>


                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </span>

                                                    
                                                    
                                                    
                                                    
                                                </h1>
                                            </nav>
                                        </div>

                                        <div class="col-lg-6 mb-3 d-none  d-lg-block text-left">
                                            <i class="fab fa-buromobelexperte fa-2x text-muted text-success mx-1 "></i>
                                        </div>
                                    </div>


                                    <div class="row d-block d-lg-none">
                                        <div class="col-12 text-center pb-3">
                                            <button type="button" class="btn btn-success btn-rounded" data-toggle="modal" data-target="#filter">
                                                فیلتر محصولات
                                            </button>
                                        </div>
                                    </div>

                                    <div class="row">

                                        <?php if(count($products) > 0): ?>

                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboardProduct','data' => ['product' => $product,'size' => '4']]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('dashboardProduct'); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'size' => '4']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <div class="col-lg-12 text-center justify-content-center mt-5">
                                                    <div class="row justify-content-center">
                                                        <div class="col-lg-12"><?php echo e($products->links('components.paginate.index')); ?></div>
                                                    </div>
                                                </div>

                                                <div class="col-12 pt-3 text-center">
                                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                         <?php if (isset($component)) { $__componentOriginal80ad8177d85540467c466ef09dd0abd20595e2d6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Tag::class, ['name' => $tag->name,'hidden' => 'true']); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('tag'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal80ad8177d85540467c466ef09dd0abd20595e2d6)): ?>
<?php $component = $__componentOriginal80ad8177d85540467c466ef09dd0abd20595e2d6; ?>
<?php unset($__componentOriginal80ad8177d85540467c466ef09dd0abd20595e2d6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>

                                        <?php else: ?>

                                            <div class="col-12 text-center">
                                                <h5 class="text-center">
                                                    محصولی ثبت نشده
                                                </h5>
                                            </div>

                                        <?php endif; ?>



                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-12" style="height: 100px"></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var salty = [] ;
        var groups = [] ;
        var packing  = [];

        function filter() {

            if($("#is_salid").is(':checked'))
                salty.push( 1 );
            if($("#not_salid").is(':checked'))
                salty.push( 0 );


            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if($("#group<?php echo e($group->id); ?>").is(':checked'))
                    groups.push( $("#group<?php echo e($group->id); ?>").val() );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            if($("#packing1").is(':checked'))
                packing.push( 1 );

            if($("#packing2").is(':checked'))
                packing.push( 2 );

            if($("#packing3").is(':checked'))
                packing.push( 3 );

            if($("#packing4").is(':checked'))
                packing.push( 4 );


            window.location.href = "<?php echo e(url('/products?')); ?>"+"salty="+salty+"&"+"groups="+groups+"&"+"packing="+packing;


        }
        function filter2() {

            if($("#sm_is_salid").is(':checked'))
                salty.push( 1 );
            if($("#sm_not_salid").is(':checked'))
                salty.push( 0 );


            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if($("#sm_group<?php echo e($group->id); ?>").is(':checked'))
                    groups.push( $("#sm_group<?php echo e($group->id); ?>").val() );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            if($("#sm_packing1").is(':checked'))
                packing.push( 1 );

            if($("#sm_packing2").is(':checked'))
                packing.push( 2 );

            if($("#sm_packing3").is(':checked'))
                packing.push( 3 );

            if($("#sm_packing4").is(':checked'))
                packing.push( 4 );


            window.location.href = "<?php echo e(url('/products?')); ?>"+"salty="+salty+"&"+"groups="+groups+"&"+"packing="+packing;


        }
        // popovers Initialization
        $(function () {
            $('.example-popover').popover({
                container: 'body'
            })
        })

    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/products/index.blade.php ENDPATH**/ ?>