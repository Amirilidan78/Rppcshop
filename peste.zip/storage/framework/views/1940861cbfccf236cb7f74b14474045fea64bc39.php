<?php $__env->startSection('meta'); ?>
    <link href="https://rppcshop.ir" rel="canonical" >
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('intro'); ?>
    <!-- Intro -->
    <section class="view intro mt-5 pt-5">

        <div class="container">

            <div class="row d-flex justify-content-center align-items-center h-100 mx-md-5">

                <div class="col-lg-4 col-xl-5 col-flex mt-lg-0 pt-lg-4 mt-5 pt-5">

                    <h1 class="heading font-weight-bold  h4  text-success mb-4 animated fadeInDown">
                        فروشگاه شرکت تعاونی <strong>پسته</strong> رفسنجان
                        <br
                            class="d-block d-md-none d-lg-block d-xl-none"></h1>
                        <h2 class="subheading h6 mb-xl-4 pb-xl-0 mb-md-3 pb-md-3 mb-4 wow fadeInRight" data-wow-delay="0.3s">
                            فروش <strong>پسته</strong> بسته بندی به صورت آنلاین به سراسر کشور
                        </h2>




                </div>

                <div class="col-lg-8 col-xl-7 pt-lg-4">

                    <div class="view  wow  fadeInLeft" data-wow-delay="0.9s">
                        <img src="<?php echo e(asset('images/p3.jpeg')); ?>" class="img-fluid" alt="انواع پسته درجه یک فروشگاه ">
                    </div>

                </div>

            </div>

        </div>

    </section>
    <!-- Intro -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container">

        <br>
        <br>
        <br><hr>

        <section class="mt-5" >

            <!-- Secion heading -->
            <h3 class="text-center h4 font-weight-bold mt-5 pt-5 mb-3 drk-grey-text wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.2s;">
                خرید پسته بسته بندی درجه یک و دستچین از مرکز خرید پسته <strong>رفسنجان</strong>
            </h3>

            <!-- Section description -->
            <p class="text-center text-uppercase grey-text font-weight-bold mb-5 pb-4 wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.2s;">
                به صورت مستقیم از شرکت تعاونی <strong>پسته</strong> واقع در استان کرمان , شهر رفسنجان با اطمینان خرید کنید
            </p>

            <!-- Grid row -->
            <div class="row wow fadeIn" data-wow-delay="0.4s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.4s;">

                <!-- Grid column -->
                <div class="col-md-4">

                    <!-- Grid row -->
                    <div class="row text-center pb-5">
                        <div class="col-md-12 text-center">
                            <i class="fas fa-coins fa-3x text-success pb-3"></i>
                            <h3 class="h5 text-center"><strong>خرید پسته ارزان</strong></h3>
                            <p class="grey-text">با کمترین قیمت موجود در بازار</p>
                        </div>
                    </div>
                    <!-- Grid row -->

                    <!-- Grid row -->
                    <div class="row  pb-5">
                        <div class="col-md-12 text-center">
                            <i class="fas fa-check fa-3x text-success pb-3"></i>
                            <h3 class="h5"><strong>خرید پسته با کیفیت</strong></h3>
                            <p class="grey-text">با اطمینان از ما خرید کنید با تظمین کیفیت محصولات </p>
                        </div>
                    </div>
                    <!-- Grid row -->

                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-4 pb-3 flex-center">
                    <img src="https://rppcshop.ir/storage/products/1587872336.jpeg" alt="خرید پسته ارزان و با کیفیت" class="z-depth-0 img-fluid">
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-4">

                    <!-- Grid row -->
                    <div class="row  pb-5">
                        <div class="col-md-12 text-center">
                            <i class="fas fa-search-location fa-3x text-success pb-3"></i>
                            <h3 class="h5"><strong>ارسال به همه ی شهر ها با پست پیشتاز</strong></h3>
                            <p class="grey-text">خرید بالای 100 هزار تومان شامل پست رایگان است</p>
                        </div>
                    </div>
                    <!-- Grid row -->

                    <!-- Grid row -->
                    <div class="row text-center pb-5">
                        <div class="col-md-12 text-center">
                            <i class="fas fa-box-open fa-3x text-success  pb-3"></i>
                            <h3 class="h5"><strong>خرید پسته بسته بندی</strong></h3>
                            <p class="grey-text">محصولات در بسته بندی های سلوفن ,قوطی ,جعبه و کارتون به فروش میرسد</p>
                        </div>
                    </div>
                    <!-- Grid row -->

                </div>
                <!-- Grid column -->

            </div>
            <!-- Grid row -->

        </section>

    </div>


    
    <?php $__currentLoopData = $productsGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($products) > 0): ?>
            <?php ($group = $products[0]->group); ?>
            <br><hr>
            <div class="container-fluid my-1">
            <section  class=" pb-0 mt-0 ">
                <div class="row justify-content-center">

                    <div class="col-10 py-3 px-4">
                        <h3 class="text-right text-black-50 h5">
                            <strong><?php echo e($group->name); ?></strong>
                            <a href="<?php echo e(url('/products?groups=')); ?><?php echo e($group->id); ?>" class="h6 float-left text-success">
                                بیشتر
                            </a>
                        </h3>

                    </div>

                    <div class="col-lg-10">
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboardProduct','data' => ['product' => $product]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('dashboardProduct'); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if(count($productsSalty) > 0): ?>
        <br><hr>
        <section>
            <div class="container-fluid my-1">
                <section  class=" pb-0 mt-0 ">
                    <div class="row justify-content-center">

                        <div class="col-10 py-3 px-4">
                            <h3 class="text-right text-black-50 h5">
                                <strong>پسته شور</strong>
                                <a href="<?php echo e(url('/products?salty=1')); ?>" class="h6 float-left text-success">
                                    بیشتر
                                </a>
                            </h3>

                        </div>

                        <div class="col-lg-10">
                            <div class="row">
                                <?php $__currentLoopData = $productsSalty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboardProduct','data' => ['product' => $product]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('dashboardProduct'); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </section>
    <?php endif; ?>

    
    <?php if(count($productsNotSalty) > 0): ?>
        <br><hr>
        <div class="container-fluid my-1">
            <section  class=" pb-0 mt-0 ">
                <div class="row justify-content-center">

                    <div class="col-10 py-3 px-4">
                        <h3 class="text-right text-black-50 h5">
                             <strong>پسته خام</strong>
                            <a href="<?php echo e(url('/products?salty=0')); ?>" class="h6 float-left">
                                بیشتر
                            </a>
                        </h3>

                    </div>

                    <div class="col-lg-10">
                        <div class="row">
                            <?php $__currentLoopData = $productsNotSalty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboardProduct','data' => ['product' => $product]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('dashboardProduct'); ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    <?php endif; ?>







































































































    <div class="streak streak-photo streak-long-2"  id="your-element-selector">
        <div class="flex-center rgba-gradient-mask">
            <div class="container-fluid">

                <!-- Section heading -->
                <h3 class="text-center mb-5 pb-4 white-text font-weight-bold wow fadeInDown" data-wow-delay="0.2s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.2s;">
                    <strong >
                        درباره ی
                         فروشگاه شرکت تعوانی پسته رفسنجان
                    </strong>
                </h3>

                <!--First row-->
                <div class="row text-center justify-content-center">

                    <!--Second column-->
                    <div class="col-md-3 mb-2 text-center wow fadeInUp " data-wow-delay="0.2s">
                        <h6 class="h1  white-text mb-1 Bkoodak"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.counter','data' => ['number' => count($users)]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('counter'); ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($users))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </h6>
                        <p class="white-text"> کاربران</p>
                    </div>
                    <!--/Second column-->

                    <!--Third column-->
                    <div class="col-md-3 mb-2 text-center wow fadeInUp " data-wow-delay="0.2s">
                        <h6 class="h1  white-text mb-1 Bkoodak"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.counter','data' => ['number' => $productsCount]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('counter'); ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($productsCount)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </h6>
                        <p class="white-text">محصولات</p>
                    </div>
                    <!--/Third column-->

                    <!--Fourth column-->
                    <div class="col-md-3 text-center wow fadeInUp " data-wow-delay="0.2s">
                        <h6 class="h1  white-text mb-1 Bkoodak"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.counter','data' => ['number' => count($orders)]]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('counter'); ?>
<?php $component->withAttributes(['number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($orders))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </h6>
                        <p class="white-text">سفارش</p>
                    </div>
                    <!--/Fourth column-->

                </div>
                <!--First row-->

            </div>
        </div>
    </div>


    <div class="container-fluid">
        <section id="about" class="mt-5 mb-5">
            <!--Grid row-->
            <div class="row justify-content-center">
                <!--Grid column-->
                <div class="col-lg-4">
                    <img src="<?php echo e(asset('images/landing.JPG')); ?>" class="img-fluid" alt="انواع پسته درجه یک فروشگاه ">
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-5 ml-lg-5 justify-content-left">


                    <h3 class="text-left h4 dark-grey-text text-right font-weight-bold pb-4 wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-name: fadeIn; animation-delay: 0.2s;">
                            نحوه تشکیل شرکت تعاونی تولیدکنندگان پسته رفسنجان
                    </h3>

                    <p class="grey-text text-right">
                        با مروری کوتاه به وضع ناهنجار تولید و فروش <strong>پسته</strong> ایران در زمان قبل از تاسیس شرکت تعاونی تولیدکنندگان پسته رفسنجان، به این حقیقت تلخ می رسیم، که به علت اعمال سیاست های غلط دولت های وقت، و اتکاء بیش از حد بودجه کشور به درامدهای نفتی، و نیز عدم توجه به اهمیت تولیدات کشاورزی در اقتصاد ملی، که در این میان محصول پسته جایگاه خاص خود را دارد، و بالاخره عدم حمایت دولت و مسئولین از حقوق و منافع کشاورزی ایرانی، <strong>تجارت</strong> پسته ایران منحصراً در اختیار و سیطره چندین سرمایه دار خاص داخلی بود که با هدف سودجوئی صرف، و با حداکثر سوءاستفاده از وضعیت فقر و عدم توانائی زارعین پسته کار و نیاز مبرم آن ها به فروش فوری دسترنج خود به قیمت ارزان از روی استیصال، با ترفندهای گوناگون از جمله خرید سلف پسته از زارع یا دادن وام تا فصل برداشت محصول، پسته تولیدی آنان را به ثمن بخس می خریدند و به قیمت نازل
                    </p>


                </div>
                <!--Grid column-->

            </div>
            <!--Grid row-->

        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('js/vanta.js')); ?>"></script>
    <script src="<?php echo e(asset('js/net.min.js')); ?>"></script>
    <script>
        VANTA.NET({
            el: "#your-element-selector",
            mouseControls: true,
            touchControls: true,
            minHeight: 200.00,
            minWidth: 200.00,
            scale: 1.00,
            scaleMobile: 1.00,
            maxDistance: 20.00,
            backgroundColor: 0x4C4C4C,
            color: 0x3FB278
        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.mater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\peste\resources\views/home/index.blade.php ENDPATH**/ ?>