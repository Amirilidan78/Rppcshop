<?php
use  \Illuminate\Support\Facades\URL ;

Route::get('/sitemap', function() {

    // create new sitemap object
    $sitemap = App::make('sitemap');

    // set cache key (string), duration in minutes (Carbon|Datetime|int), turn on/off (boolean)
    // by default cache is disabled
    $sitemap->setCache('laravel.sitemap', 60);

    // check if there is cached sitemap and build new only if is not
    if (!$sitemap->isCached()) {
        // add item to the sitemap (url, date, priority, freq)
        $sitemap->add(URL::to('/'), now(), '1.0', 'daily');
        $sitemap->add(URL::to('/products'), now(), '0.9', 'monthly');
        $sitemap->add(URL::to('/blog'), now(), '0.8', 'monthly');
        $sitemap->add(URL::to('/aboutUs'), now(), '0.5', 'monthly');
        $sitemap->add(URL::to('/register'), now(), '0.5', 'monthly');
        $sitemap->add(URL::to('/forgotPassword'), now(), '0.5', 'monthly');
        $sitemap->add(URL::to('/contact'), now(), '0.5', 'monthly');


        // get all posts from db
        $posts = DB::table('products')->orderBy('Created_at', 'desc')->get();

        // add every post to the sitemap
        foreach ($posts as $post) {
            $sitemap->add($post->english_name, $post->Updated_at, 0.6, 'monthly');
        }
    }

    return $sitemap->render('xml');
});

Route::get('/flush',function (){ session()->flush(); });
Route::get('/test',function (){

    dd(
        \App\Order::create([
            'user_phone' => "09370843199" ,
            'status' => 1
        ])
    );
});
Route::get('/md5/{text}',function ($text){ return md5($text); });

//start homeController
Route::get('/',"Guest\homeController@index");
Route::get('/contact',"Guest\homeController@contact")->name('contact');
Route::get('/aboutUs',"Guest\homeController@aboutUs")->name('showAboutUs');
Route::get('/help',"Guest\homeController@help")->name('help');

Route::get('/register',"Guest\userController@showRegister")->name('showRegister');
Route::post('/register',"Guest\userController@postRegister")->name('postRegister');
Route::get('/forgotPassword',"Guest\userController@showForgotPassword")->name('postForgotPassword');
Route::post('/forgotPassword',"Guest\userController@postForgotPassword")->name('postForgotPassword');
Route::post('/checkCode',"Guest\userController@postCheckCode")->name('postCheckCode');
Route::post('/postChangePassword',"Guest\userController@postChangePassword")->name('postChangePassword');
//end homeController


//start cartController
Route::get('/cart',"Guest\cartController@index");
Route::get('/deleteShoppingCart',"Guest\cartController@deleteShoppingCart")->name('deleteShoppingCart');
Route::post('/postAddProductTOShoppingCart',"Guest\cartController@postAddProductTOShoppingCart");
Route::get('/cart/delete/product/{product:id}',"Guest\cartController@deleteProductFromShoppingCart");

Route::get('/cart2',"Guest\cartController@index2");
Route::post('/insertOrderAndOrderPost',"Guest\cartController@insertOrderAndOrderPost");


Route::get('/transaction/{order:id}','Guest\transactionController@index');
Route::get('/transaction/{order:id}/verify','Guest\transactionController@verify');

Route::post('/postTransaction','Guest\transactionController@postTransaction')->name('postTransaction');

Route::get('/successTransaction/','Guest\transactionController@successTransaction');
Route::get('/failTransaction/','Guest\transactionController@failTransaction');
//end cartController



//start productController
Route::get('/products',"Guest\productController@index");
Route::get('/product/{product:english_name}',"Guest\productController@show")->name('showProduct');
//end productController



Route::get('/blog',"Blog\postController@index")->name('showBlog');
Route::get('/blog/post/{post:id}',"Blog\postController@show")->name('showPost');


//start admin

Route::get('/login',"Admin\loginController@index");
Route::post('/login',"Admin\loginController@checkIsAdmin");

Route::prefix('/admin')->name('admin.')->middleware('admin')->group( function () {

    Route::get('', "Admin\dashboardController@index")->name('dashboard');


    Route::get('/products', "Admin\productController@index")->name('products');
    Route::get('/products/delete/{product:id}', "Admin\productController@destroy")->name('product.delete');
    Route::get('/products/edit/{product:id}', "Admin\productController@edit")->name('product.edit');
    Route::post('/products/store', "Admin\productController@store")->name('product.store');
    Route::post('/products/update/{product:id}', "Admin\productController@update")->name('product.update');

    Route::post('/groups/store', "Admin\groupController@store")->name('group.store');
    Route::get('/groups/destroy/{id}', "Admin\groupController@destroy")->name('group.destroy');
    Route::post('/groups/update', "Admin\groupController@update")->name('group.update');

    Route::get('/orders', "Admin\orderController@index")->name('orders');
    Route::get('/order/{order:id}', "Admin\orderController@show")->name('order');
    Route::get('/order/{order:id}/delete', "Admin\orderController@delete")->name('order.delete');
    Route::get('/order/{order:id}/changeStatus/{status}', "Admin\orderController@changeStatus")->name('order.changeStatus');
    Route::get('/order/{order:id}/changeStatusToPost/{code}', "Admin\orderController@changeStatusToPost")->name('order.changeStatusToPost');


    Route::get('/tags', 'Admin\tagController@index')->name('tags');
    Route::post('/tags/store', 'Admin\tagController@store')->name('tags.store');
    Route::post('/tags/modify', 'Admin\tagController@modify')->name('tags.modify');
    Route::get('/tags/delete/{tag:id}', 'Admin\tagController@delete')->name('tags.delete');
    Route::post('/tags/products/{product:id}', 'Admin\tagController@products')->name('tags.products');

    Route::get('/users', "Admin\userController@index")->name('users');
    Route::get('/users/excel', "Admin\userController@excel")->name('user.excel');
    Route::post('/users/modify', "Admin\userController@modify")->name('users.modify');
    Route::post('/users/search', "Admin\userController@search")->name('users.search');
    Route::post('/users/store', "Admin\userController@store")->name('users.store');
    Route::get('/users/delete/{user:id}', "Admin\userController@delete")->name('users.delete');

    Route::get('/blog', "Admin\BlogController@index")->name('blog');
    Route::get('/blog/post/delete/{id}', "Admin\BlogController@delete")->name('post.delete');
    Route::post('/blog/post/add', "Admin\BlogController@add")->name('post.add');
    Route::get('/blog/post/edit/{post:id}', "Admin\BlogController@edit")->name('post.edit');
    Route::post('/blog/post/update/{post:id}', "Admin\BlogController@update")->name('post.update');
});



Route::get('/logout',function (){
    session()->flush();
    \App\functions\view\alert::guest(true,'از حساب کاربری خود خارج شدید');
    return redirect('');
});



Route::post('/user_login',"Guest\userController@postLogin")->name('loginUser');
Route::prefix('/userDashboard')->name('user.')->middleware('user')->group( function () {

    Route::get('', "Guest\userController@showDashboard")->name('dashboard');
    Route::post('/user/modify', "Guest\userController@modifyUser")->name('modifyUser');
    Route::post('/user/password/modify', "Guest\userController@modifyUserPassword")->name('modifyUserPassword');

    Route::get('/address', "Guest\userController@showAddress")->name('address');
    Route::get('/address/delete/{id}', "Guest\userController@deleteAddress")->name('deleteAddress');
    Route::post('/address/create', "Guest\userController@createAddress")->name('createAddress');

    Route::get('/comments ', "Guest\userController@showComments")->name('comments');

    Route::get('/orders ', "Guest\userController@showOrders")->name('orders');

    Route::get('/orders', "Guest\userController@showOrders")->name('orders');
    Route::get('/order/{order:id}', "Guest\userController@showOrder")->name('order');

    Route::get('/comments', "Guest\userController@showComments")->name('comments');
    Route::get('/logout', "Guest\userController@logout")->name('logout');
});

Route::fallback(function () {
    return view('home.404') ;
});

Route::view('/notAllow','notAllow');
