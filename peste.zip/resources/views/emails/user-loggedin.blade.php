@component('mail::message')

<h1 style="text-align: right">
    RppcShop.ir
</h1>
<h4 style="text-align: right">
    ورود ادمین
    {{$name}}
</h4>
<h4 style="text-align: right">
    در تاریخ
    {{$date}}
</h4>
<h4 style="text-align: right">
    ip :
    {{$ip}}
</h4>

{{--@component('mail::button', ['url' => ''])--}}
{{--Button Text--}}
{{--@endcomponent--}}

@endcomponent
