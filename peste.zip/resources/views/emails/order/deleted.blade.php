@component('mail::message')
    <h1 style="text-align: right">
        RppcShop.ir
    </h1>
    <h4 style="text-align: right">
        {{ $order->getOrderId() }}
        سفارش

    </h4>
    <h4 style="text-align: right">
        در تاریخ
        {{ $order->Created_at }}
    </h4>
    <h4 style="text-align: right">
        برای کاربر
        {{ $user->name . ' ' . $user->last_name }}
    </h4>
    <h4 style="text-align: right">
        با شماره همراه
        {{ $user->phone }}
    </h4>
    <h4 style="text-align: right  ; color: red">
        حذف شد .
    </h4>
    <h4 style="text-align: right ; color: blue">
        وضعیت سفارش
        {{ $order->getStep() }}
    </h4>
@endcomponent
