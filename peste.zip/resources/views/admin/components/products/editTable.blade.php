<div class="table-responsive text-nowrap">

    <table class="table">
        <thead>
        <tr>
            <th scope="col" class="text-right">#</th>
            <th scope="col">عکس اصلی</th>
            <th scope="col"></th>
            <th scope="col">نام محصول</th>
            <th scope="col"></th>
            <th scope="col">قیمت</th>
            <th scope="col"></th>
            <th scope="col">تعداد موجود</th>
            <th scope="col"></th>
            <th scope="col">گالری عکس ها</th>
            <th scope="col">ویرایش</th>
        </tr>
        </thead>
        <tbody>
        @foreach($products as $product)
            <tr>
                <td>
                    <button type="button" class="close text-center" style="opacity: 1" aria-label="Close">
                        <span class="text-danger text-center" >×</span>
                    </button>
                </td>
                <td class="animated fadeInDown">
                    @if($product->pic1)
                        <div class="mdb-lightbox no-margin">
                            <figure>
                                <a href="{{url("insert/products/{$product->id}/{$product->pic1}")}}" data-size="1600x1067">
                                    <img src='{{url("insert/products/{$product->id}/{$product->pic1}")}}' class="rounded " alt="عکس" style="width: 70px ; height: 70px"/>
                                </a>
                            </figure>
                        </div>
                    @else
                            ثبت نشده
                    @endif
                </td>
                <td></td>
                <td class="animated fadeInDown">{{$product->Name}}</td>
                <td></td>
                <td class="Bkoodak animated fadeInDown">@Price(['price'=>$product->price]) @endPrice</td>
                <td></td>
                <td class="Bkoodak animated fadeInDown" >{{$product->count}}</td>
                <td></td>
                <td>
                    <button class="btn btn-rounded btn-info animated fadeInDown" data-toggle="modal" data-target="#galley">
                        نمایش
                    </button>
                </td>
                <td>

                    <button class="btn btn-rounded btn-warning animated fadeInDown" data-toggle="modal" data-target="#centralModalWarning">
                        ویرایش سریع
                    </button>
                    <a class="btn btn-rounded btn-secondary animated fadeInDown"  href="">
                        ویرایش
                    </a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <div class="col-12 justify-content-center text-center">
        {{ $products->links('components.paginate.index') }}
    </div>

</div>
