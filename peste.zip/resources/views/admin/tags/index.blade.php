@extends('admin.layout.master')

@section('style')

    <x-db-table-config/>

@stop
@section('body')


    <div class="row justify-content-center">
        <div class="col-lg-10">
            <ul class="nav nav-tabs md-tabs mt-2 primary-color" id="myTabMD" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#all" role="tab" aria-controls="home-md"
                       aria-selected="true">همه</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " id="home-tab-md" data-toggle="tab" href="#productsTab" role="tab" aria-controls="home-md"
                       aria-selected="true">محصولات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#add" role="tab" aria-controls="contact-md"
                       aria-selected="false">تگ جدید</a>
                </li>
            </ul>
            <div class="tab-content card pt-5" id="myTabContentMD">

                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">

                    @if(count($all) > 0)
                        <x-db-table :items="['نام','ویرایش','حذف']">
                            @foreach($all as $tag)
                                <tr>
                                    <td>{{$tag->name}}</td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" onclick="showModifyModal('{{$tag->id}}','{{$tag->name}}')">ویرایش</button>
                                    </td>
                                    <td>
                                        <button class="btn btn-danger btn-sm" onclick="showDeleteModal({{$tag->id}})">حذف</button>
                                    </td>
                                </tr>
                            @endforeach
                        </x-db-table >
                    @else
                        <h5 class="text-center">
                            ثبت نشده
                        </h5>
                    @endif

                </div>


                <div class="tab-pane fade  " id="productsTab" role="tabpanel" aria-labelledby="productsTab">

                    @if(count($products) > 0)
                        <x-db-table :items="['آیدی','نام محصول','تگ ها ']">
                            @foreach($products as $product)

                                <tr>

                                    <td><span class="Bkoodak">{{$product->id}}</span></td>

                                    <td>{{$product->Name}}</td>

                                    <td> <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#products{{$product->id}}">ویرایش</button> </td>

                                </tr>

                            @endforeach
                        </x-db-table >
                    @else
                        <h5 class="text-center">
                            ثبت نشده
                        </h5>
                    @endif

                </div>

                <div class="tab-pane fade" id="add" role="tabpanel" aria-labelledby="add">

                    <form action="{{ route('admin.tags.store') }}" method="POST"> @csrf
                        <div class="row justify-content-center">
                            <div class="col-lg-10">

                                <div class="row">

                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >نام </span>
                                        </div>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                    <div class="col-lg-6"></div>

                                    <div class="col-lg-4">
                                        <button type="submit" class="btn btn-success btn-rounded  animated fadeInDown">
                                            ذخیره
                                        </button>
                                    </div>
                                    <div class="col-lg-8"></div>
                                </div>

                            </div>
                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>



    <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">حذف تگ</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-times fa-4x animated rotateIn"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn  btn-outline-danger" data-dismiss="modal">بستن</a>
                    <button  class="btn  btn-danger waves-effect" id="deleteButton" data-delete-id="" onclick="tagDelete()" >حذف</button>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>

    <form action="{{ route('admin.tags.modify') }}" method="post">  @csrf
        <div class="modal fade" id="modify" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog  modal-notify modal-warning" role="document">
                <!--Content-->
                <div class="modal-content text-center">
                    <!--Header-->
                    <div class="modal-header d-flex justify-content-center">
                        <p class="heading">ویرایش تگ</p>
                    </div>

                    <!--Body-->
                    <div class="modal-body text-center">

                        <div class="row justify-content-center">
                            <input type="hidden" id="modifyTagId" name="id">
                            <div class="col-lg-8 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown">نام </span>
                                </div>
                                <input type="text" class="form-control" id="modifyTagName" name="name">
                            </div>
                        </div>

                    </div>

                    <!--Footer-->
                    <div class="modal-footer flex-center">
                        <a  class="btn  btn-outline-warning" data-dismiss="modal">بستن</a>
                        <button type="submit" class="btn  btn-warning waves-effect">ویرایش</button>
                    </div>
                </div>
                <!--/.Content-->
            </div>
        </div>
    </form>

    @foreach($products as $product)
        <?php
            $tags = $product->tags()->get()->map(function ($key){
                return $key->id ;
            })->toArray() ;
        ?>
        <form action="{{ route('admin.tags.products',$product->id) }}" method="post">  @csrf
            <div class="modal fade" id="products{{$product->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog  modal-notify modal-warning" role="document">
                    <!--Content-->
                    <div class="modal-content text-center">
                        <!--Header-->
                        <div class="modal-header d-flex justify-content-center">
                            <p class="heading">محصول {{$product->Name}}</p>
                        </div>

                        <!--Body-->
                        <div class="modal-body text-center">

                            @foreach($all as $allTag)
                                    <a class="list-group-item list-group-item-action" style="cursor: default">
                                        <div class="form-check text-center form-check-inline">
                                            <input type="checkbox" class="form-check-input" value="{{$allTag->id}}"  id="check{{$allTag->id}}{{$product->id}}" name="{{$allTag->id}}" {{(in_array($allTag->id,$tags)) ? "checked" : null}}>
                                            <label class="form-check-label" for="check{{$allTag->id}}{{$product->id}}">{{$allTag->name}}</label>
                                        </div>
                                    </a>
                            @endforeach

                        </div>

                        <!--Footer-->
                        <div class="modal-footer flex-center">
                            <a  class="btn  btn-outline-warning" data-dismiss="modal">بستن</a>
                            <button type="submit" class="btn  btn-warning waves-effect">ثبت</button>
                        </div>
                    </div>
                    <!--/.Content-->
                </div>
            </div>
        </form>
    @endforeach



@stop


@section('script')

    <script>
        function showDeleteModal(id) {

            $('#delete').modal('show');
            $( "#deleteButton" ).data( "delete-id" , id);
        }

        function showModifyModal(id,name) {

            $('#modify').modal( 'show' );
            $( "#modifyTagId" ).val( id );
            $( "#modifyTagName" ).val( name );
        }

        function tagDelete() {

            id = $( "#deleteButton" ).data( "delete-id");
            window.location.href = "{{url('/admin/tags/delete/')}}"+'/'+id;
        }
    </script>

@stop
