<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>- پسته -</title>


    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('awesome/css/all.css')}}">


    {{-- start mdb css --}}
    <link href="{{asset('home/css/bootstrap.css')}}" rel="stylesheet">
    <link href="{{asset('home/css/mdb.css')}}" rel="stylesheet">
    {{-- end mdb css --}}
    <link href="{{asset('home/font/bkoodak/Bkoodak.css')}}" rel="stylesheet">

    <script type="text/javascript" src="{{asset('home/js/jquery-3.4.1.min.js')}}"></script>




    <style>

        .Bkoodak{
            font-family: "B Koodak" !important;
            /*font-size: 20px;*/
        }

        .collapsible-header{
            font-size: 15px !important;
            margin-top: 4px !important;
            margin-bottom: 4px !important;
        }


        .white-skin{
            background:  white;
        }

        .md-outline.select-wrapper+label {
            top: .6em !important;
            z-index: 2 !important;
        }

        * {direction: rtl;}
        div{
            text-align: right
        }

        @font-face {
            font-family: "IRANSansDN";
            src: url({{url('home/font/iransansdn.ttf')}}) format('truetype');
        }

        div,b,h1,h2,h3,h4,h5,h6,a,span,p{
            font-family: "IRANSansDN" !important;
        }


    </style>

    @yield('style')
</head>

<body class="coworking-page">

<!-- Main navigation -->
<header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg scrolling-navbar navbar-light z-depth-0 fixed-top white ml-md-4 mr-md-3" style="direction: ltr">
        <a class="navbar-brand text-info" >
            <strong>پنل <br><span class="font-weight-bold ">مدیریت</span></strong>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
                aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
            <ul class="navbar-nav ml-auto text-uppercase smooth-scroll">
                <li class="nav-item">
                    <a class="nav-link @if(!request()->routeIs('admin.dashboard')) heather-color @endif"  href="{{route('admin.dashboard')}} " data-offset="100">
                        <i class="fas fa-home"></i>
                        <strong>پیشخوان</strong>
                    </a>
                </li>




                @if($access_products)
                    <li class="nav-item">
                        <a class="nav-link @if(!request()->routeIs('admin.products')) heather-color @endif" href="{{route('admin.products')}}" data-offset="100">
                            <i class="fas fa-box"></i>
                            <strong>محصولات</strong>
                        </a>
                    </li>
                @endif

                @if($access_orders)
                    <li class="nav-item">
                        <a class="nav-link @if(!request()->routeIs('admin.orders')) heather-color @endif" href="{{route('admin.orders')}}" data-offset="100">
                            <i class="fas fa-clipboard-list"></i>
                            <strong>سفارش ها</strong>
                        </a>
                    </li>
                @endif

                @if($access_users)
                    <li class="nav-item">
                        <a class="nav-link @if(!request()->routeIs('admin.users')) heather-color @endif" href="{{route('admin.users')}}" data-offset="100">
                            <i class="fas fa-users"></i>
                            <strong>کاربران</strong>
                        </a>
                    </li>
                @endif

                @if($access_posts)
                    <li class="nav-item">
                        <a class="nav-link @if(!request()->routeIs('admin.blog')) heather-color @endif" href="{{route('admin.blog')}}" data-offset="100">
                            <i class="fas fa-chart-line"></i>
                            <strong>وبلاگ</strong>
                        </a>
                    </li>
                @endif

                @if($access_tags)
                    <li class="nav-item">
                        <a class="nav-link @if(!request()->routeIs('admin.tags')) heather-color @endif" href="{{route('admin.tags')}}" data-offset="100">
                            <i class="fas fa-tags"></i>
                            <strong>تگ ها</strong>
                        </a>
                    </li>
                @endif


                <li class="nav-item">
                    <a class="nav-link heather-color" href="{{ url('/logout') }}" data-offset="100">
                        <i class="fas fa-door-open"></i>
                        <strong>خروج</strong>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- Navbar -->

    @yield('intro')


</header>
<!-- Main navigation -->

<!-- Main layout -->
<main>

    <div class="container-fluid">

       <div class="row">
           <div class="col-12 pt-5 mt-5"></div>
       </div>

        @yield('body')

        <div class="row">
            <div class="col-12 pt-5 mt-5"></div>
        </div>

    </div>

</main>
<!-- Main layout -->

<!-- Footer -->
{{--<footer class="page-footer font-small special-color-dark ">--}}

{{--    <!-- Footer Text -->--}}
{{--    <div class="container-fluid text-center text-md-left">--}}

{{--        <!-- Grid row -->--}}
{{--        <div class="row">--}}

{{--            <!-- Grid column -->--}}
{{--            <div class="col-md-6 mt-md-0 mt-3 text-center">--}}

{{--                <!-- Content -->--}}
{{--                <h5 class="text-uppercase font-weight-bold">شماره تلفن :</h5>--}}
{{--                <p>--}}
{{--                    034 3424 2424--}}
{{--                </p>--}}

{{--            </div>--}}
{{--            <!-- Grid column -->--}}

{{--            <hr class="clearfix w-100 d-md-none pb-3">--}}

{{--            <!-- Grid column -->--}}
{{--            <div class="col-md-6 mb-md-0 mb-3 text-center">--}}

{{--                <!-- Content -->--}}
{{--                <h5 class="text-uppercase font-weight-bold">آدرس :</h5>--}}
{{--                <p>--}}
{{--                    کرمان-رفسنجان-مدرس و ...--}}
{{--                </p>--}}

{{--            </div>--}}
{{--            <!-- Grid column -->--}}

{{--        </div>--}}
{{--        <!-- Grid row -->--}}

{{--    </div>--}}
{{--    <!-- Footer Text -->--}}

{{--    <!-- Copyright -->--}}
{{--    <div class="footer-copyright text-center py-3">--}}
{{--        <a href="http://amirranjbar78.ir">--}}
{{--            <img src="{{asset('images/logo.png')}}" alt="amirRanjbar" style="width: 50px ; height: 50px">--}}
{{--        </a>--}}
{{--    </div>--}}
{{--    <!-- Copyright -->--}}

{{--</footer>--}}
<!-- Footer -->


{{-- start mdb js --}}
<script type="text/javascript" src="{{asset('home/js/popper.min.js')}}"></script>
<script type="text/javascript" src="{{asset('home/js/bootstrap.js')}}"></script>
<script type="text/javascript" src="{{asset('home/js/mdb.js')}}"></script>
{{-- end mdb js --}}

@yield('script')
<script>
    @if(session('adminAlert'))
        @if(session('adminAlert')[0] == false)
        toastr.error("{{session('adminAlert')[1]}}",'خطا') ;
        @elseif(session('adminAlert')[0] == true)
        toastr.success("{{session('adminAlert')[1]}}",'اطلاعیه') ;
        @else
        toastr.info("{{session('adminAlert')[1]}}",'اطلاعیه') ;
        @endif
    @endif
</script>

</body>

</html>
