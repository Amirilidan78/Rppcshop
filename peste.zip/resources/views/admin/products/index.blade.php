@extends('admin.layout.master')

@section('style')
    <style>
        th,td{
            text-align: center !important;
        }
    </style>


    <x-db-table-config/>


    <script>
        $(document).ready(function () {
            $('#table1').DataTable();
            $('#table2').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });
    </script>

    <style>
        ul>li{
            text-align: right !important;
            direction: rtl !important;
        }
    </style>

@stop
@section('body')


    <div class="modal fade" id="deleteProduct" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">حذف محصول</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-times fa-4x animated rotateIn"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn  btn-outline-danger" data-dismiss="modal">بستن</a>
                    <button  class="btn  btn-danger waves-effect"  onclick="productDelete()" >تایید</button>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


    <div class="modal fade" id="deleteGroup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">حذف گروه</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-times fa-4x animated rotateIn"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn  btn-outline-danger" data-dismiss="modal">بستن</a>
                    <button  class="btn  btn-danger waves-effect"  onclick="groupDelete()" >تایید</button>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


    <form action="{{ route('admin.group.update') }}" method="post"> @csrf
        <div class="modal fade" id="editGroup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-notify modal-warning" role="document">
                <!--Content-->
                <div class="modal-content text-center">
                    <!--Header-->
                    <div class="modal-header d-flex justify-content-center">
                        <p class="heading">ویرایش گروه</p>
                    </div>

                    <!--Body-->
                    <div class="modal-body text-center">

                        <input type="hidden" name="id" id="group_id">
                        <div class="row justify-content-center">
                            <div class="col-lg-10 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >نام </span>
                                </div>
                                <input type="text" class="form-control" name="name" id="group_name">
                            </div>
                        </div>

                    </div>

                    <!--Footer-->
                    <div class="modal-footer flex-center">
                        <a  class="btn  btn-outline-warning" data-dismiss="modal">بستن</a>
                        <button  class="btn  btn-warning waves-effect"  type="submit" >تایید</button>
                    </div>
                </div>
                <!--/.Content-->
            </div>
        </div>
    </form>



    <div class="row justify-content-center">
        <div class="col-lg-10">
            <ul class="nav nav-tabs md-tabs mt-2 primary-color" id="myTabMD" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#all" role="tab" aria-controls="home-md"
                       aria-selected="true"> محصولات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#groups" role="tab" aria-controls="contact-md"
                       aria-selected="false"> گروه ها</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#add" role="tab" aria-controls="contact-md"
                       aria-selected="false">افزودن محصول</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#addGroup" role="tab" aria-controls="contact-md"
                       aria-selected="false">افزودن گروه  </a>
                </li>
            </ul>
            <div class="tab-content card pt-5" id="myTabContentMD">


                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">

                    <?php
                        $table = [
                            '#',
                            'نام محصول',
                            'گروه',
                            'قیمت',
                            'قیمت با تخفیف',
                            'وزن',
                            'نوع فرآورده',
                            'نوع بسته بندی',
                            'تعداد موجود',
                            'عملیات',
                        ]
                        ?>
                        <x-dbTable id="table1" :items="$table">
                            @foreach($all as $product)
                                <tr>
                                    <td>
                                    <span class="Bkoodak">
                                        {{$product->id}}
                                    </span>
                                    </td>

                                    <td class="animated fadeInDown">{{$product->Name}}</td>
                                    <td class="animated fadeInDown">{{$product->group->name}}</td>
                                    <td class="Bkoodak animated fadeInDown">
                                        <x-price :price="$product->price"/>
                                    </td>
                                    <td class="Bkoodak animated fadeInDown">
                                        @if($product->price_off) <x-price :price="$product->price_off"/> @else ثبت نشده @endif
                                    </td>
                                    <td class="Bkoodak animated fadeInDown"><span class="Bkoodak">{{$product->weight}}</span><span>گرم</span></td>
                                    <td class="Bkoodak animated fadeInDown">{{ $product->getPersianSalty() }}</td>
                                    <td class="Bkoodak animated fadeInDown">{{ $product->getPersianPacking() }}</td>
                                    <td class="Bkoodak animated fadeInDown" >{{$product->count}}</td>
                                    <td>
                                        <a href="{{ route('admin.product.edit',$product->id) }}" class="btn btn-rounded btn-md btn-warning animated fadeInDown"  >
                                            ویرایش
                                        </a>
                                        <a  class="btn btn-rounded btn-danger btn-md animated fadeInDown"    onclick="showDeleteModalProduct({{$product->id}})" >
                                            حذف
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </x-dbTable>

                </div>



                <div class="tab-pane fade" id="groups" role="tabpanel" aria-labelledby="groups">

                    <div class="row justify-content-center">
                        <div class="col-lg-10">

                            <?php
                            $table = [
                                '#',
                                'نام گروه',
                                'ویرایش',
                                'حذف',
                            ]
                            ?>
                            <x-dbTable id="table2" :items="$table">
                                @foreach($groups as $group)
                                    <tr>
                                        <td>
                                            <span class="Bkoodak">
                                                {{$group->id}}
                                            </span>
                                        </td>
                                        <td class="animated fadeInDown">
                                             <span>
                                                 {{$group->name}}
                                             </span>
                                        </td>
                                        <td>
                                            <a  class="btn btn-rounded btn-md btn-warning animated fadeInDown" onclick="showEditModalGroup('{{$group->id}}' , '{{$group->name}}')" >
                                                ویرایش
                                            </a>
                                        </td>
                                        <td>
                                            <a  class="btn btn-rounded btn-danger btn-md animated fadeInDown" onclick="showDeleteModalGroup({{$group->id}})" >
                                                حذف
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </x-dbTable>


                        </div>
                    </div>

                </div>



                <div class="tab-pane fade" id="add" role="tabpanel" aria-labelledby="add">

                    <div class="row justify-content-center">
                        <div class="col-lg-10">

                            <form action="{{ route('admin.product.store') }}" method="post" id="form" enctype="multipart/form-data"> @csrf
                                <div class="row justify-content-center">

                                    <div class="col-lg-4 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >نام محصول</span>
                                        </div>
                                        <input type="text" class="form-control" name="Name">
                                    </div>

                                    <div class="col-lg-4 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >url</span>
                                        </div>
                                        <input type="text" class="form-control" name="url" placeholder="english plz">
                                    </div>


                                    <div class="col-lg-4 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >گروه محصول</span>
                                        </div>
                                        <select  class="mdb-select md-form" name="group_id" >
                                            @foreach($groups as $group)
                                                <option value="{{$group->id}}" >
                                                    {{$group->name}}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-12" style="height: 50px"></div>

                                    <div class="col-lg-1"></div>
                                    <div class="col-lg-11 md-form input-group mb-3 ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >توضیحات محصول</span>
                                        </div>
                                        <div>
                                            <div id="toolbar-container"></div>
                                            <div id="editor">
                                                <p>توضیحات محصول</p>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="description" id="text">

                                    <div class="col-12" style="height: 50px"></div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown" >قیمت</span>
                                        </div>
                                        <input type="number" class="form-control" name="price">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >تومان</span>
                                        </div>
                                    </div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown" >قیمت با تخفیف</span>
                                        </div>
                                        <input type="number" class="form-control" name="price_off">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >تومان</span>
                                        </div>
                                    </div>

                                    <div class="col-12" style="height: 50px"></div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown" >وزن</span>
                                        </div>
                                        <input type="number" class="form-control" name="weight" >
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >گرم</span>
                                        </div>
                                    </div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نوع فرآرده</span>
                                        </div>
                                        <select  class="mdb-select md-form" name="is_salty" >
                                            <option value="1"  selected> شور  </option>
                                            <option value="0" > خام  </option>
                                        </select>
                                    </div>

                                    <div class="col-12" style="height: 50px"></div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نوع بسته بندی</span>
                                        </div>
                                        <select  class="mdb-select md-form" name="type_packing" >
                                            <option value="1"  selected> سلوفون  </option>
                                            <option value="2" > قوطی  </option>
                                            <option value="3" > جعبه  </option>
                                            <option value="4" > کارتون  </option>
                                        </select>
                                    </div>

                                    <div class="col-lg-5 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown" >تعداد</span>
                                        </div>
                                        <input type="number" class="form-control" name="count" >
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown" >عدد</span>
                                        </div>
                                    </div>

                                    <div class="col-12" style="height: 50px"></div>

                                    <div class="col-lg-4">
                                        <span class=" md-addon animated fadeInDown" >عکس های  محصول</span>
                                    </div>
                                    <div class="col-lg-8"></div>

                                    <div class="col-lg-4">
                                        <div class="file-field big">
                                            <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                                <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                                <input type="file" name="pic1" >
                                            </a>
                                            <div class="file-path-wrapper">
                                                <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="file-field big">
                                            <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                                <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                                <input type="file" name="pic2" >
                                            </a>
                                            <div class="file-path-wrapper">
                                                <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="file-field big">
                                            <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                                <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                                <input type="file" name="pic3" >
                                            </a>
                                            <div class="file-path-wrapper">
                                                <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-lg-12 text-center">
                                        <button class="btn btn-success btn-rounded  animated fadeInDown" type="submit">
                                            ذخیره
                                        </button>
                                    </div>

                                </div>
                            </form>


                        </div>
                    </div>

                </div>

                <div class="tab-pane fade" id="addGroup" role="tabpanel" aria-labelledby="addGroup">

                    <div class="row justify-content-center">
                        <div class="col-lg-10">

                            <form action="{{ route('admin.group.store') }}" method="POST"> @csrf

                                <div class="row">

                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >نام گروه</span>
                                        </div>
                                        <input type="text" class="form-control" name="name">
                                    </div>

                                    <div class="col-lg-6"></div>

                                    <div class="col-12 text-right">
                                        <button class="btn btn-success btn-rounded" type="submit">ثبت</button>
                                    </div>

                                </div>


                            </form>


                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>


    <div id="mdb-lightbox-ui"></div>
@stop


@section('script')
    <script>
        $(function () {
            $("#mdb-lightbox-ui").load("{{url('home/mdb-addons/mdb-lightbox-ui.html')}}");
        });
    </script>

    <script>
        var parent_id ;

        function showDeleteModalProduct(id) {

            $('#deleteProduct').modal('show');
            parent_id = id ;
        }
        function showDeleteModalGroup(id) {

            $('#deleteGroup').modal('show');
            parent_id = id ;
        }
        function showEditModalGroup(id,name) {

            $('#editGroup').modal('show');
            $("#group_id").val(id) ;
            $("#group_name").val(name) ;
        }

        function productDelete() {
            id = parent_id;
            window.location.href = "{{url('/admin/products/delete/')}}"+'/'+id;
        }

        function groupDelete() {
            id = parent_id;
            window.location.href = "{{url('/admin/groups/destroy/')}}"+'/'+id;
        }
    </script>

    <script>
        // Material Select Initialization
        $(document).ready(function() {
            $('.mdb-select').materialSelect();
            $(".caret").hide();
        });

    </script>

    <script src='{{ asset('js/ckeditor5/index.js') }}'></script>
    <script>
        DecoupledEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                const toolbarContainer = document.querySelector( '#toolbar-container' );

                toolbarContainer.appendChild( editor.ui.view.toolbar.element );
            } )
            .catch( error => {
                console.error( error );
            } );

        $( "#form" ).submit(function( event ) {
            $( "#text" ).val($( "#editor" ).html());
        });
    </script>

@stop
