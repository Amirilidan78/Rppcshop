@extends('admin.layout.master')

@section('style')


@stop
@section('body')

    <div class="container-fluid">

        <div class="row justify-content-center" >
            <div class="col-lg-10">

                <div class="card py-4 px-3">
                    <h5 class="text-black-50">
                        ویرایش محصول
                        <span class="Bkoodak">
                            {{ $product->Name }}
                        </span>
                    </h5>

                    <div class="row justify-content-center">
                        <div class="col-lg-3 text-center justify-content-center center align-content-center">
                            <div class="mdb-lightbox text-center justify-content-center center align-content-center">
                                <div class="col-12 text-center justify-content-center center align-content-center">
                                    <figure  class="text-center justify-content-center center align-content-center">
                                        <a href="{{ ( $product->pic1 ) ? asset($product->pic1) : asset('images/placeHolder.jpg') }}" class="text-center justify-content-center center align-content-center" data-size="1600x1067">
                                            <img src="{{ ( $product->pic1 ) ? asset($product->pic1) : asset('images/placeHolder.jpg') }}" class="img-fluid" />
                                        </a>
                                    </figure>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 text-center justify-content-center center align-content-center">
                            <div class="mdb-lightbox text-center justify-content-center center align-content-center">
                                <div class="col-12 text-center justify-content-center center align-content-center">
                                    <figure  class="text-center justify-content-center center align-content-center">
                                        <a href="{{ ( $product->pic2 ) ? asset($product->pic2) : asset('images/placeHolder.jpg') }}" class="text-center justify-content-center center align-content-center" data-size="1600x1067">
                                            <img src="{{ ( $product->pic2 ) ? asset($product->pic2) : asset('images/placeHolder.jpg') }}" class="img-fluid" />
                                        </a>
                                    </figure>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 text-center justify-content-center center align-content-center">
                            <div class="mdb-lightbox text-center justify-content-center center align-content-center">
                                <div class="col-12 text-center justify-content-center center align-content-center">
                                    <figure  class="text-center justify-content-center center align-content-center">
                                        <a href="{{ ( $product->pic3 ) ? asset($product->pic3) : asset('images/placeHolder.jpg') }}" class="text-center justify-content-center center align-content-center" data-size="1600x1067">
                                            <img src="{{ ( $product->pic3 ) ? asset($product->pic3) : asset('images/placeHolder.jpg') }}" class="img-fluid" />
                                        </a>
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>

                    <form action="{{ route('admin.product.update',[$product->id]) }}" method="post" id="form" enctype="multipart/form-data">@csrf
                        <div class="row justify-content-around">

                            <div class="col-lg-4 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >نام محصول</span>
                                </div>
                                <input type="text" class="form-control" name="Name" value="{{ $product->Name }}">
                            </div>

                            <div class="col-lg-4 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >url</span>
                                </div>
                                <input type="text" class="form-control" name="url" placeholder="english plz" value="{{ $product->english_name }}">
                            </div>


                            <div class="col-lg-4 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown"  >گروه محصول</span>
                                </div>
                                <select  class="mdb-select md-form" name="group_id" >
                                    @foreach($groups as $group)
                                        <option {{ ($product->group_id == $group) ? 'selected' : "" }} value="{{$group->id}}" >
                                            {{$group->name}}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-12" style="height: 50px"></div>

                            <div class="col-lg-1"></div>
                            <div class="col-lg-11 md-form input-group mb-3 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >توضیحات محصول</span>
                                </div>
                                <div>
                                    <div id="toolbar-container"></div>
                                    <div id="editor" >
                                        <p>{!! $product->description !!}</p>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="description" id="text">

                            <div class="col-12" style="height: 50px"></div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown" >قیمت</span>
                                </div>
                                <input type="number" class="form-control" name="price" value="{{ $product->price }}">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >تومان</span>
                                </div>
                            </div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown" >قیمت با تخفیف</span>
                                </div>
                                <input type="number" class="form-control" name="price_off" value="{{ $product->price_off }}">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >تومان</span>
                                </div>
                            </div>

                            <div class="col-12" style="height: 50px"></div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown" >وزن</span>
                                </div>
                                <input type="number" class="form-control" name="weight" value="{{ $product->weight }}">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >گرم</span>
                                </div>
                            </div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown"  >نوع فرآرده</span>
                                </div>
                                <select  class="mdb-select md-form" name="is_salty" >
                                    <option value="1"  {{ ($product->is_salty) ? 'selected' : "" }}> شور  </option>
                                    <option value="0" {{ (!$product->is_salty) ? 'selected' : "" }} > خام  </option>
                                </select>
                            </div>

                            <div class="col-12" style="height: 50px"></div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown"  >نوع بسته بندی</span>
                                </div>
                                <select  class="mdb-select md-form" name="type_packing" >
                                    <option value="1" {{ ($product->type_packing == 1) ? 'selected' : "" }} > سلوفون  </option>
                                    <option value="2" {{ ($product->type_packing == 2) ? 'selected' : "" }}> قوطی  </option>
                                    <option value="3" {{ ($product->type_packing == 3) ? 'selected' : "" }}> جعبه  </option>
                                    <option value="4" {{ ($product->type_packing == 4) ? 'selected' : "" }}> کارتن  </option>
                                </select>
                            </div>

                            <div class="col-lg-5 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown" >تعداد</span>
                                </div>
                                <input type="number" class="form-control" name="count" value="{{ $product->count }}">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon  animated fadeInDown" >عدد</span>
                                </div>
                            </div>

                            <div class="col-12" style="height: 50px"></div>

                            <div class="col-lg-4">
                                <span class=" md-addon animated fadeInDown" >عکس های  محصول</span>
                            </div>
                            <div class="col-lg-8"></div>

                            <div class="col-lg-4">
                                <div class="file-field big">
                                    <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                        <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                        <input type="file" name="pic1" >
                                    </a>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="file-field big">
                                    <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                        <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                        <input type="file" name="pic2" >
                                    </a>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="file-field big">
                                    <a class="btn-floating btn-lg primary-color lighten-1 mt-0 float-left">
                                        <i class="fas fa-paperclip text-white" aria-hidden="true"></i>
                                        <input type="file" name="pic3" >
                                    </a>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate"  type="text" placeholder="عکسی آپلود نشده">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-10 text-center mt-2">
                                <button type="submit" class="btn btn-warning btn-rounded" >ویرایش</button>
                            </div>

                        </div>
                    </form>

                </div>

            </div>
        </div>

    </div>

@stop


@section('script')

    <script>
        // Material Select Initialization
        $(document).ready(function() {
            $('.mdb-select').materialSelect();
            $(".caret").hide();
        });

    </script>

    <script src='{{ asset('js/ckeditor5/index.js') }}'></script>
    <script>
        DecoupledEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                const toolbarContainer = document.querySelector( '#toolbar-container' );

                toolbarContainer.appendChild( editor.ui.view.toolbar.element );
            } )
            .catch( error => {
                console.error( error );
            } );

        $( "#form" ).submit(function( event ) {
            $( "#text" ).val($( "#editor" ).html());
        });
    </script>
@stop
