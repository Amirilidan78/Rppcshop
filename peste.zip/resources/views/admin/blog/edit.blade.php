@extends('admin.layout.master')

@section('style')


@stop
@section('body')

    <div class="container-fluid">

        <div class="row justify-content-center" >
            <div class="col-lg-10">

                <div class="card py-4 px-3">
                    <h5 class="text-black-50">
                        ویرایش پست
                    </h5>

                    <div class="row justify-content-center">
                        <div class="col-lg-3 text-center justify-content-center center align-content-center">
                            <div class="mdb-lightbox text-center justify-content-center center align-content-center">
                                <div class="col-12 text-center justify-content-center center align-content-center">
                                    <figure  class="text-center justify-content-center center align-content-center">
                                        <a href="{{ ( $post->image ) ? asset($post->image) : asset('images/placeHolder.jpg') }}" class="text-center justify-content-center center align-content-center" data-size="1600x1067">
                                            <img src="{{ ( $post->image ) ? asset($post->image) : asset('images/placeHolder.jpg') }}" class="img-fluid" />
                                        </a>
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>

                    <form action="{{ route('admin.post.update',$post->id) }}" method="post" id="form" enctype="multipart/form-data">@csrf
                        <div class="row justify-content-around">

                            <input type="hidden" name="text" id="text">

                            <div class="col-lg-8 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >عنوان پست </span>
                                </div>
                                <input type="text" class="form-control" name="title"  value="{{ $post->title }}">
                            </div>

                            <div class="col-lg-8 md-form input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text md-addon animated fadeInDown" >متن پست</span>
                                </div>
                                <div>
                                    <div id="toolbar-container"></div>
                                    <div id="editor" >
                                        {!! $post->text !!}
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-8 md-form input-group mb-3">
                                <div class="file-field">
                                    <div class="btn btn-primary btn-sm float-left">
                                        <span>تصویر پست</span>
                                        <input type="file" name="file">
                                    </div>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate" type="text" placeholder="آپلود">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-10 text-center mt-2">
                                <button type="submit" class="btn btn-warning btn-rounded" >ویرایش</button>
                            </div>

                        </div>
                    </form>

                </div>

            </div>
        </div>

    </div>

@stop


@section('script')

    <script>
        // Material Select Initialization
        $(document).ready(function() {
            $('.mdb-select').materialSelect();
            $(".caret").hide();
        });

    </script>

    <script src='{{ asset('js/ckeditor5/index.js') }}'></script>
    <script>
        DecoupledEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                const toolbarContainer = document.querySelector( '#toolbar-container' );

                toolbarContainer.appendChild( editor.ui.view.toolbar.element );
            } )
            .catch( error => {
                console.error( error );
            } );

        $( "#form" ).submit(function( event ) {
            $( "#text" ).val($( "#editor" ).html());
        });
    </script>
@stop
