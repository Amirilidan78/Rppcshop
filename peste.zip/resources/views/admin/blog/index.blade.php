@extends('admin.layout.master')

@section('style')
    <!-- DataTables CSS -->
    <link href="{{ asset('Home/css/addons/datatables.min.css') }}" rel="stylesheet">
    <!-- DataTables JS -->
    <script src="{{ asset('Home/js/addons/datatables.min.js') }}" type="text/javascript"></script>

    <!-- DataTables Select CSS -->
    <link href="{{ asset('Home/css/addons/datatables-select.min.css') }}" rel="stylesheet">
    <!-- DataTables Select JS -->
    <script src="{{ asset('Home/js/addons/datatables-select.min.js') }}" type="text/javascript"></script>
@stop
@section('body')

    @foreach($posts as $post)
        @include('components.modals.delete' , [
            'id' => 'delete'.$post->id ,
            'title' => 'حذف پست!؟' ,
            'deleteUrl' => route('admin.post.delete',$post->id) ,
        ])
    @endforeach
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <ul class="nav nav-tabs md-tabs mt-2 primary-color" id="myTabMD" role="tablist">

                <li class="nav-item">
                    <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#all" role="tab" aria-controls="home-md"
                       aria-selected="true">همه</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#add" role="tab" aria-controls="contact-md"
                       aria-selected="false">پست جدید</a>
                </li>

            </ul>
            <div class="tab-content card pt-5" id="myTabContentMD">


                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">

                    @foreach($posts as $post)

                        <div class="row">
                            <div class="col-lg-1"></div>
                            <div class="col-lg-8 col-md-10 mb-4">

                                <!-- News card -->
                                <div class="card  mb-3 text-center hoverable">

                                    <div class="card-body">

                                        <!-- Grid row -->
                                        <div class="row">

                                            <!-- Grid column -->
                                            <div class="col-md-6 text-left ml-xl-3 ml-lg-0 ml-md-3 mt-3 text-right">

                                                <h4 class="mb-4 text-right">

                                                    <strong>{!! $post->title !!}</strong>

                                                </h4>

                                                <p class="dark-grey-text text-right">
                                                    {!! $post->text !!}
                                                </p>

                                                <p>

                                                <div class="mt-2">
                                                    <span >
                                                            تاریخ ثبت
                                                            :
                                                        </span>
                                                    <span class="Bkoodak" style="font-size: 17px">
                                                            {{$post->Created_at}}
                                                        </span>
                                                </div>
                                                </p>

                                                <a class="btn btn-danger btn-md" data-toggle="modal"  data-target="#{{'delete'.$post->id}}">حذف</a>
                                                <a class="btn btn-warning btn-md" href="{{ route('admin.post.edit',$post->id) }}" >ویرایش</a>

                                            </div>

                                            <div class="col-md-5 mx-3 my-3">
                                                <div class="view overlay rgba-white-slight">
                                                    <img src="{{ ( $post->image ) ? asset("{$post->image}") : asset("images/placeHolder.jpg")}}"
                                                         class="img-fluid rounded-bottom" alt="Sample image for first version of blog listing">
                                                    <a>
                                                        <div class="mask"></div>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>
                                        <!-- Grid row -->

                                    </div>

                                </div>
                                <!-- News card -->

                            </div>
                        </div>
                    @endforeach


                    <div class="row">
                        <div class="col-12">
                            {{$posts->links('components.paginate.index')}}
                        </div>
                    </div>

                </div>


                <div class="tab-pane fade  " id="add" role="tabpanel" aria-labelledby="all">

                    <div class="row justify-content-center">
                        <div class="col-lg-10">


                            <form action="{{ route('admin.post.add') }}" method="post" id="form" enctype="multipart/form-data"> @csrf

                                <input type="hidden" name="text" id="text">

                                <div class="col-lg-8 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon animated fadeInDown" >عنوان پست </span>
                                    </div>
                                    <input type="text" class="form-control" name="title" id="title">
                                </div>

                                <div class="col-lg-8 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon animated fadeInDown" >متن پست</span>
                                    </div>
                                    <div>
                                        <div id="toolbar-container"></div>
                                        <div id="editor">
                                            <p>متن پست</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="file-field">
                                            <div class="btn btn-primary btn-sm float-left">
                                                <span>تصویر پست</span>
                                                <input type="file" name="file">
                                            </div>
                                            <div class="file-path-wrapper">
                                                <input class="file-path validate" type="text" placeholder="آپلود">
                                            </div>
                                        </div>
                                </div>

                                <button class="btn btn-success btn-rounded" type="submit"> ثبت </button>

                            </form>


                        </div>
                    </div>

                </div>



            </div>
        </div>
    </div>




@stop


@section('script')
    <script src='{{ asset('js/ckeditor5/index.js') }}'></script>
    <script>
        DecoupledEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                const toolbarContainer = document.querySelector( '#toolbar-container' );

                toolbarContainer.appendChild( editor.ui.view.toolbar.element );
            } )
            .catch( error => {
                console.error( error );
            } );

        $( "#form" ).submit(function( event ) {
            $( "#text" ).val($( "#editor" ).html());
        });
    </script>
@stop
