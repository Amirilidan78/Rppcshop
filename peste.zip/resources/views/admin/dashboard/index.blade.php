@extends('admin.layout.master')

@section('style')
    <style>
        .Bkoodak {
            font-size: 22px ;
        }
    </style>
@stop
@section('body')



    <div class="row justify-content-center pt-2">


        <div class="col-lg-5">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-header unique-color text-center">
                        <h5 class="text-center text-white">
                            سفارش این هفته
                        </h5>
                    </div>

                    <div class="text-center">
                        <canvas id="myChart" ></canvas>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-lg-5">
            <div class="card mt-5">
                <div class="card-body">
                    <div class="form-header unique-color text-center">
                        <h5 class="text-center text-white">
                            بازدید سایت در هفته ی گذشته
                        </h5>
                    </div>

                    <div class="text-center">
                        <canvas id="lineChart"></canvas>
                    </div>
                </div>
            </div>
        </div>


    </div>



@stop


@section('script')


    <script>
        //bar
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [
                    @foreach($orders as $order)
                        @if( \Morilog\Jalali\Jalalian::fromDateTime($order->date)->isToday() )
                            "امروز" ,
                        @elseif( \Morilog\Jalali\Jalalian::fromDateTime($order->date)->isYesterday() )
                            "دیروز" ,
                        @else
                            "{{ explode(' ' , \Morilog\Jalali\Jalalian::fromDateTime($order->date))[0] }}",
                        @endif
                    @endforeach
                ],
                datasets: [{
                    label: 'سفارش',
                    data: [
                        @foreach($orders as $order)
                            "{{$order->total}}",
                        @endforeach
                    ],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgb(145,255,135)',
                        'rgb(255,244,172)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgb(145,255,135)',
                        'rgb(255,244,172)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>



    <script>
        //line
        var ctxL = document.getElementById("lineChart").getContext('2d');
        var myLineChart = new Chart(ctxL, {
            type: 'line',
            data: {
                labels: [
                    "هفت روز پیش",
                    "شش روز پیش",
                    "پنج روز پیش",
                    "چهار روز پیش",
                    "سه روز پیش",
                    "دو روز پیش",
                    "دیروز",
                    "امروز",
                ],
                datasets: [{
                    label: "بازدید",
                    data: [10, 20, 40, 6, 30, 4, 25 ,4, 25],
                    backgroundColor: [
                        'rgba(105, 0, 132, .2)',
                    ],
                    borderColor: [
                        'rgba(200, 99, 132, .7)',
                    ],
                    borderWidth: 2
                },
                    // {
                    //     label: "My Second dataset",
                    //     data: [28, 48, 40, 19, 86, 27, 90],
                    //     backgroundColor: [
                    //         'rgba(0, 137, 132, .2)',
                    //     ],
                    //     borderColor: [
                    //         'rgba(0, 10, 130, .7)',
                    //     ],
                    //     borderWidth: 2
                    // }
                ]
            },
            options: {
                responsive: true
            }
        });
    </script>



@stop
