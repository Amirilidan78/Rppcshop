@extends('admin.layout.master')

@section('style')
    <x-db-table-config/>
@stop
@section('body')


    <div class="row justify-content-center">
        <div class="col-lg-10">
            <ul class="nav nav-tabs md-tabs mt-2 primary-color" id="myTabMD" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#all" role="tab" aria-controls="home-md"
                       aria-selected="true">همه</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#edit" role="tab" aria-controls="contact-md"
                       aria-selected="false">ویرایش</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab-md" data-toggle="tab" href="#add" role="tab" aria-controls="contact-md"
                       aria-selected="false">کاربر جدید</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"   href="{{ route('admin.user.excel') }}"
                       >Excel</a>
                </li>
            </ul>
            <div class="tab-content card pt-5" id="myTabContentMD">


                <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">

                    @if(count($all) > 0)
                        <x-db-table :items="['نام','نام خانوادگی','ایمیل','شماره همراه','حذف']">
                            @foreach($all as $user)
                                <tr>
                                    <td>{{$user->name}}</td>
                                    <td>{{$user->last_name}}</td>
                                    <td>{{$user->email}}</td>
                                    <td>{{$user->phone}}</td>
                                    <td><button class="btn btn-danger btn-sm" onclick="showDeleteModal({{$user->id}})">حذف</button></td>
                                </tr>
                            @endforeach
                        </x-db-table >
                    @else
                        <h5 class="text-center">
                            ثبت نشده
                        </h5>
                    @endif

                </div>



                <div class="tab-pane fade" id="edit" role="tabpanel" aria-labelledby="dis_active">

                    <div class="row justify-content-center" id="formModify">
                        <div class="col-lg-4 text-center">
                            <span>
                                شماره تلفن کاربر
                            </span>
                            <br>
                            <br>
                            <input type="text" class="form-control Bkoodak text-center mt-2" name="phone" id="modifyPhone" >
                            <br>
                            <button class="btn-info btn" onclick="searchUser()">
                                جستجو
                            </button>
                        </div>
                    </div>


                    <div class="row justify-content-center" id="userModify" style="display: none">

                        <form action="{{ route('admin.users.modify') }}" method="POST"> @csrf
                            <div class="row">

                                <div class="col-lg-6 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon animated fadeInDown" >نام </span>
                                    </div>
                                    <input type="text" class="form-control" name="name" id="name_modify">
                                </div>
                                <div class="col-lg-6"></div>

                                <div class="col-lg-6 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon  animated fadeInDown"  >  نام خانوادگی </span>
                                    </div>
                                    <input type="text" class="form-control Bkoodak" name="last_name" id="last_name_modify">
                                </div>
                                <div class="col-lg-6"></div>

                                <div class="col-lg-6 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon  animated fadeInDown"  > شماره همراه  </span>
                                    </div>
                                    <input type="text" class="form-control Bkoodak"  id="phone_modify" disabled>
                                    <input type="hidden" name="phone" id="phone_modify_hidden">
                                </div>
                                <div class="col-lg-6"></div>


                                <div class="col-lg-6 md-form input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text md-addon  animated fadeInDown"  >ایمیل</span>
                                    </div>
                                    <input type="text" class="form-control Bkoodak" name="code_melli" id="code_melli_modify">
                                </div>
                                <div class="col-lg-6"></div>



                                <div class="col-lg-4">
                                    <button type="submit" class="btn btn-success btn-rounded  animated fadeInDown">
                                        ذخیره
                                    </button>
                                </div>
                                <div class="col-lg-8"></div>
                            </div>
                        </form>

                    </div>


                </div>


                <div class="tab-pane fade" id="add" role="tabpanel" aria-labelledby="add">

                    <form action="{{ route('admin.users.store') }}" method="POST"> @csrf
                        <div class="row justify-content-center">
                            <div class="col-lg-10">

                                <div class="row">

                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon animated fadeInDown" >نام </span>
                                        </div>
                                        <input type="text" class="form-control" name="name">
                                    </div>
                                    <div class="col-lg-6"></div>

                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >  نام خانوادگی </span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="last_name">
                                    </div>
                                    <div class="col-lg-6"></div>

                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  > شماره همراه  </span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="phone">
                                    </div>
                                    <div class="col-lg-6"></div>


                                    <div class="col-lg-6 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >ایمیل</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="code_melli">
                                    </div>
                                    <div class="col-lg-6"></div>



                                     <div class="col-lg-6 md-form input-group mb-3">
                                         <div class="input-group-prepend">
                                             <span class="input-group-text md-addon  animated fadeInDown"  >رمز عبور</span>
                                         </div>
                                         <input type="password" class="form-control Bkoodak" name="password">
                                    </div>
                                    <div class="col-lg-6"></div>




                                    <div class="col-lg-4">
                                        <button type="submit" class="btn btn-success btn-rounded  animated fadeInDown">
                                            ذخیره
                                        </button>
                                    </div>
                                    <div class="col-lg-8"></div>
                                </div>

                            </div>
                        </div>
                    </form>


                </div>


            </div>
        </div>
    </div>


    <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">حذف کاربر</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-times fa-4x animated rotateIn"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn  btn-outline-danger" data-dismiss="modal">بستن</a>
                    <button  class="btn  btn-danger waves-effect" id="deleteButton" data-delete-id="" onclick="userDelete()" >حذف</button>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


@stop


@section('script')
<script>
        function showDeleteModal(id) {

            $('#delete').modal('show');
            $( "#deleteButton" ).data( "delete-id" , id);
        }

        function userDelete() {

            id = $( "#deleteButton" ).data( "delete-id");
            window.location.href = "{{url('/admin/users/delete/')}}"+'/'+id;
        }
    </script>
    <script>
        function searchUser() {


            $.ajax({
                url: "{{ route('admin.users.search') }}",
                type: "POST",
                async: true,
                cache: false,
                data: {
                    phone : $("#modifyPhone").val() ,
                    _token: "{{ csrf_token() }}"
                },
                dataType: 'json',
                success: function (result) {


                    if(result == -1)
                        toastr.error('شماره همراه نمیتواند خالی باشد','خطا');
                    else if(result == -2)
                        toastr.error('با این شماره همراه کاربری ثبت نشده','خطا');
                    else{

                        $("#formModify").hide();
                        $("#userModify").fadeIn();

                        $("#name_modify").val(result['name']);
                        $("#last_name_modify").val(result['last_name']);
                        $("#phone_modify").val(result['phone']);
                        $("#phone_modify_hidden").val(result['phone']);
                        $("#code_melli_modify").val(result['code_melli']);



                    }

                }
            });

        }
    </script>
@stop
