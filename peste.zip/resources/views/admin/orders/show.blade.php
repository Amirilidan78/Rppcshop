@extends('admin.layout.master')

@section('style')



@stop
@section('body')


    <div class="row justify-content-center mt-5">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">
                        سفارش
                        {{ $order->getOrderId() }}
                    </h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <div class="card px-3 py-3 my-4">
                        <div class="row">


                            <div class="col-lg-12 text-center py-3">
                                <span>وضعیت سفارش</span>
                                :
                                <span class="h6 text-success">{{$order->getStep()}}</span>
                            </div>


                        </div>
                    </div>

                    <div class="card px-3 py-3 my-4">
                        <div class="row">


                            <div class="col-lg-6 text-center py-3">
                                <span>خریدار</span>
                                :
                                <span class="h6">{{$user->name.' '.$user->last_name}}</span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شماره همراه</span>
                                :
                                <span class=" Bkoodak h6 ">{{$user->phone}}</span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>استان</span>
                                :
                                <span class=" Bkoodak h6 ">{{$post->ostan}}</span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شهر</span>
                                :
                                <span class=" Bkoodak h6 ">{{$post->city}}</span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>کد پستی</span>
                                :
                                <span class=" Bkoodak h6 ">{{$post->post_code}}</span>
                            </div>

                            <div class="col-lg-6 text-center py-3">
                                <span>شماره ثابت</span>
                                :
                                <span class=" Bkoodak h6 ">{{$post->number}}</span>
                            </div>


                            <div class="col-lg-12 text-center py-3">
                                <span>آدرس</span>
                                :
                                <span class=" Bkoodak h6 ">{{$post->address}}</span>
                            </div>

                            <div class="col-lg-12 text-center py-3">
                                <span>نوع ارسال</span>
                                :
                                <span class=" Bkoodak h6 ">{{$order->getSendType()}}</span>
                            </div>


                        </div>
                    </div>

                    @if($factor)
                        <div class="card px-3 py-3 mt-3">
                            <div class="row">
                                <div class="col-lg-12 text-center py-3">
                                    <span>سریال پرداخت</span>
                                    :
                                    <span class=" Bkoodak h6 ">{{$factor->ref_id}}</span>
                                </div>
                            </div>
                        </div>
                    @endif

                    @if($order->post_rahgiri)
                        <div class="card px-3 py-3 mt-3">
                            <div class="row">
                                <div class="col-lg-12 text-center py-3">
                                    <span> شماره رهگیری پست</span>
                                    :
                                    <span class=" Bkoodak h6 ">{{$order->post_rahgiri}}</span>
                                </div>
                            </div>
                        </div>
                    @endif

                    <div class="table-responsive mt-3">
                        <table class="table product-table table-cart-v-1">

                        <!-- Table head -->
                        <thead>

                        <tr>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>شماره محصول</strong>
                            </th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>محصول</strong>
                            </th>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>تعداد</strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت کل
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                        </tr>

                        </thead>
                        <!-- Table head -->

                        <!-- Table body -->
                        <tbody>

                        @foreach($products as $product)
                            <tr>


                                <td><span>{{$product->product_id}}</span></td>

                                <td> <h6 class="mt-3 animated fadeInDown"> <strong class="">{{$product->product->Name}}</strong> </h6>  </td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown"> <x-price :price="$product->price"/> </span>
                                </td>

                                <td></td>

                                <td class=" animated fadeInDown"> <span class="Bkoodak">{{$product->count}}</span>  </td>

                                <td></td>

                                <td > <span class="Bkoodak animated fadeInDown"> <x-price :price="$product->total_price"/> </span> </td>

                                <td></td>

                            </tr>
                        @endforeach

                        </tbody>
                        <!-- Table body -->

                    </table>
                    </div>


                </div>

            </div>

        </div>
    </div>

@stop


@section('script')




@stop
