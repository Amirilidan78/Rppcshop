@extends('admin.layout.master')

@section('style')

    <x-db-table-config/>


    <script>
        $(document).ready(function () {
            $('#tableStatus1').DataTable();
            $('#tableStatus2').DataTable();
            $('#tableStatus3').DataTable();
            $('#tableStatus4').DataTable();
            $('#tableStatus5').DataTable();
            $('.dataTables_length').addClass('bs-select');
        });
    </script>

@stop
@section('body')


    <div class="modal fade" id="modalDeleteOrder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading"> حذف سفارش ؟ </p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-times fa-4x animated rotateIn"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn  btn-danger waves-effect"  onclick="deleteOrder()">حذف</a>
                    <a type="button"  class="btn  btn-outline-danger" class="btn  btn-danger waves-effect" data-dismiss="modal">لغو</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>


    <!--Modal: modalPush-->
    <div class="modal fade" id="modalStatus1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading"> تایید ثبت پرداخت سفارش </p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-bell fa-4x animated rotateIn mb-4"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn btn-success" onclick="functionStatus(1)">ثبت</a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!--Modal: modalPush-->


    <!--Modal: modalPush-->
    <div class="modal fade" id="modalStatus2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">این سفارش مورد تایید بخش حساب داری است ؟</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-bell fa-4x animated rotateIn mb-4"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn btn-success" onclick="functionStatus(2)">بله</a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!--Modal: modalPush-->


    <!--Modal: modalPush-->
    <div class="modal fade" id="modalStatus3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">این سفارش مورد تایید بخش انبار است</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <i class="fas fa-bell fa-4x animated rotateIn mb-4"></i>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn btn-success" onclick="functionStatus(3)">بله</a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!--Modal: modalPush-->


    <!--Modal: modalPush-->
    <div class="modal fade" id="modalStatus4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">این سفارش تحویل پست داده شد</p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <div class="col-lg-12 md-form input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text md-addon  animated fadeInDown"  >کد رهگیری پست</span>
                        </div>
                        <input type="text" class="form-control Bkoodak"  id="post_code">
                    </div>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn btn-success" onclick="functionStatusPost()">بله</a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!--Modal: modalPush-->


    <!--Modal: modalPush-->
    <div class="modal fade" id="modalStatus5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-notify modal-success" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading">  تحویل کاربر </p>
                </div>

                <!--Body-->
                <div class="modal-body text-center">

                    <div class="col-lg-12 md-form input-group mb-3">
                        این سفارش تحویل کاربر داده شد
                    </div>

                </div>

                <!--Footer-->
                <div class="modal-footer flex-center">
                    <a  class="btn btn-success" onclick="functionStatus(5)">بله</a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                </div>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <!--Modal: modalPush-->



    <div class="row " id="divSelect">
        <div class="col-12">
            <div class="row justify-content-center py-3">
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer !important" onclick="showTable(1)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                منتظر پرداخت
                                <span class="counter Bkoodak ">{{ count($ordersStatus1) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer" onclick="showTable(2)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                منتظر تایید حساب داری
                                <span class="counter Bkoodak ">{{ count($ordersStatus2) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center py-3">
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer" onclick="showTable(3)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                منتظر تایید انبار
                                <span class="counter Bkoodak ">{{ count($ordersStatus3) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer" onclick="showTable(4)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                منتظر تحویل به پست
                                <span class="counter Bkoodak ">{{ count($ordersStatus4) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center py-3">
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer" onclick="showTable(5)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                تحویل به پست داده شده
                                <span class="counter Bkoodak success-color">{{ count($ordersStatus5) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="view overlay zoom" style="cursor: pointer" onclick="showTable(6)">
                        <div class="card py-5 primary-color">
                            <h5 class="text-center text-white">
                                تحویل به کاربر داده شده
                                <span class="counter Bkoodak success-color">{{ count($ordersStatus6) }}</span>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center d-none" id="selectButton" >
        <div class="col-12 text-center">
            <button class="btn btn-success btn-rounded" onclick="showSelect()">سفارشات</button>
        </div>
    </div>


    <div class="row justify-content-center mt-5 d-none" id="status1">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">منتظر پرداخت</h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                        $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'مبلغ قابل پرداخت',
                        'مبلغ کل',
                        'محصول',
                        'عملیات',
                    ]
                    ?>
                    <x-dbTable id="tableStatus1" :items="$table">
                        @foreach($ordersStatus1 as $order)
                            <?php $user = $order->user  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>

                                <td><span class="Bkoodak">{{ $order->total_price }}</span></td>

                                <td><span class="Bkoodak">{{ $order->total_price }}</span></td>

                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>

                                <td>
                                    <a class="btn btn-success btn-md mt-1" onclick="showModalStatus1({{$order->id}})">پرداخت انجام شده</a>
                                    <a class="btn btn-danger btn-md mt-1"  onclick="showModalDelete({{$order->id}})">حذف سفارش</a>
                                </td>

                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>

    <div class="row justify-content-center mt-5 d-none" id="status2">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">منتظر تایید حساب داری</h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                    $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'محصولات',
                        'سریال پرداخت',
                        'تایید',
                    ]
                    ?>
                    <x-dbTable id="tableStatus2" :items="$table">
                        @foreach($ordersStatus2 as $order)
                            <?php $user = $order->user  ?>
                            <?php $factor  = $order->factor  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>


                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>

                                <td><span class="Bkoodak">{{ $factor->ref_id ?? 'ثبت نشده' }}</span></td>

                                <td>
                                    <a class="btn btn-success btn-md mt-1" onclick="showModalStatus2({{$order->id}})">تایید</a>
                                    <a class="btn btn-danger btn-md mt-1"  onclick="showModalDelete({{$order->id}})">حذف سفارش</a>
                                </td>

                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>

    <div class="row justify-content-center mt-5 d-none" id="status3">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">منتظر تایید انبار </h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                    $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'محصولات',
                        'تایید',
                    ]
                    ?>
                    <x-dbTable id="tableStatus3" :items="$table">
                        @foreach($ordersStatus3 as $order)
                            <?php $user = $order->user  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>


                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>

                                <td>
                                    <a class="btn btn-success btn-md mt-1" onclick="showModalStatus3({{$order->id}})">تایید</a>
                                </td>

                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>

    <div class="row justify-content-center mt-5 d-none" id="status4">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">منتظر تحویل به پست </h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                    $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'محصولات',
                        'تایید',
                    ]
                    ?>
                    <x-dbTable id="tableStatus4" :items="$table">
                        @foreach($ordersStatus4 as $order)
                            <?php $user = $order->user  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>


                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>


                                <td><a class="btn btn-success btn-md mt-1" onclick="showModalStatus4({{$order->id}})">تایید</a></td>


                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>

    <div class="row justify-content-center mt-5 d-none" id="status5">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">تحویل به پست داده شده</h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                    $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'محصولات',
                        'سریال پرداخت',
                        'کد رهگیری پست',
                        'تحویل کاربر',
                    ]
                    ?>
                    <x-dbTable id="tableStatus5" :items="$table">
                        @foreach($ordersStatus5 as $order)
                            <?php $user = $order->user  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>


                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>

                                <td><span class="Bkoodak">{{ $factor->ref_id ?? 'ثبت نشده' }}</span></td>

                                <td><span class="Bkoodak">{{ $order->post_rahgiri }}</span></td>

                                <td><a class="btn btn-success btn-md mt-1" onclick="showModalStatus5({{$order->id}})">تایید</a></td>
                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>


    <div class="row justify-content-center mt-5 d-none" id="status6">
        <div class="col-lg-10">
            <div class="card card-cascade narrower animated slideInDown" id="card1">

                <!-- Card image -->
                <div class="view view-cascade  text-center  justify-content-center center align-center py-4 info-color ">
                    <h5 class="text-white">تحویل به کاربر داده شده</h5>
                </div>

                <!-- Card content -->
                <div class="card-body card-body-cascade text-center">

                    <?php
                    $table = [
                        'نام کاربر',
                        'شماره کاربر',
                        'شماره سفارش',
                        'تاریخ ثبت سفارش',
                        'محصولات',
                        'سریال پرداخت',
                        'کد رهگیری پست',
                        'تحویل کاربر',
                    ]
                    ?>
                    <x-dbTable id="tableStatus5" :items="$table">
                        @foreach($ordersStatus6 as $order)
                            <?php $user = $order->user  ?>
                            <tr>

                                <td><span>{{ $user->name.' '.$user->last_name }}</span></td>

                                <td><span>{{ $user->phone }}</span></td>

                                <td><span class="Bkoodak">{{ $order->getOrderId() }}</span></td>

                                <td><span class="Bkoodak">{{ $order->Created_at }}</span></td>


                                <td><a href="{{ route('admin.order',$order->id) }}" class="btn btn-info btn-md btn-rounded">نمایش</a></td>

                                <td><span class="Bkoodak">{{ $factor->ref_id ?? 'ثبت نشده' }}</span></td>

                                <td><span class="Bkoodak">{{ $order->post_rahgiri }}</span></td>

                                <td>
                                    <i class="fas fa-check text-success"></i>
                                </td>
                            </tr>
                        @endforeach
                    </x-dbTable>

                </div>

            </div>

        </div>
    </div>

@stop


@section('script')

    <script>


        function hideSelect() {
            $("#divSelect").addClass('d-none');
            $("#divSelect").removeClass('animated fadeInDown');

            $("#selectButton").removeClass('d-none');
            $("#selectButton").addClass('animated fadeInDown');
        }


        function showSelect() {
            $("#divSelect").removeClass('d-none');
            $("#divSelect").addClass('animated fadeInDown');

            $("#selectButton").addClass('d-none');
            $("#selectButton").removeClass('animated fadeInDown');
            hideAllTables();
        }

        function showTable(id) {
            hideSelect();
            $("#status"+id).addClass("animated fadeInDown");
            $("#status"+id).removeClass("d-none");
        }

        function hideTable(id) {
            showSelect();
            $("#status"+id).removeClass("animated fadeInDown");
            $("#status"+id).addClass("d-none");
        }

        function hideAllTables() {
            if( !$("#status1").hasClass('d-none') )
                $("#status1").addClass('d-none');
            if( !$("#status2").hasClass('d-none') )
                $("#status2").addClass('d-none');
            if( !$("#status3").hasClass('d-none') )
                $("#status3").addClass('d-none');
            if( !$("#status4").hasClass('d-none') )
                $("#status4").addClass('d-none');
            if( !$("#status5").hasClass('d-none') )
                $("#status5").addClass('d-none');
        }

    </script>

    <script>

        $( ".zoom" ).mouseover(function()
        {
            $(this).addClass("animated jello");
        });

        $( ".zoom" ).mouseout(function()
        {
            $(this).removeClass("animated jello ");
        });
    </script>


    <script>
        var id ;

        function showModalDelete(order_id) {
            $("#modalDeleteOrder").modal('show');
            id = order_id ;
        }

        function showModalStatus1(order_id) {
            $("#modalStatus1").modal('show');
            id = order_id ;
        }

        function showModalStatus2(order_id) {
            $("#modalStatus2").modal('show');
            id = order_id ;
        }

        function showModalStatus3(order_id) {
            $("#modalStatus3").modal('show');
            id = order_id ;
        }

        function showModalStatus4(order_id) {
            $("#modalStatus4").modal('show');
            id = order_id ;
        }

        function showModalStatus5(order_id) {
            $("#modalStatus5").modal('show');
            id = order_id ;
        }

        function deleteOrder() {
            window.location.href = '{{ url('/admin/order') }}'+'/'+id+'/delete' ;
        }

        function functionStatus(status) {
            window.location.href = '{{ url('/admin/order') }}'+'/'+id+'/changeStatus/'+status ;
        }

        var code = null;
        function functionStatusPost() {
            code = $("#post_code").val() ;
            if( code ){
                window.location.href = '{{ url('/admin/order') }}'+'/'+id+'/changeStatusToPost/'+code ;
            }else{
                toastr.warning('کد رهگیری نمیتواند خالی باشد','هشدار');
            }
        }

    </script>

@stop
