<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>login admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{url('awesome/css/all.css')}}">
    <!-- Bootstrap core CSS -->
    <link href="{{asset('home/css/bootstrap.min.css')}}" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="{{asset('home/css/mdb.min.css')}}" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <style>
        html,
        body,
        header,
        .view {
            height: 100%;
        }
        @media (min-width: 560px) and (max-width: 740px) {
            html,
            body,
            header,
            .view {
                height: 650px;
            }
        }
        @media (min-width: 800px) and (max-width: 850px) {
            html,
            body,
            header,
            .view  {
                height: 650px;
            }
        }
    </style>
</head>

<body class="login-page">

<!-- Main Navigation -->
<header>


    <!-- Intro Section -->
    <section class="view intro-2">
        <div class="mask rgba-stylish-strong h-100 d-flex justify-content-center align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-5 col-lg-6 col-md-10 col-sm-12 mx-auto mt-5">

                        <!-- Form with header -->
                        <div class="card wow fadeIn" data-wow-delay="0.3s">
                            <div class="card-body">

                                <!-- Header -->
                                <div class="form-header purple-gradient">
                                    <h3 class="font-weight-500 my-2 py-1"><i class="fas fa-user"></i> Admin</h3>
                                </div>

                                <form action="{{url('/login')}}" method="post">
                                    <!-- Body -->@csrf
                                    <div class="mt-5">
                                        <div class="md-form ">
                                            <i class="fas fa-user prefix text-dark"></i>
                                            <input type="text" name="userName" id="orangeForm-name" class="form-control">
                                            <label for="orangeForm-name">Your UserName</label>
                                        </div>
                                    </div>

                                    <div class="mt-5">
                                        <div class="md-form ">
                                            <i class="fas fa-lock prefix text-dark"></i>
                                            <input type="password" name="password" id="orangeForm-pass" class="form-control">
                                            <label for="orangeForm-pass">Your password</label>
                                        </div>
                                    </div>

                                    @if($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <div class="col-12 my-2 text-center">
                                                <div class="card">
                                                    <div class="card-body text-white danger-color">
                                                        {{ $error }}
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif


                                        @if(session('alert'))
                                            <div class="col-12 text-center">
                                                <div class="card">
                                                    <div class="card-body text-white {{session('alert')[1]}}">
                                                        {{session('alert')[2]}}
                                                    </div>
                                                </div>
                                            </div>
                                        @endif


                                    <div class="mt-3">
                                        <div class="text-center">
                                            <button class="btn purple-gradient btn-lg" type="submit">login</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                        <!-- Form with header -->

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Intro Section -->

</header>
<!-- Main Navigation -->

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="{{asset('home/js/jquery-3.4.1.min.js')}}"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="{{asset('home/js/popper.min.js')}}"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="{{asset('home/js/bootstrap.min.js')}}"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="{{asset('home/js/mdb.js')}}"></script>

<!-- Custom scripts -->
<script>

    new WOW().init();

</script>

</body>

</html>
