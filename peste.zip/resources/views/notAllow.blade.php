@extends('home.mater')

@section('body')
    <div class="container vh-100">

        <!-- Grid row -->
        <div class="row d-flex align-items-center h-100">

            <!-- Grid column -->
            <div class="col-12">

                <!--Section: Block Content-->
                <section class="mt-70 mb-5 text-center">




                    <h1 class="display-1">:(</h1>

                    <h2 class="mb-4 h4">دسترسی غیر مجاز</h2>

                    <p class="mb-0">شما صفحه ای که به آن دسترسی ندارید را فراخوانی کرده اید!</p>
                    <br>
                    <a href="{{ url('') }}" class="btn btn-info btn-rounded">صفحه اصلی</a>

                </section>
                <!--Section: Block Content-->

            </div>
            <!-- Grid column -->

        </div>
        <!-- Grid row -->

    </div>

@endsection
