<div class="col-lg-{{ $size ?? '3' }} product_cols" onclick="goToProductPage('{{ $product->english_name }}')" style="cursor: pointer">
        <div class="card hoverable mb-4" >
            <div class="card-body" >
                <div class="row align-items-center">
                    <div class="col-6 px-0">
                        <a>
                            <img src="{{ asset($product->pic1 ?? 'images/placeHolder.jpg') }}" class="img-fluid" alt="{{ $product->Name }}" title="{{ $product->Name }}پسته ">
                        </a>
                    </div>
                    <div class="col-6">

                       <h2 class="h6 py-0 my-0">
                            <a class="py-0">
                                <strong>
                                    {{ $product->Name }}
                                </strong>
                            </a>
                       </h2>
                        <h6 class="d-none"><b> پسته {{ $product->Name }} </b></h6>
                        <h3 class="d-none"><b> پسته {{ $product->Name }} </b></h3>
                        <br>

                        <h3 class="h6 py-0 my-0">
                            <a class="py-0">
                                {{$product->group->name}}
                                {{$product->getPersianSalty()}}
                            </a>
                        </h3>

                        <br>


                        <span class="h6-responsive font-weight-bold dark-grey-text mt-2">
                            @if($product->price_off)

                                <strong class="text-success">
                                    <span  class="Bkoodak">
                                            <x-price :price="$product->price_off" />
                                    </span>
                                    تومان
                                </strong>

                                <span class="grey-text">
                                    </br>
                                <small>
                              <s class="Bkoodak"><x-price :price="$product->price" /></s>
                            </small>

                        @else
                            <strong class="text-success">
                                <span  class="Bkoodak">
                                        <x-price :price="$product->price" />
                                </span>
                                تومان
                            </strong>

                                    </br>
                                    </br>


                                    @endif

                        </span>
                        </span>

                    </div>
                </div>
            </div>
        </div>
</div>
