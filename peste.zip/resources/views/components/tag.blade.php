<div class="chip blue lighten-4" @if( $hidden == true ) style="display: none" @endif>
    <h2 class=" pt-2 m-0" style="font-size: 13px;">
        {{$name}}
    </h2>
</div>
