
<div class="col-lg-4 col-md-6 mb-4 ">
    <div class="card-wrapper" >
        <div id="card-{{$id}}" class=" card-rotating text-center">

            <div class="face front">
                <div class="card card-cascade wider card-ecommerce">
                    <!-- Card image -->
                    <div class="view view-cascade overlay">
                        <img src="{{ ( $product->pic1 ) ? asset("{$product->pic1}") : asset("images/placeHolder.jpg") }}" class="card-img-top" alt="{{$title}}" title="{{ $product->Name }}پسته ">
                        <a>
                            <div class="mask rgba-white-slight waves-effect waves-light"></div>
                        </a>
                    </div>
                    <!-- Card image -->
                    <!-- Card content -->
                    <div class="card-body card-body-cascade text-center">
                        <!-- Category & Title -->
                        <a  class="text-muted">  <h2 class="h5"> <strong>{{$title}}</strong> </h2>  </a>
                        <h6 class="d-none"><b>پسته</b></h6>

                        <span class="h4 card-title">
                            <strong>
                                <span  class="Bkoodak">
                                    <x-price :price="$price" />
                                </span>
                                تومان
                            </strong>
                        </span>

                        <a class="rotate-btn mb-2" data-card="card-{{$id}}">
                            <i class="fas fa-redo-alt"></i>
                            اطلاعات بیشتر
                        </a>
                        <div class="card-footer px-1 pt-2 mt-3 mb-0 pb-0 text-center">
                            <a class="btn btn-primary text-white btn-rounded " href="{{route('showProduct',$product->english_name)}}">
                                نمایش
                            </a>
                        </div>
                    </div>
                    <!-- Card content -->
                </div>
            </div>

            <div class=" face back">
                <div class=" card-cascade wider card-ecommerce pt-5">
                    <div class="card-body card-body-cascade text-center mt-5">

                        <h6 class="py-3">
                            بسته بندی :
                            {{$product->getPersianPacking()}}
                        </h6>

                        <h6 class="py-3">
                            نوع فرآورده :
                            {{$product->getPersianSalty()}}
                        </h6>

                        <h6 class="py-3">
                            نوع پسته :
                            {{$product->group->name}}
                        </h6>

                        <h6 class="py-3">
                            وزن خالص :
                            <span class="Bkoodak">{{$product->weight}}</span>
                            گرم
                        </h6>

                        <h6 class="py-3">
                            وضعیت انبار  :
                           <span class="{{$available == 1 ? "text-success" : "text-danger"}}">
                                {{$available == 1 ? "موجود" : "نا موجود"}}
                           </span>
                        </h6>

                        <!--Triggering button-->
                        <a class="rotate-btn" data-card="card-{{$id}}">
                            <i class="fas fa-undo"></i>
                            محصول
                        </a>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

