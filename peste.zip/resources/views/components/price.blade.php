@php($array = mb_str_split(strrev($price),3))
@php($count = count($array))

@if($count == 1)
    {{strrev($array[0])}}
@elseif($count == 2)
    {{strrev($array[0].','.$array[1])}}
@elseif($count == 3)
    {{strrev($array[0].','.$array[1].','.$array[2])}}
@elseif($count == 4)
    {{strrev($array[0].','.$array[1].','.$array[2].','.$array[3])}}
@endif
