<button
    class="btn btn-{{ $color }}        @if( $rounded == true )  btn-rounded @endif       @if( $size )  btn-{{$size}}  @endif         @if($fadeIn) animated fadeInUp @endif      "
    @if( $modalTarget ) data-toggle="modal" data-target="#{{ $modalTarget }}" @endif >

    @if(!empty($text)) {{$text}} @else {{ $slot }} @endif
</button>
