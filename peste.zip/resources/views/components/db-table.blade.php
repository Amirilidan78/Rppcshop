<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
    <thead>
    <tr>
        @foreach($items as $item)
            <th >
                {{$item}}
            </th>
        @endforeach

    </tr>
    </thead>
    <tbody>

        {{$slot}}

    </tbody>
</table>
