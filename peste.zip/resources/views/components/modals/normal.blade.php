
<div class="modal fade" id="{{$id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog  modal-notify {{ $modal_type }} {{$modal_size}}" role="document">
        <div class="modal-content text-center">
            <div class="modal-header d-flex justify-content-center">
                <p class="heading"> {{ $title }} </p>
            </div>

            <div class="modal-body text-center">

                {{ $slot }}

            </div>

            <div class="modal-footer flex-center">
                <a  class="btn  btn-outine-danger" data-dismiss="modal">بستن</a>
                <a href="{{$Url}}" class="btn  btn-danger waves-effect"  >{{ $nameAction }}</a>
            </div>
        </div>
    </div>
</div>
