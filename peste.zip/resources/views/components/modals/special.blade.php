@if($form == true) <form action="{{ $formAction }}" method="{{ $formMethod }}"> @csrf  @endif

    <div class="modal fade" id="{{$id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog  modal-notify {{$modalSize}} modal-{{ $modalColor }} " role="document">
            <div class="modal-content text-center">
                <div class="modal-header d-flex justify-content-center">
                    <p class="heading"> {{ $title }} </p>
                </div>

                <div class="modal-body text-center">

                    {{ $slot }}

                </div>

                <div class="modal-footer flex-center">

                    @if($form == true)

                        <a  class="btn btn-outline-{{ $modalColor }}" data-dismiss="modal">بستن</a>
                        <button type="submit"  class="btn btn-{{ $modalColor }}" >
                            @if($formSubmitText)
                                {{$formSubmitText}}
                            @else
                                ثبت
                            @endif
                        </button>

                    @else

                        @if($footer)
                            {{ $footer }}
                        @else
                            <a  class="btn  btn-outine-{{ $modalColor }}" data-dismiss="modal">بستن</a>
                        @endif

                    @endif

                </div>
            </div>
        </div>
    </div>

@if($form == true) </form>  @endif
