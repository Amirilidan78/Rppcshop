<!--Modal: modalConfirmDelete-->
<div class="modal fade" id="{{$id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-sm modal-notify modal-danger" role="document">
        <!--Content-->
        <div class="modal-content text-center">
            <!--Header-->
            <div class="modal-header d-flex justify-content-center">
                <p class="heading">{{$title}}</p>
            </div>

            <!--Body-->
            <div class="modal-body text-center">

                <i class="fas fa-times fa-4x animated rotateIn"></i>

            </div>

            <!--Footer-->
            <div class="modal-footer flex-center">
                <a  class="btn  btn-outline-danger" data-dismiss="modal">بستن</a>
                <a href="{{$deleteUrl}}" class="btn  btn-danger waves-effect"  >حذف</a>
            </div>
        </div>
        <!--/.Content-->
    </div>
</div>
<!--Modal: modalConfirmDelete-->
