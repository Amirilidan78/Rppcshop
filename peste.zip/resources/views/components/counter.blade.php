@if($number < 10)
    10+
@elseif($number < 20)
    20+
@elseif($number < 30)
    30+
@elseif($number < 40)
    40+
@elseif($number < 50)
    50+
@elseif($number < 100)
    100+
@elseif($number < 150)
    150+
@elseif($number < 200)
    200+
@elseif($number < 250)
    250+
@elseif($number < 300)
    300+
@elseif($number < 350)
    350+
@elseif($number < 400)
    400+
@elseif($number < 450)
    450+
@elseif($number < 500)
    500+
@elseif($number < 550)
    550+
@elseif($number < 600)
    600+
@elseif($number < 650)
    650+
@elseif($number < 700)
    700+
@elseif($number < 750)
    750+
@elseif($number < 800)
    800+
@elseif($number < 850)
    850+
@elseif($number < 900)
    900+
@elseif($number < 950)
    950+
@elseif($number < 1000)
    1000+
@endif
