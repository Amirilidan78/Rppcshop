
@extends('home.mater')

@section('style')
    <style>
        th,td{
            text-align: center ;
        }
    </style>
@stop
@section('body')

    @foreach($cartDetail as $i)
        @include('components.modals.delete' ,[
            'id' => 'delete'.$i['0'] ,
            'title' => "حذف محصول از سبد خرید !؟" ,
            'deleteUrl' => url("/cart/delete/product/{$i['0']}") ,
        ])
    @endforeach

    @if($cartDetail)
        @foreach($cartDetail as $i)
        <div class="modal fade" id="{{'modal'.$i['0']}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog  modal-notify modal-lg modal-warning " role="document">
                        <div class="modal-content text-center">
                            <div class="modal-header d-flex justify-content-center">
                                <p class="heading"> ویرایش تعداد محصول </p>
                            </div>

                            <div class="modal-body text-center">

                                <div class="d-flex justify-content-center my-4 " style="display: none">
                                    <span class="font-weight-bold blue-text mr-2 mt-1" style="display: none">0</span>
                                    <form class="range-field w-50 " style="display: none">
                                        <input class="border-0" type="range" min="0" max="100" style="display: none"/>
                                    </form>
                                    <span class="font-weight-bold blue-text ml-2 mt-1" style="display: none">100</span>
                                </div>

                                @php($count = \App\Product::find($i['0'])->count)

                                <span class="font-weight-bold text-warning mr-2 mt-1">تعداد : </span>
                                <span class="font-weight-bold text-info mr-2 mt-1 Bkoodak " id="countOrderProducts{{$i['0']}}">{{$i['3']}}</span>
                                <div class="d-flex justify-content-center my-4 pt-3">
                                    <form class="range-field w-75">
                                        <input class="border-0" type="range" min="0" max="{{$count}}" value="{{$i['3']}}" id="rangeInput{{$i['0']}}"  name="count"/>
                                    </form>
                                </div>


                                <input type="hidden" name="product_id" value="{{$i['0']}}">

                            </div>

                            <div class="modal-footer flex-center">
                                    <a  class="btn btn-outline-warning" data-dismiss="modal">بستن</a>
                                    <button    class="btn btn-warning" onclick="addToCart({{$i['0']}})"> ویرایش  </button>
                            </div>
                        </div>
                    </div>
                </div>
        @endforeach
    @endif

    <div class="container">
        <section class="section my-5 pb-5">

            @if(count($cartDetail) > 0)

                <div class="table-responsive mt-5 pt-5">

                    <table class="table product-table table-cart-v-1">

                        <!-- Table head -->
                        <thead>

                        <tr>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>محصول</strong>
                            </th>


                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>تعداد</strong>
                            </th>

                            <th></th>

                            <th class="font-weight-bold animated fadeInDown">
                                <strong>
                                    قیمت کل
                                    (تومان)
                                </strong>
                            </th>

                            <th></th>

                            <th>ویرایش تعداد</th>

                            <th></th>

                            <th class="animated fadeInDown">
                                نمایش
                            </th>


                        </tr>

                        </thead>
                        <!-- Table head -->

                        <!-- Table body -->
                        <tbody>

                        @foreach($cartDetail as $i)
                            <tr>

                                <td>
                                    <button type="button" class="close text-danger animated fadeInDown" data-toggle="modal" data-target="#delete{{$i['0']}}">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </td>

                                <td>

                                    <h5 class="mt-3 animated fadeInDown">

                                        <strong class="">{{$i[1]}}</strong>

                                    </h5>

                                    {{--                        <p class="text-muted">درجه 1</p>--}}

                                </td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown"> <x-price :price="$i[2]"/> </span>
                                </td>

                                <td></td>

                                <td class="Bkoodak animated fadeInDown">
                                    {{$i[3]}}
                                </td>

                                <td></td>

                                <td >
                                    <span class="Bkoodak animated fadeInDown">
                                        <x-price :price="$i[2]*$i[3]"/>
                                    </span>
                                </td>

                                <td></td>

                                <td>
                                    <x-but color="warning" rounded="true" size="md" fadeIn="true" :modalTarget="'modal'.$i[0]" text="ویرایش"> ویرایش  </x-but>
                                </td>
                                <td></td>

                                <?php
                                    $product = \App\Product::find($i[0])
                                ?>
                                <td>
                                    <a  class="btn btn-info btn-rounded btn-md animated fadeInDown">نمایش</a>
                                </td>


                            </tr>
                        @endforeach

                        </tbody>
                        <!-- Table body -->

                    </table>

                </div>

                <div class="col-12 mt-5 pt-5">
                    <div class="row ">

                        <div class="col-lg-4 mt-3 text-center">
                            <div class="card  animated fadeInDown">
                                <div class="card-header text-center info-color">
                            <span class="text-white">
                                قیمت کل
                            </span>
                                </div>
                                <div class="card-body text-center">
                                    <h6 class="Bkoodak text-center">
                                        <x-price :price="$priceTotal"/>
                                    </h6>
                                    <h6>
                                        تومان
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mt-3 text-center">
                            <a href="{{ route('deleteShoppingCart') }}" class="btn btn-warning  animated fadeInDown">
                                خالی کردن سبد خرید
                            </a>
                        </div>
                        <div class="col-lg-4 mt-3 text-center">
                            <a href="{{ url('cart2') }}" class="btn btn-success  animated fadeInDown">
                                مرحله بعدی
                            </a>
                        </div>
                    </div>
                </div>
            @else
                <div class="col-12" style="height: 100px"></div>

                <div class="col-12 text-center mt-5 pt-5">
                    <h4 class="text-center">
                        سبد خرید شما خالی است
                    </h4>
                    <a href="{{url('products')}}" class="btn  btn-success btn-rounded waves-light">
                    <span>
                        بازگشت به صفحه ی محصولات
                    </span>
                    </a>
                </div>
            @endif




        </section>


        <section>
            <div class="row">
                @if(count($cartDetail) > 0)
                    <div class="col-12" style="height: 250px"></div>
                @else
                    <div class="col-12" style="height: 400px"></div>
                @endif
            </div>
        </section>
    </div>
@stop
@section('script')
    <script>

    @foreach($cartDetail as $i)
            $("#rangeInput{{$i['0']}}").change(function () {
                $("#countOrderProducts{{$i['0']}}").html($("#rangeInput{{$i['0']}}").val());
            })
    @endforeach


    function addToCart(id) {

        $.ajax({
            type: 'post',
            url: "{{url('/postAddProductTOShoppingCart')}}",
            data: {
                _token: "{{csrf_token()}}",
                count: $("#rangeInput"+id).val() ,
                product_id: id ,
            },
            dataType: 'json',
            success: function (data) {

                if(data['response']==1){
                    toastr.info('به روز رسانی شد','سبد خرید');
                    $("#cartIndex").html( parseInt(data['count']) );

                }else {

                    if(data['response']==-1)
                        toastr.warning('محصول یافت نشد','سبد خرید');

                    if(data['response']==0)
                        toastr.warning('موجودی انبار کافی نیست','سبد خرید');


                }
                location.reload();
            },
            error: function (xhr, statustext, error) {

                toastr.warning('خطا در ارتباط با سامانه', 'خطا');
            }


        });


    }

    </script>
@stop




