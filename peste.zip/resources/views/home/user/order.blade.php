@extends('home.mater')

@section('style')
    <style>
        th,tr,td{
            text-align: center;
        }
        th{
            border: none !important;
        }
    </style>

    <!-- Timeline CSS -->
    <link href="{{ asset('home/css/addons-pro/timeline.css') }}" rel="stylesheet">

@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5 grey lighten-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-12">
                 <div class="row">

                     @include('home.user.components.nav')

                     <div class="col-lg-9 mt-1">


                         <?php
                            $post = $order->post ;
                         ?>
                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-1">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row  px-5">


                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             تحویل گیرنده :
                                         </span>
                                         <h6>
                                             {{ $order->user->name.' '.$order->user->last_name }}
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             آدرس:
                                         </span>
                                         <h6>
                                             {{ $post->address }}
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                            کد پستی :
                                         </span>

                                         <h6 class="Bkoodak">
                                             {{ $post->post_code }}
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                            تلفن ثابت :
                                         </span>
                                         <h6 class="Bkoodak">
                                             {{ $post->number }}
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                          مبلغ کل :
                                         </span>
                                         <h6 class="Bkoodak">
                                             <x-price :price="$order->total_price" />
                                             تومان
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                          مبلغ قابل پرداخت :
                                         </span>
                                         <h6 class="Bkoodak">
                                             <x-price :price="($order->status == 0) ? $order->total_price : 0" />
                                             تومان
                                         </h6>
                                     </div>

                                     <div class="col-lg-6 py-3 text-right">
                                         <span class="text-muted">
                                             روش ارسال :
                                         </span>
                                         <h6 class="Bkoodak">
                                             {{ $order->getSendType() }}
                                         </h6>
                                     </div>
                                 </div>
                             </div>
                         </div>






                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-5">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row">
                                     <div class="col-12 py-3">
                                             <div class="table-responsive mt-3">
                                                 <table class="table product-table table-cart-v-1">

                                                     <!-- Table head -->
                                                     <thead>

                                                     <tr>


                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>نمایش محصول</strong>
                                                         </th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>محصول</strong>
                                                         </th>


                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>
                                                                 قیمت
                                                                 (تومان)
                                                             </strong>
                                                         </th>

                                                         <th></th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>تعداد</strong>
                                                         </th>

                                                         <th></th>

                                                         <th class="font-weight-bold animated fadeInDown">
                                                             <strong>
                                                                 قیمت کل
                                                                 (تومان)
                                                             </strong>
                                                         </th>

                                                         <th></th>

                                                     </tr>

                                                     </thead>
                                                     <!-- Table head -->

                                                     <!-- Table body -->
                                                     <tbody>

                                                     @foreach($products as $product)
                                                         <tr>

                                                             <td><a href="{{ url( "/product/{$product->product->Name}" ) }}" class="btn btn-success btn-rounded">نمایش</a></td>

                                                             <td> <h6 class="mt-3 animated fadeInDown"> <strong class="">{{$product->product->Name}}</strong> </h6>  </td>

                                                             <td >
                                                                 <span class="Bkoodak animated fadeInDown"> <x-price :price="$product->price"/> </span>
                                                             </td>

                                                             <td></td>

                                                             <td class=" animated fadeInDown"> <span class="Bkoodak">{{$product->count}}</span>  </td>

                                                             <td></td>

                                                             <td > <span class="Bkoodak animated fadeInDown"> <x-price :price="$product->total_price"/> </span> </td>

                                                             <td></td>

                                                         </tr>
                                                     @endforeach

                                                     </tbody>
                                                     <!-- Table body -->

                                                 </table>
                                             </div>
                                     </div>
                                 </div>
                             </div>
                         </div>






                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-5">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row">
                                     <div class="col-12 py-3">
                                         <style>
                                             span,li,.circle  {direction: ltr;}
                                         </style>
                                         <!-- Timeline -->
                                         <div class="row">
                                             <div class="col-md-12">

                                                 <h3 class="text-center">
                                                     وضعیت مرسوله
                                                 </h3>
                                                 <h4 class="Bkoodak h5 text-center">
                                                     {{$order->getOrderId()}}
                                                 </h4>

                                                 <div class="timeline-main">
                                                     <!-- Timeline Wrapper -->
                                                     <ul class="stepper stepper-vertical timeline timeline-basic pl-0">


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half @if($order->status == 0 ) danger-color animated  flipInY infinite  @else success-color @endif">
                                                                    <i class="fas fa-coins "
                                                                      aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5">
                                                                 <h4 class="font-weight-bold text-center">عملیات پرداخت</h4>
                                                                 <div class="text-center">
                                                                     @if($order->status == 0 )
                                                                        <h6 class="text-danger text-center ">
                                                                            منتظر پرداخت
                                                                        </h6>
                                                                         <button class="btn btn-success btn-rounded" onclick="goToPay({{$order->id}})">پرداخت</button>
                                                                     @else
                                                                         <span class="text-success">
                                                                             پرداخت موفق
                                                                         </span>
                                                                         <br>
                                                                         <span class="text-success">
                                                                             شماره رهگیری
                                                                             <span class="Bkoodak">{{$factor->ref_id}}</span>
                                                                         </span>
                                                                     @endif
                                                                 </div>
                                                             </div>
                                                         </li>


                                                         <li >
                                                             <!--Section Title -->
                                                             <a href="#!" >
                                                                <span class="circle z-depth-1-half @if($order->status == 1 ) warning-color animated  flipInY infinite @elseif($order->status < 1) gray-color @else success-color @endif">
                                                                    <i class="fas fa-calendar-check"
                                                                           aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 ml-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">تایید سفارش</h4>
                                                                 @if($order->status == 1 )
                                                                     <h6 class="text-warning text-center ">
                                                                         منتظر تایید
                                                                     </h6>
                                                                 @elseif($order->status < 1 )
                                                                     <h6 class="text-muted text-center ">
                                                                         {{ $order->getStep() }}
                                                                     </h6>
                                                                 @else
                                                                     <span class="text-success ">
                                                                         تایید شد
                                                                     </span>
                                                                 @endif
                                                             </div>
                                                         </li>


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half @if($order->status == 2 ) info-color animated  flipInY infinite @elseif($order->status < 2) gray-color @else success-color @endif">
                                                                    <i class="fas fa-dolly" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">آماده سازی سفارش</h4>
                                                                 @if($order->status == 2 )
                                                                     <h6 class="text-info text-center ">
                                                                        در حال آماده سازی
                                                                     </h6>
                                                                 @elseif($order->status < 2 )
                                                                     <h6 class="text-muted text-center ">
                                                                         {{ $order->getStep() }}
                                                                     </h6>
                                                                 @else
                                                                     <span class="text-success">
                                                                        آماده سازی
                                                                     </span>
                                                                 @endif
                                                             </div>
                                                         </li>


                                                         <li>
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle z-depth-1-half @if($order->status == 3 ) secondary-color animated  flipInY infinite @elseif($order->status < 3) gray-color @else success-color @endif">
                                                                     <i class="fas fa-shipping-fast" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 ml-2 p-4 mb-5 text-center">
                                                                 <h4 class="font-weight-bold text-center">خروج از مرکز پردازش</h4>
                                                                 @if($order->status == 3 )
                                                                     <h6 class="text-info text-center ">
                                                                         در حال بارگیری
                                                                     </h6>
                                                                 @elseif($order->status < 3 )
                                                                     <h6 class="text-muted text-center ">
                                                                         {{ $order->getStep() }}
                                                                     </h6>
                                                                 @else
                                                                     <span class="text-success">
                                                                        از مرکز خارج شد
                                                                     </span>
                                                                 @endif
                                                             </div>
                                                         </li>


                                                         <li class="timeline-inverted">
                                                             <!--Section Title -->
                                                             <a href="#!">
                                                                <span class="circle  z-depth-1-half @if($order->status == 4 ) success-color animated  flipInY infinite @elseif($order->status < 4) gray-color @endif">
                                                                    <i class="fas fa-dolly" aria-hidden="true"></i>
                                                                </span>
                                                             </a>

                                                             <!-- Section Description -->
                                                             <div class="step-content z-depth-1 mr-xl-2 p-4 mb-5">
                                                                 <h4 class="font-weight-bold text-center">تحویل به اداره پست</h4>
                                                                 @if($order->status == 4 )
                                                                     <h6 class="text-success text-center ">
                                                                         بارکد پستی برای رهگیری :
                                                                         {{ $order->post_rahgiri ?? "ثبت نشده" }}
                                                                     </h6>

                                                                 @elseif($order->status < 4 )
                                                                     <h6 class="text-muted text-center ">
                                                                         {{ $order->getStep() }}
                                                                     </h6>
                                                                 @endif
                                                             </div>
                                                         </li>



                                                     </ul>
                                                     <!-- Timeline Wrapper -->
                                                 </div>
                                             </div>
                                         </div>
                                         <!-- Timeline -->
                                     </div>
                                 </div>
                             </div>
                         </div>







                     </div>



                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>


@stop

@section('script')

    <script>
        function goToPay() {
            window.location.href =  "{{ url('/transaction/') }}/{{$order->id}}"
        }
    </script>

@stop
