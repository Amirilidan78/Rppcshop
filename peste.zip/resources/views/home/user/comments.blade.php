@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-10">
                 <div class="row">


                     @include('home.user.components.nav')


                     <div class="col-lg-9">
                         <div class="card card-cascade wider">

                             <!-- Card image -->

                             <!-- Card content -->
                             <div class="card-body card-body-cascade text-center">

                                 <div class="row">

                                     <div class="col-12 py-4">
                                         <h5 class="text-center animated fadeInDown ">دیدگاه های ثبت شده</h5>
                                     </div>

                                     <div class="col-12 py-3">
                                         <div class="row justify-content-center">

                                             @if( count($comments) > 0 )

                                                 @foreach($comments as $comment)



                                                     <div class="col-lg-10">
                                                         <div class="card py-3 px-2 my-2">
                                                             <div class="row justify-content-center">

                                                                 <div class="col-lg-8 text-center justify-content-center pt-3">
                                                                     <span class="animated fadeInDown "> {{ $comment->text }}</span>
                                                                 </div>

                                                                 <div class="col-lg-2 text-center justify-content-center pt-3">
                                                                     <a href="{{ url("/product/{$comment->product_id}") }}" class="btn btn-info btn-sm btn-rounded text-nowrap animated fadeInDown ">نمایش محصول</a>
                                                                 </div>

                                                                 <div class="col-lg-12 text-right px-5 justify-content-center ">
                                                                     <span class="text-black-50 Bkoodak animated fadeInDown "> {{ $comment->Created_at }}</span>
                                                                 </div>

                                                             </div>

                                                         </div>
                                                     </div>

                                                     {{$comments->links('components.paginate.index')}}

                                                 @endforeach

                                             @else

                                                 <div class="col-10 card px-3 py-5 ">
                                                     <h5 class="text-center animated fadeInDown ">
                                                         آدرسی ثبت نشده
                                                     </h5>
                                                 </div>

                                             @endif

                                         </div>
                                     </div>

                                 </div>



                             </div>
                             <!-- Card content -->

                         </div>
                     </div>



                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>


@stop

@section('script')

@stop
