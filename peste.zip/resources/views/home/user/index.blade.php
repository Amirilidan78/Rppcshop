@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-10">
                 <div class="row">


                     @include('home.user.components.nav')


                     <div class="col-lg-9">
                         <div class="card card-cascade wider">

                             <!-- Card image -->

                             <!-- Card content -->
                             <div class="card-body card-body-cascade text-center">

                                 <div class="row">

                                     <div class="col-12 py-4">
                                         <h5 class="text-center animated fadeInDown ">پروفایل شما</h5>
                                     </div>

                                     <div class="col-12 py-3">
                                         <div class="row">
                                             <div class="col-lg-6">
                                                 <div class="card py-3 px-2 my-2">
                                                     <a>
                                                         <span class="text-black-50 animated fadeInDown">نام : </span>
                                                         <span class="animated fadeInDown "> {{ $user->name }}</span>
                                                     </a>
                                                 </div>
                                             </div>

                                             <div class="col-lg-6">
                                                 <div class="card py-3 px-2 my-2">
                                                     <a>
                                                         <span class="text-black-50 animated fadeInDown">نام خانوادگی : </span>
                                                         <span class="animated fadeInDown "> {{ $user->last_name }}</span>
                                                     </a>
                                                 </div>
                                             </div>

                                             <div class="col-lg-6">
                                                 <div class="card py-3 px-2 my-2">
                                                     <a>
                                                         <span class="text-black-50 animated fadeInDown">شماره همراه : </span>
                                                         <span class="animated fadeInDown Bkoodak"> {{ $user->phone }}</span>
                                                     </a>
                                                 </div>
                                             </div>

{{--                                             <div class="col-lg-6">--}}
{{--                                                 <div class="card py-3 px-2 my-2">--}}
{{--                                                     <a>--}}
{{--                                                         <span class="text-black-50 animated fadeInDown">کد ملی :</span>--}}
{{--                                                         <span class="animated fadeInDown Bkoodak"> {{ $user->code_melli }}</span>--}}
{{--                                                     </a>--}}
{{--                                                 </div>--}}
{{--                                             </div>--}}
                                         </div>
                                     </div>

                                     <div class="col-12 py-4 text-center">
                                         <x-but color="success" rounded="true" modalTarget="modifyUser" text="ویرایش پروفایل"/>
                                         <x-but color="warning" rounded="true" modalTarget="modifyPassword" text="ویرایش رمز عبور"/>
                                     </div>

                                 </div>



                             </div>
                             <!-- Card content -->

                         </div>
                     </div>


                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>



{{--    change user profile modal--}}
    <x-modalSpecial
                    id="modifyUser"
                    form="true"
                    :formAction="route('user.modifyUser')"
                    formMethod="post"
                    modalSize="lg"
                    modalColor="success"
                    title="ویرایش مشخصات کاربر"
                    formSubmitText="ثبت"
    >

        <div class="row justify-content-center">

            <div class="col-lg-8 md-form input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text md-addon animated fadeInDown" >نام </span>
                </div>
                <input type="text" class="form-control" name="name" value="{{ $user->name }}">
            </div>

            <div class="col-lg-8 md-form input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text md-addon animated fadeInDown" >نام خانوادگی </span>
                </div>
                <input type="text" class="form-control" name="last_name" value="{{ $user->last_name }}">
            </div>

            <div class="col-lg-8 md-form input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text md-addon animated fadeInDown" >شماره همراه </span>
                </div>
                <input type="text" class="form-control" disabled value="{{ $user->phone }}">
            </div>

        </div>

    </x-modalSpecial >



{{--    change user passowrd modal--}}
    <x-modalSpecial
        id="modifyPassword"
        form="true"
        :formAction="route('user.modifyUserPassword')"
        formMethod="post"
        modalSize="md"
        modalColor="warning"
        title=" ویرایش رمز عبور "
        formSubmitText="ثبت"
    >

        <div class="row justify-content-center">

            <div class="col-lg-8 md-form input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text md-addon animated fadeInDown" >رمز عبور جدید </span>
                </div>
                <input type="password" class="form-control" name="password">
            </div>

            <div class="col-lg-8 md-form input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text md-addon animated fadeInDown" >تکرار رمز عبور </span>
                </div>
                <input type="password" class="form-control" name="rePassword">
            </div>

        </div>

    </x-modalSpecial >



@stop

@section('script')
@stop
