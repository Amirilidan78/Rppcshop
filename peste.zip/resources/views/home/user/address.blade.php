@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-10">
                 <div class="row">


                     @include('home.user.components.nav')


                     @foreach($addresses as $address)
                         @php( $modalId = "deleteAddress".$address->id )
                         @php( $modalUrl = route('user.deleteAddress',['id'=>$address->id]) )
                         <x-modalDelete :id="$modalId" title="حذف آدرس  !؟" :deleteUrl="$modalUrl" />
                     @endforeach


                     <div class="col-lg-9">
                         <div class="card card-cascade wider">

                             <!-- Card image -->

                             <!-- Card content -->
                             <div class="card-body card-body-cascade text-center">

                                 <div class="row">

                                     <div class="col-12 py-4">
                                         <h5 class="text-center animated fadeInDown ">آدرس های ثبت شده</h5>
                                     </div>

                                     <div class="col-12 py-3">
                                         <div class="row justify-content-center">

                                             @if( count($addresses) > 0 )

                                                 @foreach($addresses as $address)



                                                     <div class="col-lg-6">
                                                         <div class="card py-3 px-2 my-2">
                                                             <div class="row">

                                                                 <div class="col-12 pr-4">
                                                                     <button type="button" class="close text-danger" aria-label="Close" data-toggle="modal" data-target="#deleteAddress{{$address->id}}">
                                                                         <span aria-hidden="true">×</span>
                                                                     </button>
                                                                 </div>

                                                                 <div class="col-lg-6 text-center py-3">
                                                                     <span class="text-black-50 animated fadeInDown ">استان : </span>
                                                                     <span class="animated fadeInDown "> {{ $address->city }}</span>
                                                                 </div>


                                                                 <div class="col-lg-6 text-center py-3">
                                                                     <span class="text-black-50 animated fadeInDown ">شهر : </span>
                                                                     <span class="animated fadeInDown ">  {{ $address->town }} </span>
                                                                 </div>


                                                                 <div class="col-lg-12 text-center py-3">
                                                                     <span class="text-black-50 animated fadeInDown ">کد پستی : </span>
                                                                     <span class="animated fadeInDown Bkoodak">  {{ $address->post_code }} </span>
                                                                 </div>


                                                                 <div class="col-lg-12 text-center py-3">
                                                                     <span class="text-black-50 animated fadeInDown ">آدرس : </span>
                                                                     <span class="animated fadeInDown ">  {{ $address->address }} </span>
                                                                 </div>

                                                             </div>

                                                         </div>
                                                     </div>

                                                 @endforeach

                                             @else

                                                 <div class="col-10 card px-3 py-5 ">
                                                     <h5 class="text-center">
                                                         آدرسی ثبت نشده
                                                     </h5>
                                                 </div>

                                             @endif

                                         </div>
                                     </div>

                                     <div class="col-12 py-4 text-center ">
                                         <button class="btn btn-success btn-rounded animated fadeInUp" data-target="#createAddress" data-toggle="modal">ثبت آدرس</button>
                                     </div>

                                 </div>



                             </div>
                             <!-- Card content -->

                         </div>
                     </div>


                     <form action="{{ route('user.createAddress') }}" method="post"> @csrf
                         <div class="modal fade" id="createAddress" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                              aria-hidden="true">
                             <div class="modal-dialog  modal-notify modal-success " role="document">
                                 <div class="modal-content text-center">
                                     <div class="modal-header d-flex justify-content-center">
                                         <p class="heading"> ثبت آدرس جدید </p>
                                     </div>

                                     <div class="modal-body text-center">

                                         <div class="row justify-content-center">

                                             <div class="col-lg-8 md-form input-group mb-3">
                                                 <div class="input-group-prepend">
                                                     <span class="input-group-text md-addon animated fadeInDown" >استان </span>
                                                 </div>
                                                 <input type="text" class="form-control" name="city">
                                             </div>

                                             <div class="col-lg-8 md-form input-group mb-3">
                                                 <div class="input-group-prepend">
                                                     <span class="input-group-text md-addon animated fadeInDown" >شهر </span>
                                                 </div>
                                                 <input type="text" class="form-control" name="town">
                                             </div>

                                             <div class="col-lg-8 md-form input-group mb-3">
                                                 <div class="input-group-prepend">
                                                     <span class="input-group-text md-addon animated fadeInDown" >آدرس </span>
                                                 </div>
                                                 <input type="text" class="form-control" name="address">
                                             </div>

                                             <div class="col-lg-8 md-form input-group mb-3">
                                                 <div class="input-group-prepend">
                                                     <span class="input-group-text md-addon animated fadeInDown" >کد پستی </span>
                                                 </div>
                                                 <input type="text" class="form-control" name="post_code">
                                             </div>

                                         </div>

                                     </div>

                                     <div class="modal-footer flex-center">
                                         <a  class="btn  btn-outline-success" data-dismiss="modal">بستن</a>
                                         <button type="submit"  class="btn  btn-success waves-effect"  >ثبت</button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </form>


                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>


@stop

@section('script')

@stop
