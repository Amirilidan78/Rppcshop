@extends('home.mater')

@section('style')
    <style>
        th,tr,td{
            text-align: center;
        }
        th{
            border: none !important;
        }
    </style>
@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5 grey lighten-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-10">
                 <div class="row">

                     @include('home.user.components.nav')

                     <div class="col-lg-9 mt-1">
                         <div class="card card-cascade wider py-0 px-0 mx-0 mt-1">
                             <div class="card-body card-body-cascade text-center py-0  mx-0">
                                 <div class="row">
                                     <div class="col-12 py-3">
                                         <div class="row justify-content-center">

                                             @if(count($orders))

                                                 <div class="table-responsive   mb-3">
                                                     <table class="table table-bordered  table-hover table  ">
                                                         <thead class="">
                                                         <tr class="success-color text-white  text-nowrap">
                                                             <th scope="col"><span >شماره  سفارش</span></th>
                                                             <th scope="col"><span >تاریخ ثبت سفارش</span></th>
                                                             <th scope="col"><span >مبلغ قابل پرداخت</span></th>
                                                             <th scope="col"><span >مبلغ کل</span></th>
                                                             <th scope="col"><span >عملیات پرداخت</span></th>
                                                             <th scope="col"><span > تحویل پست</span></th>
                                                             <th scope="col"><span >جزییات</span></th>
                                                         </tr>
                                                         </thead>
                                                         <tbody>
                                                             @foreach($orders as $order)

                                                                <tr>

                                                                     <td scope="row"> <i class=" h6" >  {{$order->getOrderId()}} </i> </td>

                                                                    <td> <span class="Bkoodak h6">{{ $order->Created_at }}</span> </td>

                                                                    <td> <span class="Bkoodak h6"><x-price :price="($order->status == 0) ? $order->total_price : 0 "/></span> </td>

                                                                    <td> <span class="Bkoodak h6"><x-price :price="$order->total_price"/></span> </td>

                                                                    <td> <span class="{{($order->status == 0) ? "text-danger" : "text-success"}} "> {{($order->status == 0) ? "نا موفق" : "پرداخت موفق"}} </span> </td>

                                                                     <td><span class="{{ ($order->post_rahgiri) ? 'text-success' : 'text-danger' }}">{{ ($order->post_rahgiri) ? 'بله' : 'خیر' }}</span></td>
                                                                     <td style="cursor: pointer">
                                                                         <a href="{{ route('user.order',$order->id) }}">
                                                                            <h3 class="text-muted">></h3>
                                                                         </a>
                                                                     </td>
                                                                 </tr>
                                                             @endforeach
                                                         </tbody>
                                                     </table>
                                                 </div>

                                                 {{$orders->links('components.paginate.index')}}


                                             @else

                                                 <div class="col-10 card px-3 py-5 ">
                                                     <h5 class="text-center animated fadeInDown ">
                                                         سفارشی ثبت نشده
                                                     </h5>
                                                 </div>

                                             @endif



                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>



                     <div class="col-12" style="height: 250px"></div>

                 </div>
             </div>
        </div>
    </div>


@stop

@section('script')

@stop
