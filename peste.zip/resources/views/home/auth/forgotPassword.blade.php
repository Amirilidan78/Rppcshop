@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <section class="view intro">

        <div class="container-fluid">

            <div class="row d-flex justify-content-center align-items-center h-75 mx-md-5 mt-5 pt-5">

                <div class="col-lg-6 ">
                    <!-- Form with header -->
                    <div class="card  animated fadeInDown" data-wow-delay="0.3s">
                        <div class="card-body">

                            <!-- Header -->
                            <div class="form-header success-color">
                                <h3 class="font-weight-500 my-2 py-1">فراموشی رمز عبور</h3>
                            </div>

                            <div class="justify-content-center row" id="page1"  >
                                    <div class="col-lg-8   mb-3">
                                        <div class="md-form">
                                            <input type="text" id="phoneNumber" name="phone" class="form-control text-left Bkoodak">
                                            <label for="phone">شماره همراه</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mt-3">
                                            <div class="text-center">
                                                <button class="btn btn-success btn-rounded" id="but1" onclick="sendPhone()">
                                                    بازیابی رمز عبور
                                                    <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true" id="spinnerPage1" style="display: none"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <div class="justify-content-center row" id="page2" style="display: none">

                                <div class="col-12 text-center">
                                    <h6 class="text-center">
                                        کد ارسالی ب شماره همراه ثبت شده را وارد کنید
                                    </h6>
                                </div>

                                <div class="col-lg-8   mb-3">
                                    <div class="md-form">
                                        <input type="text" id="codeNumber" name="code" class="form-control text-left Bkoodak">
                                        <label for="codeNumber">کد ارسالی</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mt-3">
                                        <div class="text-center">
                                            <button class="btn btn-success btn-rounded btn-lg" id="but2" onclick="checkCode()">
                                                ارسال
                                                <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true" id="spinnerPage2" style="display: none"></span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="justify-content-center row" id="page3"  style="display: none">
                                    <div class="col-lg-8 text-center">
                                        <h6 class="text-center">
                                            رمز عبور جدید را وارد کنید
                                        </h6>
                                    </div>

                                    <div class="col-lg-8   mb-3">
                                        <div class="md-form">
                                            <input type="password" id="passwordChange" name="password" class="form-control text-left Bkoodak" required>
                                            <label for="passwordChange">رمز عبور جدید</label>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="mt-3">
                                            <div class="text-center">
                                                <button class="btn btn-success btn-rounded btn-lg" onclick="changePassword()" >تغییر رمز عبور</button>
                                            </div>
                                        </div>
                                    </div>
                            </div>

                        </div>
                    </div>
                    <!-- Form with header -->
                </div>

            </div>

        </div>

    </section>

@stop

@section('script')
    <script>
        var phone ;

        function sendPhone() {

            $("#spinnerPage1").fadeIn();
            $("#but1").attr("disabled", true);

            if( Mobile_Check($("#phoneNumber").val()) == false ){
                toastr.warning('لطفا شماره همراه معتبری را وارد نمایید','هشدار');
                return 1 ;
            }



            $.ajax({
                url: "{{ route('postForgotPassword') }}",
                type: "POST",
                async: true,
                cache: false,
                data: {
                    phone : $("#phoneNumber").val() ,
                    _token: "{{ csrf_token() }}"
                },
                dataType: 'json',
                success: function (result) {

                    if(result == -1)
                        toastr.error('شماره همراه نمیتواند خالی باشد','خطا');
                    else if(result == -2)
                        toastr.error('با این شماره همراه کاربری ثبت نشده','خطا');
                    else if(result == -3)
                        toastr.error('خطا در ارسال کد لطفا با پشتیبانی تماس بگیرید','خطا');
                    else if(result == -4)
                        toastr.error('حد مجاز اس ام اس رسیدید','خطا');
                    else{
                        phone =  $("#phoneNumber").val() ;
                        $('#page1').hide();
                        $('#page2').fadeIn();
                    }

                    $("#spinnerPage1").fadeOut();
                    $("#but1").attr("disabled", false);

                }
            });




        }
        function checkCode() {


            $("#spinnerPage2").fadeIn();
            $("#but2").attr("disabled", true);

            $.ajax({
                url: "{{ route('postCheckCode') }}",
                type: "POST",
                async: true,
                cache: false,
                data: {
                    phone : phone ,
                    code : $("#codeNumber").val() ,
                    _token: "{{ csrf_token() }}"
                },
                dataType: 'json',
                success: function (result) {

                    $("#code").val('');

                    if(result == -1)
                        toastr.error(' کد نمیتواند خالی باشد','خطا');
                    else if(result == -2)
                        toastr.error('با این شماره همراه کاربری ثبت نشده','خطا');
                    else if(result == -3)
                        toastr.error('کد وارد شده اشتباه است','خطا');
                    else if(result == -4)
                        toastr.error('حد مجاز اس ام اس رسیدید','خطا');
                    else{

                        $('#page2').hide();
                        $('#page3').fadeIn();
                    }


                    $("#spinnerPage2").fadeOut();
                    $("#but2").attr("disabled", false);

                }
            });
        }
        function changePassword() {

            $.ajax({
                url: "{{ route('postChangePassword') }}",
                type: "POST",
                async: true,
                cache: false,
                data: {
                    phone : phone ,
                    password : $("#passwordChange").val() ,
                    _token: "{{ csrf_token() }}"
                },
                dataType: 'json',
                success: function (result) {

                    if(result == -1)
                        toastr.error(' رمز عبور نمیتواند خالی باشد','خطا');
                    else if(result == -2)
                        toastr.error('با این شماره همراه کاربری ثبت نشده','خطا');
                    else if(result == -3)
                        toastr.error(' رمز عبور نمیتواند کمتر از 8 حرف باشد','خطا');
                    else{

                        toastr.success('رمز عبور شما با موفقیت تغییر کرد','اطلاعیه');
                        $('#login').modal({
                            'show' : true
                        });
                        $("#phone").val(phone);
                        $("#phone").focus();
                        $("#password").focus();
                        $("#password").val($("#passwordChange").val());

                    }

                }
            });
        }
    </script>
@stop
