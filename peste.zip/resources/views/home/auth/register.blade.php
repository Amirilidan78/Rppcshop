@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <section class="view intro">

        <div class="container-fluid">

            <div class="row d-flex justify-content-center align-items-center h-75 mx-md-5 mt-5">

                <div class="col-lg-10">
                    <!-- Form with header -->
                    <div class="card  animated fadeInDown" data-wow-delay="0.3s">
                        <div class="card-body">

                            <!-- Header -->
                            <div class="form-header success-color">
                                <h3 class="font-weight-500 my-2 py-1">ثبت نام</h3>
                            </div>

                            <form action="{{url('/register')}}" method="post"  id="formRegister">
                                <!-- Body -->@csrf

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نام</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="name" id="name">
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >نام خانوادگی</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="last_name" id="last_name">
                                    </div>
                                </div>

                                <div class="justify-content-center row">
                                    <div class="col-lg-8 md-form input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text md-addon  animated fadeInDown"  >شماره همراه</span>
                                        </div>
                                        <input type="text" class="form-control Bkoodak" name="phone" id="phoneRegister">
                                    </div>
                                </div>

{{--                                <div class="justify-content-center row">--}}
{{--                                    <div class="col-lg-8 md-form input-group mb-3">--}}
{{--                                        <div class="input-group-prepend">--}}
{{--                                            <span class="input-group-text md-addon  animated fadeInDown"  >کدملی</span>--}}
{{--                                        </div>--}}
{{--                                        <input type="text" class="form-control Bkoodak" name="code_melli">--}}
{{--                                    </div>--}}
{{--                                </div>--}}

                                <div class="row">
                                    <div class="col-12 text-center ">
                                        <br>
                                        <p>
                                            <i class="fas fa-star pt-2 text-danger"></i>
                                            <span class="text-danger"> رمز عبور پس از ثبت نام به شماره همراه شما ارسال خواهد شد </span>
                                        </p>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <div class="text-center">
                                        <button class="btn btn-success btn-rounded btn-lg" type="submit">ثبت نام</button>
                                    </div>
                                </div>

                            </form>

                        </div>
                    </div>
                    <!-- Form with header -->
                </div>

            </div>

        </div>

    </section>

@stop

@section('script')
    <script>


        $( "#formRegister" ).submit(function( event ) {

            if( Mobile_Check($("#phoneRegister").val()) == false ){
                event.preventDefault();
                toastr.warning('لطفا شماره همراه معتبری را وارد نمایید','هشدار');
            }

            if( $('#name').val().length < 3 ){
                event.preventDefault();
                toastr.warning('نام نمیتواند کمتر از 3 حرف باشد','هشدار');
            }

            if( $('#last_name').val().length < 3 ){
                event.preventDefault();
                toastr.warning('نام خانوادگی نمیتواند کمتر از 3 حرف باشد','هشدار');
            }

        });

    </script>
@stop
