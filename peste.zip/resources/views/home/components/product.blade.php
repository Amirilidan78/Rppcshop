<div class="col-lg-3 col-md-12 mb-4">

    <!-- Card -->
    <div class="card card-ecommerce">

        <div class="view overlay">
            <img src="{{($image) ? $image : asset('images/placeHolder.jpg')}}" class="img-fluid" alt="">
            <a>
                <div class="mask rgba-white-slight waves-effect waves-light"></div>
            </a>
        </div>

        <div class="card-body">

            <h5 class="card-title mb-1">
                <strong>
                    <a href="" class="dark-grey-text">{{$Name}}</a>
                </strong>
            </h5>

            @if($available)
                <span class="badge badge-success mb-2">موجود</span>
            @else
                <span class="badge badge-danger mb-2">تمام شد</span>
            @endif

{{--            <ul class="rating">--}}


{{--                @for($i = 0 ; $i < $ratingsBlue ; $i++)--}}
{{--                    <li>--}}
{{--                        <i class="fas fa-star blue-text"></i>--}}
{{--                    </li>--}}
{{--                @endfor--}}

{{--                @for($j = 0 ; $j < $ratingsGrey ; $j++)--}}
{{--                    <li>--}}
{{--                        <i class="fas fa-star grey-text"></i>--}}
{{--                    </li>--}}
{{--                @endfor--}}

{{--            </ul>--}}

            <div class="card-footer pb-0 " style="border: none">
                <div class="row mb-0">
                  <h5 >
                    <strong class="Bkoodak">
                        @php($price = $product->price)
                        <strong class="Bkoodak">
                            <x-price :price="$price" />
                        </strong>
                    </strong>
                      تومان
                  </h5>
                </div>
            </div>

            <div class="text-center">
                <a class="btn btn-primary btn-rounded" href="{{route('showProduct',$Name)}}">
                    نمایش
                </a>
            </div>

        </div>

    </div>

    <!-- Card -->
</div>
