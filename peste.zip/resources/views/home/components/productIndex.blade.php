<!-- Grid column -->
<div class="col-lg-4 col-md-12 mb-lg-0 mb-4">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-1">
        <img src="{{$image}}" class="img-fluid"
             alt="عکس">
        <a>
            <div class="mask rgba-white-slight"></div>
        </a>
    </div>
    <!--Excerpt-->
    <div class="card-body pb-0">
        <h4 class="font-weight-bold my-3">{{$Name}}</h4>
        <p class="grey-text">
           {!! $short_description !!}
        </p>
        <p >
            <span class="Bkoodak">
                @Price(['price'=>$price]) @endPrice
            </span>
            <span>
                تومان
            </span>
        </p>
        <ul class="list-unstyled mb-0">
            <li>
                <a class="btn btn-success btn-rounded" href="{{route('showProduct',$id)}}">
                    نمایش
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- Grid column -->
