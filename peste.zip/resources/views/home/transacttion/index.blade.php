@extends('home.mater')

@section('style')
@stop

@section('intro')

@stop

@section('body')

    <div class="container-fluid my-5">
        <div class="row pt-5 justify-content-center">
             <div class="col-lg-10 text-center">

                 <form action="{{ route('postTransaction') }}" method="post"> @csrf
                     <input type="hidden" name="order_id" value="{{$order->id}}">
                     <input type="hidden" name="status" value="1">
                    <button class="btn btn-success btn-rounded">پرداخت موفق</button>
                 </form>

                 <form action="{{ route('postTransaction') }}" method="post"> @csrf
                     <input type="hidden" name="order_id" value="{{$order->id}}">
                     <input type="hidden" name="status" value="0">
                    <button class="btn btn-danger btn-rounded">پرداخت نا موفق</button>
                 </form>

             </div>
        </div>
    </div>


@stop

@section('script')

@stop
