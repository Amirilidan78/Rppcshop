@extends('home.mater')

@section('style')
    <link href="https://rppcshop.ir/404" rel="canonical" >

@stop

@section('intro')

@stop

@section('body')
    <div class="container vh-100">

        <!-- Grid row -->
        <div class="row d-flex align-items-center h-100">

            <!-- Grid column -->
            <div class="col-12">

                <!--Section: Block Content-->
                <section class="mt-70 mb-5 text-center">

                    <h1 class="display-1">404</h1>

                    <h2 class="mb-4 h4">صفحه مورد نظر یافت نشد</h2>

                    <p class="mb-0">صفحه ای که به دنبال آن میگردید یافت نشد یا خطایی رخ داده است</p>
                    <br>
                    <a href="{{ url('') }}" class="btn btn-info btn-rounded">صفحه اصلی</a>

                </section>
                <!--Section: Block Content-->

            </div>
            <!-- Grid column -->

        </div>
        <!-- Grid row -->

    </div>


@stop

@section('script')

@stop
