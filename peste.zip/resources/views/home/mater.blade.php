<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>  {{  $pageTitle ?? $title }}</title>

    <link rel="home" href="{{ $home }}" />
    <meta name="keywords" content="{!! $keywords  !!}" />
    <meta name="description" content="{{ $pageDescription ?? $description ?? "فروشگاه اینترنتی شرکت تعاونی پسته رفسنجان" }}" >
    {{--og--}}
    <meta property=”og:site_name” content="{{ $og['site_name'] }}" />
    <meta property=”og:locale” content="{{ $og['locale'] }}" />
    <meta property=”og:url” content={{ $og['url'] }} />
    <meta property=”og:type” content="{{ $og['type'] }}" />
    <meta property=”og:description” content="{{ $og['description'] }}" />
    <meta property=”og:image” content="{{ $og['image'] }}" />

    <?php $twitterSpecial ?? $twitterSpecial = null ; ?>
    @if($twitterSpecial)
        {{--twitter--}}
        <meta name=”twitter:card” content="{{ $twitterSpecial['card'] }}" />
        <meta name=”twitter:title” content="{{ $twitterSpecial['title'] }}" />
        <meta name=”twitter:description” content="{{ $twitterSpecial['description'] }}" />
        <meta name=”twitter:url” content="{{ $twitterSpecial['url'] }}" />
        <meta name=”twitter:image” content="{{ $twitterSpecial['image'] }}" />
        <meta name=”twitter:creator” content="{{ $twitterSpecial['creator'] }}" />
    @else
        {{--twitter--}}
        <meta name=”twitter:card” content="{{ $twitter['card'] }}" />
        <meta name=”twitter:title” content="{{ $twitter['title'] }}" />
        <meta name=”twitter:description” content="{{ $twitter['description'] }}" />
        <meta name=”twitter:url” content="{{ $twitter['url'] }}" />
        <meta name=”twitter:image” content="{{ $twitter['image'] }}" />
        <meta name=”twitter:creator” content="{{ $twitter['creator'] }}" />
    @endif

    {{--geo--}}
    <meta NAME="geo.position" CONTENT="{{ $geo['position'] }}">
    <meta NAME="geo.placename" CONTENT="{{ $geo['placename'] }}">
    <meta NAME="geo.region" CONTENT="{{ $geo['region'] }}">


    @yield('meta')

    <meta http-equiv="language" content="fa">
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-164629643-1"></script>

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-M2KPTM2');</script>
    <!-- End Google Tag Manager -->

    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-164629643-1');
    </script>



    <link rel="stylesheet" href="{{url('awesome/css/all.css')}}">

    <link href="{{asset('home/font/bkoodak/Bkoodak.css')}}" rel="stylesheet">
    <script>
        function goToProductPage(title) {
            window.location.href = "{{url('product')}}"+'/'+title ;
        }
    </script>
    <link rel="stylesheet" href="{{asset('awesome/css/all.css')}}">
    <link href="{{asset('home/css/all.min.css')}}" rel="stylesheet">
    @yield('style')

</head>

<body class="coworking-page">

<!-- Main navigation -->
<header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg scrolling-navbar navbar-light z-depth-0 fixed-top white">
        <a class="navbar-brand text-success" href="{{url('')}}">
            <img src="{{ asset('img/logo.PNG') }}" title="لوگو فروشگاه شرکت تعاونی پسته رفسنجان" alt="لوگو فروشگاه شرکت تعاونی پسته رفسنجان" style="width: 60px;">
        </a>

        <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
            <ul class="navbar-nav ml-auto text-uppercase smooth-scroll">

                <li class="nav-item">
                    <a class="nav-link heather-color animated fadeInDown" href="{{url('')}}" data-offset="100">
                        <i class="fas fa-home"></i>
                        <strong>صفحه اصلی</strong>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link heather-color animated fadeInDown" href="{{url('products')}}" data-offset="100">
                        <i class="fas fa-box-open"></i>
                        <strong>محصولات</strong>
                    </a>
                </li>


                <li class="nav-item">
                    <a class="nav-link heather-color animated fadeInDown" href="{{url('blog')}}" data-offset="100">
                        <i class="far fa-list-alt"></i>
                        <strong>وبلاگ</strong>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link heather-color animated fadeInDown" href="{{route('showAboutUs')}}" data-offset="100">
                        <i class="far fa-address-card"></i>
                        <strong>درباره ما</strong>
                    </a>
                </li>



            </ul>
            <ul class="navbar-nav mr-auto text-uppercase smooth-scroll">

                <li class="nav-item">

                    @if(session('user'))
                        <a class="nav-link heather-color animated fadeInDown" href="{{ url('/userDashboard') }}">
                            <i class="fas fa-user-alt"></i>
                            <strong>{{session('user')['name'] . ' ' . session('user')['last_name']}}</strong>
                        </a>
                    @else
                        <a class="nav-link heather-color animated fadeInDown" data-toggle="modal" data-target="#login" data-offset="100">
                            <i class="fas fa-user-alt"></i>
                            <strong>حساب کاربری</strong>
                        </a>
                    @endif

                </li>


            </ul>
        </div>

        <a class="nav-link pt-0-1" href="{{url('cart')}}" data-offset="100">
            <button type="button" class="btn btn-outline-success btn-rounded btn-md z-depth-0 m-0 pt-2 " id="cartButton">
                سبد خرید <i class="fas fa-shopping-basket"></i>
                <span class="badge badge-success rounded" id="cartIndex">
                                @if(session("user_basket"))
                        @php($count = 0 )
                        @foreach(session("user_basket") as $i)
                            @php($count += $i['count'])
                        @endforeach
                        {{$count}}
                    @else
                        0
                    @endif
                  </span>
            </button>
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-4"
                aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    </nav>
    <!-- Navbar -->

    @yield('intro')


</header>
<!-- Main navigation -->

<!-- Main layout -->
<main>

    <section>
        <div class="container">

            <!-- Central Modal Medium Success -->
            <form  action="{{ route('loginUser') }}" method="post" id="formLogin"> @csrf
                <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog modal-notify modal-success" role="document">
                        <!--Content-->
                        <div class="modal-content">
                            <!--Header-->
                            <div class="modal-header">
                                <p class="heading lead">
                                    <i class="fas fa-user text-white"></i>
                                    ورود به حساب کاربری
                                </p>

                            </div>

                            <!--Body-->
                            <div class="modal-body">
                                <div class="text-center">

                                    <div class="text-center" style="color: #757575;">
                                        <div class="md-form">
                                            <input type="text" id="phone" name="phone" class="form-control text-left Bkoodak">
                                            <label for="phone">شماره همراه</label>
                                        </div>
                                        <div class="md-form">
                                            <input type="password" id="password" name="password" class="form-control text-left Bkoodak">
                                            <label for="password">رمز عبور</label>
                                        </div>

                                        <!-- Register -->
                                        <p> هنوز
                                            <a href="{{ url('/register') }}">ثبت نام</a>
                                            نکرده اید!؟
                                        </p> <!-- Register -->
                                        <p>
                                            رمز عبور خود را
                                            <a href="{{ url('/forgotPassword') }}">فراموش</a>
                                            کرده اید!؟
                                        </p>

                                    </div>

                                </div>
                            </div>

                            <!--Footer-->
                            <div class="modal-footer justify-content-center">
                                <button type="submit" class="btn btn-success">
                                    ورود
                                    <i class="fas fa- ml-1 mr-1 text-white"></i>
                                </button>
                                <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">بستن</a>
                            </div>
                        </div>
                        <!--/.Content-->
                    </div>
                </div>
            </form>
            <!-- Central Modal Medium Success-->

        </div>
    </section>

    @yield('body')
</main>
<!-- Main layout -->

<!-- Footer -->
<footer class="page-footer font-small unique-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">

        <!-- Grid row -->
        <div class="row justify-content-center" >

            <div class="col-lg-9">
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-4 mx-auto ">

                        <h3 class="font-weight-bold text-uppercase mt-3 h5 mb-4">فروشگاه اینترنتی شرکت تعاونی پسته رفسنجان</h3>
                        <p>
                            برای خرید حضوری میتوانید با شماره
                            <span class="Bkoodak">{{ $phone_master ?? '' }}</span>
                            تماس حاصل فرمایید .
                            آدرس دفتر
                            {{ $address_master ?? '' }}
                        </p>
                    </div>
                    <!-- Grid column -->


                    <hr class="clearfix w-100 d-md-none">


                    <!-- Grid column -->
                    <div class="col-md-5 text-center text-md-right">

                        <br>
                        <p>
                            <i class="fas fa-home mr-3"></i> {{ $address_master ?? "شهرک آفتاب , آفتاب 12 , پلاک 17" }} </p>
                        <p>
                            <i class="fas fa-envelope mr-3"></i> {{ $email_master ?? "rafila@gmail.com" }}</p>
                        <p>
                            <i class="fas fa-phone mr-3"></i>  <span class="Bkoodak">{{ $phone_master ?? "34323072" }}</span> </p>

                    </div>


                    <hr class="clearfix w-100 d-md-none">

                    <!-- Grid column -->
                    <div class="col-md-2 mx-auto">

                        <br>
                        <ul class="list-unstyled text-center text-md-right">
                            <li>
                                <a href="{{ url('/contact') }}">ارتباط با ما</a>
                            </li>
                            <li>
                                <a href="{{ url('/aboutUs') }}">درباره ما</a>
                            </li>
                            <li>
                                <a href="{{ url('/help') }}">راهنما</a>
                            </li>
                            <li>

                            </li>
                        </ul>

                    </div>
                    <!-- Grid column -->


                    <hr class="clearfix w-100 d-md-none">

                    <!-- Grid column -->
                    <div class="col-md-1 mx-auto text-center pb-3">

                        <script src="https://cdn.zarinpal.com/trustlogo/v1/trustlogo.js" type="text/javascript"></script>

                    </div>
                </div>
            </div>

        </div>
        <!-- Grid row -->

    </div>
    <!-- Footer Links -->

{{--    <hr>--}}
{{--    <aside>--}}
{{--        <div class="footer-copyright text-center py-3 mt">--}}


{{--            <a href="https://www.instagram.com/corona_national_award/" class="px-3 pt-2">--}}
{{--                <i class="fab fa-instagram " style="font-size: 18px"></i>--}}
{{--            </a>--}}

{{--            <a href="https://t.me/Corona_National_Award" class="px-3 pt-2">--}}
{{--                <i class="fab fa-telegram " style="font-size: 18px"></i>--}}
{{--            </a>--}}



{{--        </div>--}}
{{--    </aside>--}}
{{--    --}}
    <div class="footer-copyright text-center py-3 -3">
        © 2020 Copyright:
        <a href="https://www.linkedin.com/in/amir-ranjbar-9214b2179/" rel="nofollow">
            <i class="fab fa-linkedin"></i>
            Amir Ranjbar
        </a>
    </div>
    <!-- Copyright -->

</footer>
<!-- Footer -->

<script type="text/javascript" src="{{asset('home/js/all.min.js')}}"></script>

<script>
    function Mobile_Check(input) {
        if( input = 'namad')
            return  true ;

        if (!/09(0[0-9]|1[0-9]|3[0-9]|2[0-9])-?[0-9]{3}-?[0-9]{4}$/.test(input))
            return false;
        else return true;
    }
    $( "#formLogin" ).submit(function( event ) {

        if( Mobile_Check($("#phone").val()) == false ){
            event.preventDefault();
            toastr.warning('لطفا شماره همراه معتبری را وارد نمایید','هشدار');
        }

        if( $('#password').val().length < 8 ){
            event.preventDefault();
            toastr.warning('رمز عبور نمیتواند کمتر از 8 حرف باشد','هشدار');
        }

    });
    @if(session('guestAlert'))
    @if(session('guestAlert')[0] == false)
    toastr.error("{{session('guestAlert')[1]}}",'خطا') ;
    @elseif(session('guestAlert')[0] == true)
    toastr.success("{{session('guestAlert')[1]}}",'اطلاعیه') ;
    @else
    toastr.info("{{session('guestAlert')[1]}}",'اطلاعیه') ;
    @endif
    @endif
</script>
@yield('script')
</body>

</html>
