@extends('home.mater')

@section('style')
    <link href="https://rppcshop.ir/products" rel="canonical" >
@stop
@section('style')
    <style>
        .form-check-inline {
            width: 100% !important;
            padding-left: 15px;
        }
        .form-check-label  {
            width: 100% !important;
        }
        .list-group-item-action{
            cursor: default !important ;
        }
    </style>
@stop

@section('body')

    <!-- Modal: modalPoll -->
    <div class="modal fade right" id="filter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="false">
        <div class="modal-dialog modal-full-height modal-right modal-notify modal-success" role="document">
            <div class="modal-content">
                <!--Header-->
                <div class="modal-header">
                    <p class="heading lead">
                        فیلتر محصولات
                    </p>

                </div>

                <!--Body-->
                <div class="modal-body">
                    <div class="text-center">

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع فرآورده
                            </a>

                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="sm_is_salid" {{(in_array("1",$is_salty)) ? "checked" : null}} >
                                    <label class="form-check-label" for="sm_is_salid">شور</label>
                                </div>
                            </a>

                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" id="sm_not_salid" {{(in_array("0",$is_salty)) ? "checked" : null}}>
                                    <label class="form-check-label" for="sm_not_salid">خام</label>
                                </div>
                            </a>

                        </div>

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع بسته بندی
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="1" id="sm_packing1" {{(in_array("1",$packing)) ? "checked" : null}}>
                                    <label class="form-check-label" for="sm_packing1">سلوفون</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="2" id="sm_packing2" {{(in_array("2",$packing)) ? "checked" : null}}>
                                    <label class="form-check-label" for="sm_packing2">قوطی</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="3" id="sm_packing3" {{(in_array("3",$packing)) ? "checked" : null}}>
                                    <label class="form-check-label" for="sm_packing3">جعبه</label>
                                </div>
                            </a>


                            <a class="list-group-item list-group-item-action" style="cursor: default">
                                <div class="form-check text-right form-check-inline">
                                    <input type="checkbox" class="form-check-input" value="4" id="sm_packing4" {{(in_array("4",$packing)) ? "checked" : null}}>
                                    <label class="form-check-label" for="sm_packing4">کارتون</label>
                                </div>
                            </a>


                        </div>

                        <div class="list-group mt-4">
                            <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                نوع پسته
                            </a>
                            @foreach($groups as $group)
                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                    <div class="form-check text-right form-check-inline">
                                        <input type="checkbox" class="form-check-input" id="sm_group{{$group->id}}" value="{{$group->id}}" {{(in_array("{$group->id}",$filterGroups)) ? "checked" : null}}>
                                        <label class="form-check-label" for="sm_group{{$group->id}}">{{$group->name}}</label>
                                    </div>
                                </a>
                            @endforeach
                        </div>

                    </div>

                </div>

                <!--Footer-->
                <div class="modal-footer justify-content-center">
                    <a type="button" class="btn btn-success waves-effect waves-light" onclick="filter2()">
                        فیلتر
                    </a>
                    <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">
                        بستن
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal: modalPoll -->


    <div class="container-fluid grey lighten-5">
        <div class="row justify-content-center">
            <div class="col-lg-10 pt-2">
                <section class="section pt-5">
                    <div class="row pt-5 justify-content-center">


                        <div class="col-12">
                            <div class="row">

                                <div class="col-lg-3 d-none  d-lg-block">
                                    <nav>
                                        <div class="card py-3 px-4 pb-5 ">

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع فرآورده
                                                </a>

                                                <a class="list-group-item list-group-item-action" >
                                                    <div class="form-check text-right form-check-inline" >
                                                        <input type="checkbox" class="form-check-input" id="is_salid"  {{(in_array("1",$is_salty)) ? "checked" : null}} >
                                                        <label class="form-check-label" for="is_salid" >شور</label>
                                                    </div>
                                                </a>

                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" id="not_salid" {{(in_array("0",$is_salty)) ? "checked" : null}}>
                                                        <label class="form-check-label" for="not_salid">خام</label>
                                                    </div>
                                                </a>

                                            </div>

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع بسته بندی
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="1" id="packing1" {{(in_array("1",$packing)) ? "checked" : null}}>
                                                        <label class="form-check-label" for="packing1">سلوفون</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="2" id="packing2" {{(in_array("2",$packing)) ? "checked" : null}}>
                                                        <label class="form-check-label" for="packing2">قوطی</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="3" id="packing3" {{(in_array("3",$packing)) ? "checked" : null}}>
                                                        <label class="form-check-label" for="packing3">جعبه</label>
                                                    </div>
                                                </a>


                                                <a class="list-group-item list-group-item-action" style="cursor: default">
                                                    <div class="form-check text-right form-check-inline">
                                                        <input type="checkbox" class="form-check-input" value="4" id="packing4" {{(in_array("4",$packing)) ? "checked" : null}}>
                                                        <label class="form-check-label" for="packing4">کارتون</label>
                                                    </div>
                                                </a>


                                            </div>

                                            <div class="list-group mt-4">
                                                <a  class="list-group-item list-group-item-action active text-center text-white success-color border-success" style="cursor: default">
                                                    نوع پسته
                                                </a>
                                                @foreach($groups as $group)
                                                    <a class="list-group-item list-group-item-action" style="cursor: default">
                                                        <div class="form-check text-right form-check-inline">
                                                            <input type="checkbox" class="form-check-input" id="group{{$group->id}}" value="{{$group->id}}" {{(in_array("{$group->id}",$filterGroups)) ? "checked" : null}}>
                                                            <label class="form-check-label" for="group{{$group->id}}">{{$group->name}}</label>
                                                        </div>
                                                    </a>
                                                @endforeach
                                            </div>

                                            <div class="col-12 text-center mt-3">
                                                <a   class="btn btn-success   waves-effect"  onclick="filter()">فیلتر</a>
                                            </div>


                                        </div>
                                    </nav>
                                </div>

                                <div class="col-lg-9">

                                    <div class="row">
                                        <div class="col-lg-6 mb-3">
                                            <nav>
                                                <h1 class="text-right text-muted h6">
                                                <span >
                                                    فروشگاه  شرکت تعاونی پسته رفسنجان / محصولات

                                                    @if($groupsName)
                                                        /
                                                        @foreach($groupsName as $key => $name)
                                                            @if($key != 0)
                                                                ,
                                                            @endif
                                                            {{$name['name']}}

                                                        @endforeach
                                                    @endif
                                                </span>

                                                    {{--                                                <span class="float-left">--}}
                                                    {{--                                                    {{ count($products) }}--}}
                                                    {{--                                                     کالا--}}
                                                    {{--                                                </span>--}}
                                                </h1>
                                            </nav>
                                        </div>

                                        <div class="col-lg-6 mb-3 d-none  d-lg-block text-left">
                                            <i class="fab fa-buromobelexperte fa-2x text-muted text-success mx-1 "></i>
                                        </div>
                                    </div>


                                    <div class="row d-block d-lg-none">
                                        <div class="col-12 text-center pb-3">
                                            <button type="button" class="btn btn-success btn-rounded" data-toggle="modal" data-target="#filter">
                                                فیلتر محصولات
                                            </button>
                                        </div>
                                    </div>

                                    <div class="row">

                                        @if(count($products) > 0)

                                            @foreach($products as $product)

                                                <x-dashboardProduct
                                                    :product="$product"
                                                    size="4"
                                                    />

                                            @endforeach


                                                <div class="col-lg-12 text-center justify-content-center mt-5">
                                                    <div class="row justify-content-center">
                                                        <div class="col-lg-12">{{$products->links('components.paginate.index')}}</div>
                                                    </div>
                                                </div>

                                                <div class="col-12 pt-3 text-center">
                                                    @foreach($tags as $tag)
                                                        <x-tag :name="$tag->name" hidden="true" />
                                                    @endforeach
                                                </div>

                                        @else

                                            <div class="col-12 text-center">
                                                <h5 class="text-center">
                                                    محصولی ثبت نشده
                                                </h5>
                                            </div>

                                        @endif



                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </section>
            </div>
        </div>

        <div class="row">
            <div class="col-12" style="height: 100px"></div>
        </div>
    </div>

@stop

@section('script')
    <script>
        var salty = [] ;
        var groups = [] ;
        var packing  = [];

        function filter() {

            if($("#is_salid").is(':checked'))
                salty.push( 1 );
            if($("#not_salid").is(':checked'))
                salty.push( 0 );


            @foreach($groups as $group)
                if($("#group{{$group->id}}").is(':checked'))
                    groups.push( $("#group{{$group->id}}").val() );
            @endforeach


            if($("#packing1").is(':checked'))
                packing.push( 1 );

            if($("#packing2").is(':checked'))
                packing.push( 2 );

            if($("#packing3").is(':checked'))
                packing.push( 3 );

            if($("#packing4").is(':checked'))
                packing.push( 4 );


            window.location.href = "{{url('/products?')}}"+"salty="+salty+"&"+"groups="+groups+"&"+"packing="+packing;


        }
        function filter2() {

            if($("#sm_is_salid").is(':checked'))
                salty.push( 1 );
            if($("#sm_not_salid").is(':checked'))
                salty.push( 0 );


            @foreach($groups as $group)
                if($("#sm_group{{$group->id}}").is(':checked'))
                    groups.push( $("#sm_group{{$group->id}}").val() );
            @endforeach


            if($("#sm_packing1").is(':checked'))
                packing.push( 1 );

            if($("#sm_packing2").is(':checked'))
                packing.push( 2 );

            if($("#sm_packing3").is(':checked'))
                packing.push( 3 );

            if($("#sm_packing4").is(':checked'))
                packing.push( 4 );


            window.location.href = "{{url('/products?')}}"+"salty="+salty+"&"+"groups="+groups+"&"+"packing="+packing;


        }
        // popovers Initialization
        $(function () {
            $('.example-popover').popover({
                container: 'body'
            })
        })

    </script>
@stop



