@extends('blog.layout.mater')

@section('style')

@stop

@section('intro')
    <div class="jumbotron jumbotron-image color-grey-light m-0 p-0" style="background: url('{{asset('img/logo.PNG')}}') center center no-repeat; height: 400px;">
        <div class="mask rgba-black-strong d-flex align-items-center h-100 m-0 p-0" >
            <div class="container-fluid text-center white-text py-5 m-0 p-0 text-center">
                <h1 class="mb-3">وبلاگ</h1>
                {{--                <p class="mb-0"><i class="fas fa-quote-left mr-2"></i>Style is something each of us already has, all we need to do is find it</p>--}}
            </div>
        </div>
    </div>

@stop

@section('body')

    <div class="container mt-5 mb-4">

        <section>

            <div class="row">

                @foreach($posts as $post)
                    <div class="col-md-6 mb-4">

                        <!-- Card -->
                        <div class="">

                            <div class="view overlay z-depth-2 rounded">
                                <img class="img-fluid w-100" src="{{ ( $post->image ) ? asset("{$post->image}") : asset("images/5.jpg") }}" alt="Sample">
                                <a href="#!">
                                    <div class="mask rgba-white-slight waves-effect waves-light"></div>
                                </a>
                            </div>

                            <div class="text-center pt-4">

                                <h2>{{ $post->title }}</h2>
                                <p>
                                    {!! \Illuminate\Support\Str::substr($post->text , 0 , 200) !!}
                                    ...
                                </p>
                                <a href="{{ url("/blog/post/{$post->id}") }}"  class="btn btn-primary btn-rounded btn-md mr-1 mb-2 waves-effect waves-light">نمایش</a>

                            </div>

                        </div>
                        <!-- Card -->

                    </div>
                @endforeach


                    <div class="col-12">
                        {{$posts->links('components.paginate.index')}}
                    </div>


            </div>



        </section>

    </div>

@stop

@section('script')

@stop

