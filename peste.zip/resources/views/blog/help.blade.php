@extends('home.mater')

@section('style')

@stop

@section('intro')
@stop

@section('body')

    <div class="container mt-5 pt-5">

        <!--Grid row-->
        <div class="row pt-3">

            <!--Grid column-->
            <div class="col-md-6 mb-4">

                <!--Section: Intro-->
                <section>

                    <!-- Featured image -->
                    <div class="view overlay rounded z-depth-1-half mb-4" >
                        <img src="{{ asset('images/help.jpg') }}" class="img-fluid " alt="help">
                        <a href="">
                            <div class="mask rgba-white-slight waves-effect waves-light"></div>
                        </a>
                    </div>
                    <!-- Featured image -->

                </section>
                <!--Section: Intro-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-6 mb-4 px-5">

                <!--Section: Intro-->
                <section>
                    <!-- Post data -->
                    <div class="post-data d-flex justify-content-between my-4 mb-2">

                        <h1 class="ml-1 h3 black-text">
                            راهنما
                        </h1>
                        <!-- Author -->

                    </div>
                    <!-- Post data -->

                </section>
                <!--Section: Intro-->

                <hr>

                <!-- Text -->
                <section class="text-justify">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam architecto excepturi fugiat maxime perferendis quisquam sequi soluta voluptas, voluptates voluptatibus! Accusantium in, iure. Consequatur dolorem explicabo harum modi repellat. Atque est exercitationem fugit hic illo omnis quae, rem saepe veniam veritatis. Animi commodi corporis est ex fugiat, minima molestiae nisi non nulla, odio quisquam vitae voluptatibus. Aliquam eaque error, excepturi facere fugit repellat rerum sequi voluptatibus? Ab accusamus ad aliquid aperiam consequatur exercitationem molestiae officia provident quas quasi quis quo ullam, veritatis? Accusamus, est, odit! Adipisci beatae, dignissimos dolores, eos exercitationem laudantium magnam minima natus nesciunt porro praesentium provident quis.
                    </p>
                </section>
                <!-- Text -->


            </div>
            <!--Grid column-->


        </div>
        <!--Grid row-->

        <div class="row">
            <div class="col-12" style="height: 150px"></div>
        </div>

    </div>


@stop

@section('script')

@stop
