@extends('blog.layout.mater')

@section('style')
    <style>

    </style>
@endsection

@section('meta')

    <meta property=”article:tag” content="{{ $article['tag'] }}" />
    <meta property=”article:section” content="{{ $article['section'] }}" />
    <meta property=”article:published_time” content="{{ $article['published_time'] }}" />
    <meta property=”article:modified_time” content="{{ $article['modified_time']}}" />

@stop


@section('body')

    <div class="container mt-5 pt-5">

        <!--Grid row-->
        <div class="row pt-3">

            <!--Grid column-->
            <div class="col-md-6 mb-4">

                <!--Section: Intro-->
                <section>

                    <!-- Featured image -->
                    <div class="view overlay rounded z-depth-1-half mb-4" >
                        <img src="{{ ( $post->image ) ? asset("{$post->image}") : asset("images/5.jpg") }}" class="img-fluid " alt="{{ $post->title }}">
                        <a href="">
                            <div class="mask rgba-white-slight waves-effect waves-light"></div>
                        </a>
                    </div>
                    <!-- Featured image -->

                </section>
                <!--Section: Intro-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-6 mb-4 px-5">

                <!--Section: Intro-->
                <section>
                    <!-- Post data -->
                    <div class="post-data d-flex justify-content-between my-4 mb-2">

                        <h1 class="ml-1 h3 black-text">
                            {!! $post->title !!}
                        </h1>
                        <!-- Author -->

                    </div>
                    <!-- Post data -->

                </section>
                <!--Section: Intro-->

                <hr>

                <!-- Text -->
                <section class="text-justify">
                    <p>
                        {!! $post->text !!}
                    </p>
                </section>
                <!-- Text -->


            </div>
            <!--Grid column-->


        </div>
        <!--Grid row-->

        <div class="row">
            <div class="col-12" style="height: 150px"></div>
        </div>

    </div>


@stop

@section('script')

@endsection

