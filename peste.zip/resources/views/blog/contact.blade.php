@extends('home.mater')

@section('style')
    <style>

    </style>
@endsection

@section('body')


    <div class="container mt-5 pt-5">

        <!--Grid row-->
        <div class="row pt-3">

            <!--Grid column-->
            <div class="col-md-6 mb-4">

                <!--Section: Intro-->
                <section>

                    <!-- Featured image -->
                    <div class="view overlay rounded z-depth-1-half mb-4" >
                        <img src="{{ asset('images/contact.jpg') }}" class="img-fluid " style="width: 100%;" alt="contact">
                        <a >
                            <div class="mask rgba-white-slight waves-effect waves-light"></div>
                        </a>
                    </div>
                    <!-- Featured image -->

                </section>
                <!--Section: Intro-->

            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-md-6 mb-4 px-5">

                <!--Section: Intro-->
                <section>
                    <!-- Post data -->
                    <div class="post-data d-flex justify-content-between my-4 mb-2">

                        <h1 class="ml-1 h3 black-text">
                            ارتباط با ما
                        </h1>
                        <!-- Author -->

                    </div>
                    <!-- Post data -->

                </section>
                <!--Section: Intro-->

                <hr>

                <!-- Text -->
                <section class="text-justify">
                    <div class="col-12">
                        <p class="dark-grey-text article py-3">

                            راه های ارتباطی با ما
                        </p>


                        <br>
                        <ul>



                            <li class="pt-2">
                                ایمیل :
                                <span class=" text-muted">rppcshop1399@gmail.com</span>
                            </li>

                            <li class="pt-2">
                                توییتر آیدی :
                                <span class=" text-muted">rppcshop1399</span>
                            </li>

                            <li class="pt-2">
                                اینتاگرام آیدی :
                                <span class=" text-muted">rppcshop1399</span>
                            </li>

                        </ul>
                    </div>
                </section>
                <!-- Text -->


            </div>
            <!--Grid column-->


        </div>
        <!--Grid row-->

        <div class="row">
            <div class="col-12" style="height: 250px"></div>
        </div>

    </div>


@endsection

@section('script')

@endsection
