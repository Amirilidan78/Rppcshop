ALTER TABLE `products` ADD `english_name` VARCHAR(255) NULL AFTER `Name`;

ALTER TABLE `order_post` ADD `ostan` VARCHAR(25) NULL AFTER `order_id`, ADD `city` VARCHAR(255) NULL AFTER `ostan`;
