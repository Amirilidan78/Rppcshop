<?php

namespace App;

use App\Casts\PersianDate;
use Illuminate\Database\Eloquent\Model;

class PostComment extends Model
{
    protected $casts = [
        'Created_at' => PersianDate::class ,
    ];

    protected $table = 'post_comments' ;
    protected $guarded = [] ;
}
