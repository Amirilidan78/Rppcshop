<?php

namespace App\View\Components;

use Illuminate\View\Component;

class price extends Component
{
    public $price ;

    /**
     * Create a new component instance.
     *
     * @return void
     */

    public function __construct($price){

        $this->price = $price ;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.price');
    }
}
