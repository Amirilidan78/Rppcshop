<?php

namespace App\View\Components;

use Illuminate\View\Component;

class but extends Component
{
    public  $color ;
    public  $size ;
    public  $rounded ;
    public  $text ;
    public  $modalTarget ;
    public  $fadeIn ;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($color='info' ,$size=null ,$rounded=false ,$text='دکمه' ,$modalTarget=null ,$fadeIn=true){

        $this->color = $color ;
        $this->size = $size ;
        $this->rounded = $rounded ;
        $this->text = $text ;
        $this->modalTarget = $modalTarget ;
        $this->fadeIn = $fadeIn ;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.but');
    }
}
