<?php

namespace App\View\Components;

use Illuminate\View\Component;

class product extends Component
{

    public $id ;
    public $image ;
    public $available ;
    public $title ;
    public $price ;
    public $product ;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct(  $id ,$product ,$image ,$available ,$title ,$price ) {


//        ($product->pic1) ? asset("insert/products/{$product->id}/{$product->pic1}") : asset('images/placeHolder.jpg')
//        ($product->count>0) ? '1' : '0'
//        $product->Name
        $this->id = $id ;
        $this->product = $product ;
        $this->image = $image ;
        $this->available = $available ;
        $this->title = $title  ;
        $this->price = $price ;

    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.product');
    }
}
