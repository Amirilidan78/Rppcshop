<?php

namespace App\View\Components;

use Illuminate\View\Component;

class modalSpecial extends Component
{

    public  $form ;
    public  $formAction ;
    public  $formMethod ;
    public  $id ;
    public  $modalSize ;
    public  $modalColor ;
    public  $title ;
    public  $formSubmitText ;
    public  $footer ;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($form=false , $formAction=null ,$formMethod=null ,$id=null ,$modalSize='md' ,$modalColor='info' ,$title='title' ,$formSubmitText='ثبت' ,$footer=null ){

        $this->form = $form ;
        $this->formAction = $formAction ;
        $this->formMethod = $formMethod ;
        $this->id = $id ;
        $this->modalSize = $modalSize ;
        $this->modalColor = $modalColor ;
        $this->title = $title ;
        $this->formSubmitText = $formSubmitText ;
        $this->footer = $footer ;

    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.modals.special');
    }
}
