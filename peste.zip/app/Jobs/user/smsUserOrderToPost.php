<?php

namespace App\Jobs\user;


use App\functions\sms\Payamak;
use App\functions\session\smsControl;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class smsUserOrderToPost implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $phone ;
    private $text ;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($phone , $id ,$postId)
    {
        $this->phone = $phone ;
        $text = "سفارش ";
        $text .= " $id ";
        $text .= "تحویل پست داده شد شماره ره گیری : ";
        $text .= "$postId";
        $this->text = $text ;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Log::info($this->text);
        Payamak::sendSms($this->phone , $this->text);
    }
}
