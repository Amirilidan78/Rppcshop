<?php

namespace App\Jobs\admin;

use App\functions\sms\Payamak;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class smsAdminTransactionOfflinePayed implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $phone ;
    private $text ;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct( $id ){

        $this->phone = env('transaction_admin_phone_number') ;
        $text = "پرداخت آفلاین موفق برای سفارش ";
        $text .= "$id";
        $this->text = $text ;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Log::info($this->text);
        Payamak::sendSms($this->phone , $this->text);
    }
}
