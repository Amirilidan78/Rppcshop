<?php

namespace App\Jobs;

use App\functions\sms\Payamak;
use App\functions\session\smsControl;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class resetPassword implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $phone ;
    private $text ;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($phone , $password)
    {
        $this->phone = $phone ;
        $text = "{$password}";
        $this->text = $text ;

        smsControl::increaseSmsSession($this->phone);
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Payamak::sendSms($this->phone , $this->text);
    }
}
