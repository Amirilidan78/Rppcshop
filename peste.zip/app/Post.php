<?php

namespace App;

use App\Casts\PersianDate;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'posts' ;
    protected $guarded = [] ;

    protected $casts = [
        'Created_at' => PersianDate::class ,
    ];



    public function sames($count){
        return Post::where('id','<>',$this->id)->inRandomOrder()->take($count)->get();
    }

}
