<?php

namespace App;

use App\Casts\PersianDate;
use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{


    protected $guarded = [] ;
    protected $table = 'admins' ;
}
