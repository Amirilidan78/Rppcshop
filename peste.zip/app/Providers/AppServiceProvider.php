<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }


    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {


        //admin master
        view()->composer('admin.layout.master',function($view){
            $permissions = session('adminPermissions') ;

            $data = [
                'access_posts' => $permissions['posts'] ,
                'access_products' => $permissions['products'] ,
                'access_users' => $permissions['users'] ,
                'access_tags' => $permissions['tags'] ,
                'access_orders' => $permissions['orders'] ,

            ];
            $view->with($data);
        });
        //home master
        view()->composer('home.mater',function($view){


            $data = [

                'email_master' => env('email_master') ,
                'address_master' => env('address_master') ,
                'phone_master' => env('phone_master') ,
            ];
            $view->with($data);
        });
        //blog master
        view()->composer('blog.layout.mater',function($view){
            $data = [

                'email_master' => env('email_master') ,
                'address_master' => env('address_master') ,
                'phone_master' => env('phone_master') ,
            ];
            $view->with($data);
        });

    }
}
