<?php

namespace App\Providers;

use App\ProductGroup;
use App\View\Components\but;
use App\View\Components\dbTable;
use App\View\Components\modalDelete;
use App\View\Components\modalSpecial;
use App\View\Components\price;
use App\View\Components\product;
use App\View\Components\tag;
use Artesaos\SEOTools\Facades\JsonLd;
use Artesaos\SEOTools\Facades\OpenGraph;
use Artesaos\SEOTools\Facades\SEOMeta;
use Artesaos\SEOTools\Facades\SEOTools;
use Artesaos\SEOTools\Facades\TwitterCard;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class seoServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return array
     */
    public function gatherTags(){

        $tags = [
            'فروشگاه پسته رفسنجان' ,
            'خرید پسته ارزان' ,
            'فروشگاه شرکت تعاونی پسته رفسنجان' ,
            'خرید پسته' ,
        ];
        $groups = ProductGroup::all()->map(function ($group){
            return $group->name ;
        })->toArray();
        $products = \App\Product::all()->map(function ($product){
            return $product->Name ;
        })->toArray();

        foreach ($groups as $group)
            array_push($tags ,$group);

        foreach ($products as $product)
            array_push($tags ,$product);

        return $tags;

    }

    public function register()
    {

    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(){



        view()->composer('home.mater',function($view){

            $data = Cache::remember('site_config_data_base_sdfsf', 10 * 60, function () {
                $keywords = $this->gatherTags() ;

                $title = "خرید پسته رفسنجان | مرکز فروش پسته رفسنجان" ;
                $description = 'فروشگاه اینترنتی شرکت تعاونی پسته رفسنجان , با بهترین کیفیت و ارزان ترین قیمت در سراسر کشور از فروشگاه پسته ی رفسنجان با اطمینان خرید کنید' ;
                $imageUrl = asset('img/logo.PNG') ;
                $siteAddress = 'https://rppcshop.ir' ;
                $twitterAccount = '' ;

                $og = [
                    'site_name' => $title,
                    'locale' => 'fa_ir',
                    'url' => $siteAddress,
                    'type' => "website",
                    'description' => $description,
                    'image' => $imageUrl,
                ];
                $twitter = [
                    'card' => $title,
                    'title' => $title,
                    'description' => $description,
                    'url' => $siteAddress,
                    'image' => $imageUrl,
                    'creator' => $twitterAccount,
                ];
                $geo = [
                    'position' => "35.0; 35.0",
                    'placename' => "Iran ,Kerman ,Rafsanjan ",
                    'region' => "Iran",
                ];
                $canocical = $siteAddress ;
                $home = $siteAddress ;
                $text = "" ;
                foreach ($keywords as $key=>$keyword) {
                    if ($key == 0)
                        $text .= "$keyword " ;
                    else
                        $text .= ",$keyword" ;
                }

                $data = [
                    'title' =>  $title,
                    'description' =>  $description,
                    'keywords' =>  $text,
                    'geo' =>  $geo,
                    'twitter' =>  $twitter,
                    'canocical' =>  $canocical,
                    'home' =>  $home,
                    'og' =>  $og,
                ];
                return $data ;
            });

            $view->with($data);
        });


        view()->composer('blog.layout.mater',function($view){

            $data = Cache::remember('site_config_data_base_sdfsf', 10 * 60, function () {
                $keywords = $this->gatherTags() ;

                $title = 'فروشگاه شرکت تعوانی پسته رفسنجان' ;
                $description = 'خرید اینترنتی پسته خشک و خام و کارتنی و فله و بخ صورت جعبه ای و عمده  از فروشگاه اینترنتی شرکت تعاونی پسته رفسنجان واقع در استان کرمان شهر رفسنجان ارسال به سرارسر شهر های ایران' ;
                $imageUrl = asset('img/logo.PNG') ;
                $siteAddress = 'https://www.rppcshop.ir' ;
                $twitterAccount = '' ;

                $og = [
                    'site_name' => $title,
                    'locale' => 'fa_ir',
                    'url' => $siteAddress,
                    'type' => "website",
                    'description' => $description,
                    'image' => $imageUrl,
                ];
                $twitter = [
                    'card' => $title,
                    'title' => $title,
                    'description' => $description,
                    'url' => $siteAddress,
                    'image' => $imageUrl,
                    'creator' => $twitterAccount,
                ];
                $geo = [
                    'position' => "35.0; 35.0",
                    'placename' => "Iran ,Kerman ,Rafsanjan ",
                    'region' => "Iran",
                ];
                $canocical = $siteAddress ;
                $home = $siteAddress ;
                $text = "" ;
                foreach ($keywords as $key=>$keyword) {
                    if ($key == 0)
                        $text .= "$keyword " ;
                    else
                        $text .= ",$keyword" ;
                }

                $data = [
                    'title' =>  $title,
                    'keywords' =>  $text,
                    'geo' =>  $geo,
                    'twitter' =>  $twitter,
                    'canocical' =>  $canocical,
                    'home' =>  $home,
                    'og' =>  $og,
                ];
                return $data ;
            });

            $view->with($data);
        });


    }
}
