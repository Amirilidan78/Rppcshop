<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductGroupTag extends Model
{
    protected $table = 'product_group_tag' ;
    protected $guarded = [] ;
}
