<?php

namespace App\Observers;

use App\Order;
use Illuminate\Support\Facades\Mail;

class OrderObserver
{

    /**
     * Handle the order "created" event.
     *
     * @param  \App\Order  $order
     * @return void
     */
    public function created(Order $order)
    {
        Mail::to(env('support_admin_email'))->send(new \App\Mail\OrderCreated($order));

    }

    /**
     * Handle the order "updated" event.
     *
     * @param  \App\Order  $order
     * @return void
     */
    public function updated(Order $order)
    {
        Mail::to(env('support_admin_email'))->send(new \App\Mail\OrderUpdated($order));

    }

    /**
     * Handle the order "deleted" event.
     *
     * @param  \App\Order  $order
     * @return void
     */
    public function deleted(Order $order)
    {
        Mail::to(env('support_admin_email'))->send(new \App\Mail\OrderDeleted($order));

    }

    /**
     * Handle the order "restored" event.
     *
     * @param  \App\Order  $order
     * @return void
     */
    public function restored(Order $order)
    {
        //
    }

    /**
     * Handle the order "force deleted" event.
     *
     * @param  \App\Order  $order
     * @return void
     */
    public function forceDeleted(Order $order)
    {
        //
    }
}
