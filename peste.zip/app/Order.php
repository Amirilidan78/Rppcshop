<?php

namespace App;

use App\Casts\PersianDate;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $guarded = [] ;
    protected $table = 'orders' ;

    protected $casts = [
        'Created_at' => PersianDate::class ,
    ];

    public function getStep(){
        $step = $this->status ;

        switch ($step) {
            case 0:
                return 'منتظر پرداخت' ;
            break;
            case 1:
                return 'منتظر تایید سفارش';
            break;
            case 2:
                return 'در حال آماده سازی سفارش';
            break;
            case 3:
                return 'خروج از مرکز پردازش';
            break;
            case 4:
                return 'به پست تحویل داده شد';
            break;
            case 5:
                return 'به کاربر تحویل داده شد';
            break;
        }
    }

    public function getOrderId(){

        return 'Rppc'.explode('/',$this->Created_at)[1].$this->id ;
    }

    public function getSendType(){

        if ( $this->send_type == 1 )
            return 'پست' ;
        elseif( $this->send_type == 2 )
            return 'تیپاکس' ;
    }

    public function products(){

        return $this->hasMany('App\OrderProducts','order_id','id');
    }

    public function factor(){

        return $this->hasOne(OrderFactor::class,'order_id','id');
    }

    public function post(){

        return $this->hasOne(OrderPost::class,'order_id','id');
    }

    public function user(){

        return $this->hasOne(User::class,'phone','user_phone');
    }
}
