<?php

namespace App\functions\session ;
use App\UserPassword;
use  \Illuminate\Support\Facades\Log ;

class smsControl{

    public static function increaseSmsSession($phone){

        $user = UserPassword::where('phone',$phone)->first();

        if ($user){
            $user->update([
                'today_sms_counts' => $user->today_sms_counts + 1
            ]) ;
        }

    }

    public static function reachLimitSms($phone){

        $user = UserPassword::where('phone',$phone)->first();

        if ($user)
            if ($user->today_sms_counts > 5 )
                return true ;

        return false ;
    }
}


