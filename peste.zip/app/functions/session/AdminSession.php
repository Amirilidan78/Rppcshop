<?php

namespace App\functions\session ;
use App\User;

class AdminSession{

    public static $session_name = 'userName' ;

    public static function get(){

        return session(self::$session_name);
    }

    public static function set($obj){

        return session()->put( self::$session_name ,$obj);
    }



}


