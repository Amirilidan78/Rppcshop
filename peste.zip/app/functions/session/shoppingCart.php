<?php

namespace App\functions\session ;
use App\Product;
use Illuminate\Support\Arr;

class shoppingCart{

    public static $session_name = 'user_basket' ;

    public static function get(){

        return session(self::$session_name);
    }

    public static function set($obj){

        return session()->put( self::$session_name ,$obj);
    }

    public static function getProducts(){

        $products = [] ;

        foreach (session(self::$session_name) as $item){
            $product_id = $item['product_id'];
            $product = Product::findOrFail($product_id) ;
            array_push($products,$product);
        }

        return $products ;
    }

    public static function getSumPrices(){

        $sum = 0 ;
        if (session(self::$session_name)) {
            foreach (session(self::$session_name) as $item) {
                $product_id = $item['product_id'];
                $count = $item['count'];
                $product = Product::findOrFail($product_id);

                if ($product->price_off)
                    $sum += ($count * $product->price_off);
                else
                    $sum += ($count * $product->price);
            }
        }

        return $sum ;
    }

    public static function getShoppingCartList(){

        $cart = [] ;

        if (session(self::$session_name)){
            foreach (session(self::$session_name) as $item){
                $product = Product::findOrFail($item['product_id']);

                $array = [
                    $product->id ,
                    $product->Name ,
                    $product->price ,
                    $item['count'] ,
                ];

                array_push($cart , $array);
            }
        }

        return $cart ;
    }

    public static function clear(){

        if (session(self::$session_name))
            session()->pull(self::$session_name);

    }

}


