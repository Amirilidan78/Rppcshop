<?php

namespace App\functions\session ;
use App\Product;
use App\User;
use Illuminate\Support\Arr;

class UserSession{

    public static $session_name = 'user' ;

    public static function get(){

        return session(self::$session_name);
    }

    public static function set($obj){

        return session()->put( self::$session_name ,$obj);
    }

    public static function isLogin(){

        return (!empty(session(self::$session_name)));
    }

    public static function logout(){

        return (session()->pull(self::$session_name));
    }

    public static function getUser(){

        return User::where('phone',session(self::$session_name)['phone'])->first();
    }


}


