<?php

namespace App\functions\file ;

use Intervention\Image\Facades\Image;

class storePicture{

    private static function save($image , $destinationPath , $width  , $height){

        $input['imagename'] = time().'.'.$image->extension();

        $img = Image::make($image->path());

        $test = $img->resize($width, $height, function ($constraint) {

            $constraint->aspectRatio();

        });

        $test->save($destinationPath.'/'.$input['imagename']) ;

        return "{$input['imagename']}" ;
    }


    public static function post($file , $width = 750 , $height = 750){

        $destinationPath = base_path().env('post_upload_path') ;

        return "/storage/posts/".self::save($file , $destinationPath , $width , $height );
    }

    public static function products($file , $width = 850 , $height = 700){

        $destinationPath = base_path().env('product_upload_path') ;

        return "/storage/products/".self::save($file , $destinationPath , $width , $height );
    }

}


