<?php

namespace App\functions\view;

class validate{

    public static function guest($parameters , $error = 'لطفا همه ی فیلد ها را کامل کنید'){
        foreach ($parameters as $parameter) {
            if (is_null($parameter)){
                session()->flash('guestAlert',[ 0 => false , 1 => $error ]);
                return true;
            }
        }
        return false;
    }

    public static function admin($parameters , $error = 'لطفا همه ی فیلد ها را کامل کنید'){
        foreach ($parameters as $parameter) {
            if (is_null($parameter)){
                session()->flash('adminAlert',[ 0 => false , 1 => $error ]);
                return true;
            }
        }
        return false;
    }

}



