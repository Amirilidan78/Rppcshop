<?php

namespace App\functions\view;

class alert{

    public static function guest($type , $error = 'لطفا همه ی فیلد ها را کامل کنید'){
        session()->flash('guestAlert',[ 0 => $type , 1 => $error ]);
    }

    public static function admin($type , $error = 'لطفا همه ی فیلد ها را کامل کنید'){
        session()->flash('adminAlert',[ 0 => $type , 1 => $error ]);
    }

    public static function blog($type , $error = 'لطفا همه ی فیلد ها را کامل کنید'){
        session()->flash('blogAlert',[ 0 => $type , 1 => $error ]);
    }

}



