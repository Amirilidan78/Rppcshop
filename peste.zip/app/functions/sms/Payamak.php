<?php

namespace App\functions\sms ;
use  \Illuminate\Support\Facades\Log ;

class Payamak{

    public static function sendSms($phone,$text){
        ini_set("soap.wsdl_cache_enabled", "0");
        $sms_client = new \SoapClient('http://payamak-service.ir/SendService.svc?wsdl', array('encoding' => 'UTF-8'));

        try {
            $parameters['userName'] = "mc.09370843199";
            $parameters['password'] = "99659";
            $parameters['fromNumber'] = "500019746158916";
            $parameters['toNumbers'] = array("{$phone}");
            $parameters['messageContent'] = "{$text}";
            $parameters['isFlash'] = false;
            $recId = array(0);
            $status = 0x0;
            $parameters['recId'] = &$recId;
            $parameters['status'] = &$status;
            $status = $sms_client->SendSMS($parameters)->SendSMSResult;
            if ($status == 0)
                Log::info("sendMessage : phone({$phone}) , message:<{$text}>");
            else
                Log::alert("sendMessage : statusCode : <$status>");
            return $status ;

        } catch (Exception $e) {
            Log::critical('sendMessage : Caught exception: '. $e->getMessage(), "\n");
        }
    }

}


