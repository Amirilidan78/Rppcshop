<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductGroup extends Model
{
    protected $table = 'products_groups' ;
    protected $guarded = [] ;

    public function products(){

        return $this->hasMany(Product::class,'group_id','id');
    }

    public function tags(){
        return $this->belongsToMany(Tag::class);
    }

}
