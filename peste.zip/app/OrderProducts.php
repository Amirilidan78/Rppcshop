<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderProducts extends Model
{
    protected $guarded = [] ;
    protected $table = 'order_products' ;

    public function product(){

        return $this->hasOne(Product::class,'id','product_id');
    }
}
