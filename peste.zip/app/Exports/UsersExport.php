<?php

namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromCollection;

class UsersExport implements FromCollection
{

    public function collection()
    {

            $original = new \Illuminate\Support\Collection([
                [
                    'شماره همراه' ,
                    'نام' ,
                    'نام خانوادگی' ,
                    'ایمیل' ,
                    'آدرس' ,
                    'کد پستی' ,
                    'شماره ثابت' ,
                ]
            ]);

        $merged = $original->merge(
            User::all()->map(function ($user){

                $totalPriceOrders = 0 ;
                $address = null ;
                $postCode = null ;
                $homeNumber = null ;

                foreach ($user->orders as $order){

                    $totalPriceOrders += $order->total_price ;

                    if ($order->post){
                        $address = $order->post->address ;
                        $postCode = $order->post->post_code ;
                        $homeNumber = $order->post->number ;
                    }
                }

                return [
                    $user->phone ,
                    $user->name ,
                    $user->last_name  ,
                    $user->email ,
                    $address ,
                    $postCode ,
                    $homeNumber ,
                ] ;


            })
        );


        return  $merged ;
    }
}
