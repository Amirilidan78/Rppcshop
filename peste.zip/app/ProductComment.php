<?php

namespace App;

use App\Casts\PersianDate;
use Illuminate\Database\Eloquent\Model;

class ProductComment extends Model
{
    protected $casts = [
        'Created_at' => PersianDate::class ,
    ];

    protected $table = 'products_comments' ;
    protected $guarded = [] ;

    public function user(){

        return $this->hasOne(User::class,'phone','user_phone');
    }
}
