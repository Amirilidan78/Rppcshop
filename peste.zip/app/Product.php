<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $guarded = [] ;
    protected $table = 'products' ;

    public function attribs(){

        return $this->hasMany(ProductAttrib::class,'product_id','id');
    }

    public function comments(){

        return $this->hasMany(ProductComment::class,'product_id','id');
    }

    public function group(){
        return $this->hasOne(ProductGroup::class , 'id' , 'group_id'  );
    }

    public function sames($count){
        return Product::where('id','<>',$this->id)->inRandomOrder()->take($count)->get();
    }

    public function tags(){
        return $this->belongsToMany(Tag::class);
    }

    public function getPersianSalty(){

        if ($this->is_salty == 1)
            return "شور" ;
        else
            return "خام" ;

    }
    public function getPersianPacking(){

        if ($this->type_packing == 1)
            return "سلوفن" ;
        elseif ($this->type_packing == 2)
            return "قوطی" ;
        elseif ($this->type_packing == 3)
            return "جعبه" ;
        elseif ($this->type_packing == 4)
            return "کارتن" ;
        else
            return 'نا مشخص' ;
    }
}
