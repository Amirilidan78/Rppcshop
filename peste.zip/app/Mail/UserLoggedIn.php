<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Morilog\Jalali\Jalalian;

class UserLoggedIn extends Mailable
{
    use Queueable, SerializesModels;

    public $name ;
    public $ip ;
    public $date ;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($name ,$ip)
    {
        $this->name = $name ;
        $this->ip = $ip ;
        $this->date = Jalalian::now()->toString();

    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('emails.user-loggedin',[
            'name' => $this->name ,
            'date' => $this->date ,
            'ip' => $this->ip ,
        ]);
    }
}
