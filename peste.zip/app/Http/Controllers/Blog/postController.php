<?php

namespace App\Http\Controllers\Blog;

use App\functions\view\alert;
use App\Http\Controllers\Controller;
use App\Post;

class postController extends Controller
{

    public function index(){

        return view('blog.index' , [
            'posts' => Post::orderBy('id','desc')->paginate(6)
        ]);
    }

    public function show(Post $post){

        $article = [
            'tag' => $post->title,
            'section' => $post->text,
            'published_time' => $post->Created_at,
            'modified_time' => $post->Updated_at,
        ] ;

        $twitterSpecial = [
            'card' => $post->title,
            'title' => $post->title,
            'description' => $post->text,
            'url' => "http://rppcshop.ir",
            'image' => asset($post->pic),
            'creator' => env('twitter_account',null),
        ];


        return view('blog.post' , [
            'post' => $post ,
            'related' => $post->sames(3) ,
            'article' => $article,
            'twitterSpecial' => $twitterSpecial ,
        ]);
    }

}
