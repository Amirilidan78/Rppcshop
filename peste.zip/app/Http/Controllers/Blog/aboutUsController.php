<?php

namespace App\Http\Controllers\Blog;

use App\Http\Controllers\Controller;

class aboutUsController extends Controller
{

    public function index(){

        return view('blog.aboutUs') ;
    }

}
