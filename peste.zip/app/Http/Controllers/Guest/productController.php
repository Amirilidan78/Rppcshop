<?php

namespace App\Http\Controllers\Guest;

use App\Product;
use App\ProductGroup;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class productController extends Controller
{

    public function index(Request $r){

        $is_salty = ( $r->salty == null  ) ? null : explode(',',$r->salty) ;
        $groups =  ( $r->groups == null  ) ? null : explode(',',$r->groups) ;
        $packing = ( $r->packing == null  ) ? null : explode(',',$r->packing) ;
        $groupsName = [] ;

        if ($groups)
            $groupsName = ProductGroup::whereIn('id',$groups)->get()->toArray();

        if($is_salty && $groups && $packing)
            $products = Product::whereIn('is_salty',$is_salty)->whereIn('group_id',$groups)->whereIn('type_packing',$packing)->paginate(9) ;

        elseif($is_salty && $groups)
            $products = Product::whereIn('is_salty',$is_salty)->whereIn('group_id',$groups)->paginate(9) ;

        elseif($groups && $packing)
            $products = Product::whereIn('group_id',$groups)->whereIn('type_packing',$packing)->paginate(9) ;

        elseif($is_salty && $packing)
            $products = Product::whereIn('is_salty',$is_salty)->whereIn('type_packing',$packing)->paginate(9) ;

        elseif($is_salty)
            $products = Product::whereIn('is_salty',$is_salty)->paginate(9) ;

        elseif($packing)
            $products = Product::whereIn('type_packing',$packing)->paginate(9) ;

        elseif($groups)
            $products = Product::whereIn('group_id',$groups)->paginate(9) ;

        else
            $products = Product::paginate(9) ;

        $tags = [];
        foreach ($products as $product){
            foreach ($product->tags as $tag){
                array_push($tags,$tag);
            }
        }

        return view('home.products.index',[

            'pageDescription' => "صفحه محصولات پسته فروشگاه" ,
            "pageTitle" => "محصولات" ,
            'is_salty' => ($is_salty) ? $is_salty : [] ,
            'filterGroups' => ($groups) ? $groups : [] ,
            'packing' => ($packing) ? $packing : [] ,
            'products' => $products ,
            'tags' => $tags ,
            'groups' => ProductGroup::all() ,
            'groupsName' => $groupsName ,
        ]);
    }

    public function show(Product  $product){

        $twitterSpecial = [
            'card' => $product->Name,
            'title' => $product->Name,
            'description' => $product->description,
            'url' => "https://rppcshop.ir",
            'image' => asset($product->pic1),
            'creator' => env('twitter_account',null),
        ];

        return view('home.products.show' ,[
            'pageDescription' => $product->description ,
            "pageTitle" => $product->english_name ,
            'product' =>  $product,
            'tags' =>  $product->tags,
            'attribs' => $product->attribs ,
            'comments' => $product->comments ,
            'sames' => $product->sames(3) ,
            'twitterSpecial' => $twitterSpecial ,
        ]);
    }


}
