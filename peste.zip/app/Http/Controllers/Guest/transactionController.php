<?php

namespace App\Http\Controllers\Guest;

use App\functions\view\alert;
use App\Http\Controllers\Controller;
use App\Jobs\admin\smsAdminTransactionPayed;
use App\Jobs\user\smsUserOrderInserted;
use App\Jobs\user\smsUserTransactionPayed;
use App\Order;
use App\OrderFactor;
use Illuminate\Http\Request;
use SoapClient;

class transactionController extends Controller
{
    public function index(Order $order){

        $MerchantID = env('merchant_id'); //Required
        $Amount = $order->total_price; //Amount will be based on Toman - Required
        $Description = 'خرید پسته از Rppc.ir'; // Required
        $Email = null; // Optional
        $Mobile = $order->user_phone; // Optional
        $CallbackURL = "https://www.rppcshop.ir/transaction/{$order->id}/verify"; // Required
        $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

        $result = $client->PaymentRequest(
            [
                'MerchantID' => $MerchantID,
                'Amount' => $Amount,
                'Description' => $Description,
                'Email' => $Email,
                'Mobile' => $Mobile,
                'CallbackURL' => $CallbackURL,
            ]
        );

        OrderFactor::updateOrCreate([
            'order_id' => $order->id,
            'Authority' => $result->Authority ,
            'Amount' => $order->total_price ,
            'ref_id' => null ,
        ]);

//Redirect to URL You can do it also by creating a form
        if ($result->Status == 100) {
            Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority);
//برای استفاده از زرین گیت باید ادرس به صورت زیر تغییر کند:
//Header('Location: https://www.zarinpal.com/pg/StartPay/'.$result->Authority.'/ZarinGate');
        } else {
            echo'ERR: '.$result->Status;
        }

        dd(1);
    }

    public function verify( Order $order , Request $request ){

        $MerchantID = env('merchant_id');
        $Amount = $order->total_price; //Amount will be based on Toman
        $Authority = $_GET['Authority'];

        if ($_GET['Status'] == 'OK') {

            $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

            $result = $client->PaymentVerification(
                [
                    'MerchantID' => $MerchantID,
                    'Authority' => $Authority,
                    'Amount' => $Amount,
                ]
            );

            if ($result->Status == 100) {

                $order->update([
                    'status' => 1
                ]);

                $factor = $order->factor ;
                $factor->update([
                    'ref_id' => $result->RefID
                ]) ;


                session()->put('order_transaction_id',$order->id);

                return redirect("/successTransaction");
            } else {


                return redirect("/failTransaction");
            }
        } else {

            return redirect("/failTransaction");
        }

    }

    public function successTransaction() {
        alert::guest(true,'تراکنش موفق');
        $id = session('order_transaction_id') ;
        return redirect("");
    }

    public function failTransaction() {
        alert::guest(false,'تراکنش ناموفق');
        $id = session('order_transaction_id') ;
        return redirect("");
    }


}
