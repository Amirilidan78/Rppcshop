<?php

namespace App\Http\Controllers\Guest;

use App\functions\session\UserSession;
use App\functions\sms\Payamak;
use App\functions\session\smsControl;
use App\functions\view\alert;
use App\functions\view\validate;
use App\Jobs\registerUser;
use App\Jobs\resetPassword;
use App\Order;
use App\PostComment;
use App\ProductComment;
use App\User;
use App\UserPassword;
use App\UserPersonal;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class userController extends Controller
{

    public function postLogin(Request $r){

        $phone = $r->phone ;
        $password = $r->password ;

        if ( !$phone || !$password ){
            session()->flash('guestAlert',[ 0 => false , 1 => 'شماره همراه یا رمز عبور نمیتواند خالی باشد' ]);
            return redirect()->back();
        }

        $user = User::where('phone',$phone)->first() ;
        $userPassword = UserPassword::where('phone',$phone)->first() ;

        if ($user && $userPassword){
            if ( $userPassword->password == md5($password) ){

                session()->put('user' , [
                    'name' => $user->name ,
                    'last_name' => $user->last_name ,
                    'phone' => $user->phone ,
                    'code_melli' => $user->code_melli ,
                ]);

                session()->flash('guestAlert',[ 0 => true , 1 => 'وارد حساب کاربری خود شدید' ]);
                return redirect()->back();
            }
        }

        session()->flash('guestAlert',[ 0 => false , 1 => 'اطلاعات وارد شده اشتباه است' ]);
        return redirect()->back();
    }

    public function showRegister(){

        if (session('user')) //if is login
            return redirect('');

        return view('home.auth.register');
    }

    public function showForgotPassword(){

        if (session('user')) //if is login
            return redirect('');

        return view('home.auth.forgotPassword');
    }

    public function postForgotPassword(Request $r){

        $phone = $r->phone ;

        if (!$phone) return -1 ; // شماره همراه نمیتواند خالی باشد

        $user = User::where('phone',$phone)->count();

        if ( smsControl::reachLimitSms($phone) )
            return -4 ; //had mojaz emrooz sms

        if ($user == 0) return -2 ; // با این شماره کاربری ثبت نشده است

        $resetPassword = rand(1000,9999) ;

        UserPassword::where('phone',$phone)->update([
            'reset_password' =>$resetPassword
        ]);

        resetPassword::dispatch($phone , $resetPassword) ;

        return 1 ;
    }

    public function postCheckCode(Request $r){

        $code = $r->code ;
        $phone = $r->phone ;

        if (!$phone || !$code) return -1 ; // شماره همراه نمیتواند خالی باشد

        $user = User::where('phone',$phone)->count();

        if ($user == 0) return -2 ; // با این شماره کاربری ثبت نشده است

        $resetPassword = UserPassword::where('phone',$phone)->first()->reset_password ;

        if ($resetPassword != $code) return -3 ; // کد اشتباه


        return 1 ; //ok

    }

    public function postChangePassword(Request $r){

        $phone = $r->phone ;
        $password = $r->password ;

        if (!$password || !$phone) return -1 ; // رمز عبور نمیتواند خالی باشد

        $user = User::where('phone',$phone)->count();

        if ($user == 0) return -2 ; // با این شماره کاربری ثبت نشده است

        if (strlen($password) < 8) return -3 ; // رمز عبور باید بیشتر از 8 حرف باشد


        UserPassword::where('phone',$phone)->first()->update([
            'password' => md5($password)
        ]) ;


        return 1 ; //ok

    }

    public function postRegister(Request $r){

        $name = $r->name ;
        $last_name = $r->last_name ;
        $phone = $r->phone ;

        if ( !$name || !$last_name || !$phone ){
            session()->flash('guestAlert',[0 => false , 1 => 'لطفا فیلد ها را کامل کنید']);
            return redirect()->back();
        }

        ///todo: phone check

        if (User::where('phone',$phone)->count() > 0){
            session()->flash('guestAlert',[0 => false , 1 => 'کاربر با این شماره همراه ثبت شده است']);
            return redirect()->back();
        }

        User::create([
            'name' => $name ,
            'last_name' => $last_name ,
            'phone' => $phone ,
        ]);

        $password = rand(10000000 , 99999999) ;

        UserPassword::create([
            'phone' => $phone ,
            'password' => md5($password) ,
        ]);


        if ( smsControl::reachLimitSms($phone) ){
            session()->flash('guestAlert',[0 => false , 1 => " بیشتر از 5 بار  "]);
            return redirect()->back();
        }

        registerUser::dispatch($phone,$password);

        session()->flash('guestAlert',[ 0 => true , 1 => 'ثبت نام تکمیل شد و رمز عبور به شماره همراه شما ارسال شد' ]);
        return redirect()->back();
    }

    public function showDashboard(){

        return view('home.user.index',[
            'user' => User::findWithPhone(session('user')['phone']) ,
        ]);
    }

    public function showAddress(){

        return view('home.user.address',[
            'addresses' => UserPersonal::where('phone',session('user')['phone'])->get()
        ]);
    }

    public function deleteAddress($id){

        $address = UserPersonal::find($id) ;

        if ($address)
            $address->delete() ;
        else{
            alert::guest(false , 'یافت نشد'); ;
            return redirect()->back();
        }

        alert::guest(true , 'حذف شد'); ;
        return redirect()->back();
    }

    public function createAddress(Request $r){

        if ( validate::guest([ $r->city ,$r->town ,$r->address ,$r->post_code ]) )
            return redirect()->back();

         UserPersonal::create([
             'phone' => session('user')['phone'] ,
             'city' => $r->city ,
             'town' => $r->town ,
             'address' => $r->address ,
             'post_code' => $r->post_code ,
         ]);

         alert::guest(true,' ثبت شد ');
         return redirect()->back();

    }

    public function modifyUser(Request $r){

        if ( validate::guest([ $r->name ,$r->last_name ]) )
            return redirect()->back();

        User::findWithPhone( session('user')['phone'] )->update([
            'name' => $r->name ,
            'last_name' => $r->last_name ,
        ]) ;

        alert::guest(true,' ویرایش شد ');
        return redirect()->back();
    }

    public function modifyUserPassword(Request $r){

        if ( validate::guest([ $r->password ,$r->rePassword ]) )
            return redirect()->back();

        if ($r->password != $r->rePassword  ){
            alert::guest(false , 'رمز های عبور یکی نیستند');
            return redirect()->back();
        }

        if (strlen($r->password) < 8){
            alert::guest(false , 'رمز عبور نمیتواند کمتر از 8 حرف باشد');
            return redirect()->back();
        }

        User::findWithPhone( session('user')['phone'] )->password()->update([
            'password' => md5($r->password)
        ]);

        alert::guest(true,' ویرایش شد ');
        return redirect()->back();
    }

    public function showComments(){

        return view('home.user.comments' ,[
            'comments' => ProductComment::where('user_phone',session('user')['phone'])->paginate(8) ,
        ]);
    }

    public function showOrders(){

        return view('home.user.orders' ,[
            'orders' => Order::where('user_phone',UserSession::get()['phone'])->orderBy('Created_at','desc')->paginate(10) ,
        ]);
    }

    public function showOrder(Order $order){

        return view('home.user.order' ,[
            'order' => $order ,
            'products' => $order->products ,
            'factor' => $order->factor ,
        ]);
    }

    public function logout(){
        session()->pull('user');
        alert::guest(true,'از حساب کاربری خود خارج شدید');
        return redirect('');
    }

}
