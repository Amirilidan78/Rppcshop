<?php

namespace App\Http\Controllers\Guest;

use App\Order;
use App\Product;
use App\ProductGroup;
use App\User;
use App\Http\Controllers\Controller;

class homeController extends Controller
{
    public function index(){

        $productsSalty = Product::where('is_salty' , 1)->take(4)->get();
        $productsNotSalty = Product::where('is_salty' , 0)->take(4)->get();

        return view('home.index',[
            'productsSalty' => $productsSalty ,
            'productsNotSalty' => $productsNotSalty ,
            'productsGroups' => ProductGroup::all()->map(function ($obj){ return  Product::where('group_id',$obj->id)->inRandomOrder()->take(4)->get() ; })->filter(function ($obj){ if ($obj) return $obj ;}) ,
            'productsCount' => Product::all()->count() ,
            'orders' => Order::all() ,
            'users' => User::all() ,
        ]);
    }
    public function aboutUs(){

        return view('blog.aboutUs',[
            'pageDescription' => "درباره ی شرکت تعاونی پسته رفسنجان" ,
            "pageTitle" => "درباره ی شرکت تعاونی پسته رفسنجان"
        ]) ;
    }

    public function contact(){

        return view('blog.contact',[
            'pageDescription' => "ارتباط با پشتیبانی فروشگاه" ,
            "pageTitle" => "ارتباط با ما"
        ]) ;
    }


    public function help(){

        return view('blog.help',[
            'pageDescription' => "صفحه راهنما " ,
            "pageTitle" => "راهنما"
        ]) ;
    }


}
