<?php

namespace App\Http\Controllers\Guest;

use App\functions\session\shoppingCart;
use App\functions\session\UserSession;
use App\functions\view\alert;
use App\functions\view\validate;
use App\Jobs\user\smsUserOrderInserted;
use App\Order;
use App\OrderFactor;
use App\OrderPost;
use App\OrderProducts;
use App\Product;
use App\UserPersonal;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Http;

class cartController extends Controller
{
    public function index(){

        return view('home.cart.index',[

            'cartDetail' => shoppingCart::getShoppingCartList() ,
            'priceTotal' => shoppingCart::getSumPrices() ,
        ]);
    }

    public function index2(){

        if (shoppingCart::getShoppingCartList() == []){
            alert::guest(false , 'سبد خرید شما خالی است');
            return redirect()->back();
        }

        return view('home.cart.index2',[

            'user' => $user = UserSession::getUser(),
            'is_login' => UserSession::isLogin(),
            'cartDetail' => shoppingCart::getShoppingCartList() ,
            'priceTotal' => shoppingCart::getSumPrices() ,
            'offline_phone_number' => env('offline_phone_number') ,
        ]);
    }

    public function postAddProductTOShoppingCart(Request $r){

        $oldBasket = session("user_basket") ;

        $count = $r->count ;
        $product_id = $r->product_id ;

        $newBasket = [
            ['count'=>$count ,'product_id'=> $product_id]
        ];

        if ($oldBasket){ //basket is not empty
            foreach ($oldBasket as $key =>$item){
                if ($product_id == $item['product_id']){
                    $Product = Product::find($product_id);
                    if (!$Product){
                        session()->put('user_basket', $oldBasket);
                        return ['response' => -1] ;
                    }

                    $productCount = $Product->count;
//                    $newCount = $oldBasket[$key]['count'] + $count;
                    if ($productCount < $count){
                        session()->put('user_basket', $oldBasket);
                        return ['response' => 0] ;

                    }
                    Arr::pull($newBasket,0);
                    if ($count != 0){
                        array_push($newBasket,['count'=>$count ,'product_id'=>$item['product_id']]);
                    }

                }else{
                    array_push($newBasket,['count'=>$item['count'] ,'product_id'=>$item['product_id']]);
                }
            }
        }else{//basket is empty
            $newBasket = [
                ['count'=>$count ,'product_id'=>$product_id]
            ];
        }

        $lastCount = 0 ;
        foreach ($newBasket as $product){
            $lastCount = $lastCount  + $product['count'] ;
        }

        session()->put('user_basket', $newBasket);
        return ['response' => 1 , 'count' => $lastCount] ;

    }

    public function deleteProductFromShoppingCart(Product $product){

        $id = $product->id ;

        $oldBasket = session("user_basket") ;

        $product_id = $id ;
        $myKey = null ;

        if ($oldBasket){ //basket is not empty
            foreach ($oldBasket as $key =>$item){
                if ($product_id == $item['product_id']){
                    Arr::pull($oldBasket,$key);
                }
            }
        }

        session()->put("user_basket",$oldBasket);

        alert::guest(true , 'محصول از سبد خرید حذف شد');
        return redirect()->back();
    }

    public function deleteShoppingCart(Request $r){
        session()->pull("user_basket") ;
        alert::guest(true,"سبد خرید خالی شد");
        return redirect()->back();
    }

    public function insertOrderAndOrderPost(Request $r){

        $phone = UserSession::get()['phone'];
        $products = shoppingCart::getShoppingCartList() ;
        $oldOrder = Order::where('user_phone',$phone)->where('status',0)->count();

        if ( $oldOrder > 0 )
            return  ['response'=>2] ; //لطفا سفارش قبلی خود را پرداخت کنید


        foreach ($products as $product){

            $p= Product::find($product[0]) ;

            if ( intval($p->count) < intval($product[3]) )
                return ['response'=>3] ;
        }

        $order = Order::create([
            'user_phone' => $phone ,
            'status' => 0 ,
            'total_price' => shoppingCart::getSumPrices() ,
            'post_rahgiri' => null ,
            'send_type' => $r->send_type ,
            'date' => now()->toDateString() ,
        ]);

        OrderPost::create([
            'order_id' => $order->id ,
            'ostan' => $r->ostan ,
            'city' => $r->city ,
            'post_code' => $r->code_post ,
            'number' => $r->number ,
            'address' => $r->address ,
        ]) ;

        foreach ($products as $product){

            OrderProducts::create([
                'order_id' => $order->id ,
                'product_id' => $product[0] ,
                'count' => $product[3] ,
                'price' => $product[2] ,
                'total_price' => $product[2]*$product[3] ,
            ]);

            $p = Product::find($product[0]) ;
            $p->update([
                'count' => intval($p->count) - intval($product[3])
            ]);
        }

        if ($order->user_phone == 'enamad')
            smsUserOrderInserted::dispatch($r->number ,$order->getOrderId());

        shoppingCart::clear() ;

        return ['response' => 1 , 'id' =>$order->id ] ;
    }

}
