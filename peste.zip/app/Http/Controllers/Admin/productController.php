<?php

namespace App\Http\Controllers\Admin;

use App\functions\file\storePicture;
use App\functions\view\alert;
use App\functions\view\validate;
use App\Product;
use App\ProductGroup;
use App\Tag;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class productController extends Controller
{
    public function __construct (){
        $this->middleware('adminPermissionProducts');
    }

    public function index()
    {
        return view('admin.products.index' ,[

            'all' => Product::all(),
            'groups' => ProductGroup::all(),
            'tags' => Tag::all(),
        ]) ;
    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {

        if (
            validate::admin([
                $request->Name ,
                $request->url ,
                $request->group_id ,
                $request->description ,
                $request->price ,
                $request->weight ,
                $request->is_salty ,
                $request->type_packing ,
                $request->count ,
            ])
        )
            return redirect()->back() ;

        if (Product::where('english_name',$request->url)->count() > 0){
            alert::admin(false,'محصول با این آدرس ثبت شده است');
            return redirect()->back() ;
        }

        $product = Product::create([
            "Name"=> $request->Name
            ,"english_name"=> $request->url
            ,"group_id"=> $request->group_id
            ,"description"=> $request->description
            ,"price"=> $request->price
            ,"price_off"=> $request->price_off
            ,"weight"=> $request->weight
            ,"is_salty"=> $request->is_salty
            ,"type_packing"=> $request->type_packing
            ,"count"=> $request->count
        ]);

        if (!empty($request->pic1)){
            $src = storePicture::products( $request->file('pic1') );
            $product->update([
                'pic1' =>   $src
            ]);
        }

        if (!empty($request->pic2)){
            $src = storePicture::products( $request->file('pic2') );
            $product->update([
                'pic2' =>   $src
            ]);
        }

        if (!empty($request->pic3)){
            $src = storePicture::products( $request->file('pic3') );
            $product->update([
                'pic3' =>   $src
            ]);
        }

        alert::admin(true,'ثبت شد');
        return redirect()->back() ;

    }


    public function show($id)
    {
        //
    }


    public function edit(Product $product)
    {
        return view('admin.products.edit' , [

            'groups' => ProductGroup::all(),
            'product' => $product ,
        ]);
    }


    public function update(Product $product , Request $request )
    {
        if (
            validate::admin([
                $request->Name ,
                $request->url ,
                $request->group_id ,
                $request->description ,
                $request->price ,
                $request->weight ,
                $request->is_salty ,
                $request->type_packing ,
                $request->count ,
            ])
        )
            return redirect()->back() ;


        $product->update([
            "Name"=> $request->Name
            ,"english_name"=> $request->url
            ,"group_id"=> $request->group_id
            ,"description"=> $request->description
            ,"price"=> $request->price
            ,"price_off"=> $request->price_off
            ,"weight"=> $request->weight
            ,"is_salty"=> $request->is_salty
            ,"type_packing"=> $request->type_packing
            ,"count"=> $request->count
        ]);

        if ( !empty($request->pic1) ){
            $src = storePicture::products( $request->file('pic1') );
            $product->update([
                'pic1' =>   $src
            ]);
        }

        if ( !empty($request->pic2) ){
            $src = storePicture::products( $request->file('pic2') );
            $product->update([
                'pic2' =>   $src
            ]);
        }

        if ( !empty($request->pic3) ){
            $src = storePicture::products( $request->file('pic3') );
            $product->update([
                'pic3' =>   $src
            ]);
        }

        alert::admin(true,'ویرایش شد');
        return redirect()->back() ;
    }


    public function destroy(Product $product)
    {
        $product->delete();
        alert::admin(true,'حذف شد');
        return redirect()->back();
    }
}
