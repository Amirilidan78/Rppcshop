<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\AdminPassword;
use App\Jobs\adminLogin;
use App\Mail\UserLoggedIn;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class loginController extends Controller
{


    public function index(){

        if (session('adminIsLogin') == true)
            return redirect('/admin');
        else
            return view('admin.auth.index');
    }

    public function checkIsAdmin(Request $r){

        $r->validate([
            'userName' => 'required',
            'password' => 'required',
        ]);

        if (Admin::where('user_name',$r->userName)->count() == 0){

            session()->flash("alert",['1'=>"success-color",'2'=>"هیچ ادمینی با این مشخصات ثبت نشده"]);
            return redirect()->back(); //no admin found
        }

        $admin = Admin::where('user_name',$r->userName)->first();

        if (AdminPassword::where('user_name',$r->userName)->where('password',md5($r->password))->count() == 0){

            session()->flash("alert",['1'=>"success-color",'2'=>"رمز اشتباه"]);
            return redirect()->back(); //wrong password
        }

        session()->put('userName',$admin->user_name);
        session()->put('adminIsLogin',true);

        session()->put('adminPermissions',[
            'posts' => $admin->access_posts ,
            'products' => $admin->access_products ,
            'users' => $admin->access_users ,
            'tags' => $admin->access_tags ,
            'orders' => $admin->access_orders,
        ]);

        $ip = \Illuminate\Support\Facades\Request::ip();

        $supportEmail = env('support_admin_email') ;
        Mail::to($supportEmail)->send(new \App\Mail\UserLoggedIn($admin->user_name ,$ip));

        return redirect('/admin');
    }



}
