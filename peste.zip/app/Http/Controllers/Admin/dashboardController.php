<?php

namespace App\Http\Controllers\Admin;

use App\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class dashboardController extends Controller
{
    public function index(){

        return view('admin.dashboard.index' , [
            'orders' => DB::table('orders')->select('date', DB::raw('count(*) as total'))->orderBy('date','desc')->groupBy('date')->take(7)->get()
        ]) ;
    }
}
