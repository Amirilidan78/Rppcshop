<?php

namespace App\Http\Controllers\Admin;

use App\functions\file\storePicture;
use App\functions\view\alert;
use App\functions\view\validate;
use App\Post;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BlogController extends Controller
{
    public function __construct (){
        $this->middleware('adminPermissionPosts');
    }

    public function index(){

        return view('admin.blog.index' ,[
            'posts' => Post::orderBy('id','desc')->paginate(10) ,
        ]);
    }

    public function add(Request $r){

        if (validate::admin([$r->text , $r->title]))
            return redirect()->back();

        $post = Post::create([
            'title' => $r->title ,
            'text' => $r->text ,
        ]);

        if (!empty($r->file)){
            $src = storePicture::post( $r->file('file') );
            $post->update([
               'image' =>   $src
            ]);
        }

        alert::admin(true , 'پست ثبت شد');
        return redirect()->back();
    }

    public function delete($id){

        if (validate::admin([$id]))
            return redirect()->back();

        $post = Post::find($id);

        if ($post)
            $post->delete();
        else
            alert::admin(false , 'پست یافت نشد');
        alert::admin(true , 'پست حذف شد');

        return redirect()->back();
    }

    public function edit(Post $post){

        return view('admin.blog.edit' , [
            'post' => $post
        ]);
    }

    public function update(Post $post , Request $r){

        if ( validate::admin([$r->text , $r->title]) ) return redirect()->back();

        $id = $post->id;

        $post->update([
            'title' => $r->title ,
            'text' => $r->text ,
        ]);

        if (!empty($r->file)){

            $src = storePicture::post( $r->file('file') );
            $post->update([
                'image' =>   $src
            ]);
        }

        alert::admin(true , 'پست ویرایش شد');
        return redirect()->back();
    }

}
