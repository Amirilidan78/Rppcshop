<?php

namespace App\Http\Controllers\Admin;

use App\functions\view\alert;
use App\functions\view\validate;
use App\Product;
use App\ProductTag;
use App\Tag;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class tagController extends Controller
{
    public function __construct (){
        $this->middleware('adminPermissionTags');
    }

    public function index(){

        return view('admin.tags.index' ,[
            'all' => Tag::all() ,
            'products' => Product::all() ,
        ]) ;
    }

    public function store(Request $r){

        if (validate::admin([$r->name]))
            return redirect()->back();

        Tag::create([
            'name' => $r->name
        ]);

        alert::admin(true,'ثبت شد');
        return redirect()->back();
    }

    public function delete(Tag $tag){

        $tag->delete();
        alert::admin(true,'حذف شد');;
        return redirect()->back();
    }

    public function modify(Request $r){

        if (validate::admin([$r->id ,$r->name]))
            return redirect()->back() ;

        Tag::findOrFail($r->id)->update([
            'name' => $r->name
        ]);

        alert::admin(true,'ویرایش شد');;
        return redirect()->back();
    }


    public function products(Request $r ,Product $product){

        $inputs = $r->all();

        foreach ($inputs as $input){
            $tag = Tag::find($input);
            if ($tag)
                ProductTag::updateOrCreate([
                    'product_id' => $product->id ,
                    'tag_id' => $tag->id ,
                ]);
        }


        alert::admin(true,'ثبت شد');;
        return redirect()->back();
    }

}
