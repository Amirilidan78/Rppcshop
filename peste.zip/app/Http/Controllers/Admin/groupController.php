<?php

namespace App\Http\Controllers\Admin;

use App\functions\view\alert;
use App\functions\view\validate;
use App\Http\Controllers\Controller;
use App\ProductGroup;
use Illuminate\Http\Request;

class groupController extends Controller
{

    public function store(Request $request){

        if (validate::admin([$request->name]))
            return redirect()->back();

        ProductGroup::create([
            'name' => $request->name
        ]);

        alert::admin(true,'ثبت شد');
        return redirect()->back();
    }

    public function update(Request $request){

        $group = ProductGroup::find($request->id) ;

        $group->update([
            'name' => $request->name
        ]);

        alert::admin(true,'ثبت شد');
        return redirect()->back();
    }

    public function destroy($id){

        $group = ProductGroup::find($id) ;
        $group->delete();
        alert::admin(true,'حذف شد');
        return redirect()->back();
    }
}
