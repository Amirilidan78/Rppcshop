<?php

namespace App\Http\Controllers\Admin;

use App\functions\session\AdminSession;
use App\functions\view\alert;
use App\Jobs\smsAdminTransactionOfflinePayed;
use App\Jobs\smsUserTransactionOfflinePayed;
use App\Jobs\user\smsUserOrderToPost;
use App\Order;
use App\OrderFactor;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;

class orderController extends Controller
{
    public function __construct (){
        $this->middleware('adminPermissionOrders');
    }

    public function index(){

        return view('admin.orders.index',[
            'ordersStatus1' => Order::where('status', 0)->get() ,
            'ordersStatus2' => Order::where('status', 1)->get() ,
            'ordersStatus3' => Order::where('status', 2)->get() ,
            'ordersStatus4' => Order::where('status', 3)->get() ,
            'ordersStatus5' => Order::where('status', 4)->get() ,
            'ordersStatus6' => Order::where('status', 5)->get() ,
        ]) ;
    }

    public function show(Order $order){

        return view('admin.orders.show',[
            'order' => $order ,
            'user' => $order->user ,
            'products' => $order->products ,
            'factor' => $order->factor ,
            'post' => $order->post ,
        ]) ;
    }

    public function delete(Order $order){

        $admin = AdminSession::get();

        $order->delete();

        Log::warning("admin: {$admin} , deleted order id:{$order->id} - user-phone:{$order->user_phone} , atStatus:{$order->status} , totalPrice:{$order->total_price}");

        alert::admin(true,'سفارش حذف شد');
        return redirect()->back();
    }

    public function changeStatus(Order $order , $status){

        $admin = AdminSession::get();

        $order->update([
            'status' => $status
        ]);

        if ($status == 1){
            \App\Jobs\user\smsUserTransactionOfflinePayed::dispatch($order->user_phone ,$order->getOrderId());
            \App\Jobs\admin\smsAdminTransactionOfflinePayed::dispatch($order->getOrderId());
            OrderFactor::create([
                'ref_id' => " تایید شده توسط {$admin} " ,
                'order_id' => $order->id ,
            ]);
        }

        Log::warning("admin: {$admin} , status1 order id:{$order->id} - user-phone:{$order->user_phone}  - newOrderStatus : {$status}, totalPrice:{$order->total_price}");

        alert::admin(true,'سفارش به روز شد');
        return redirect()->back();
    }

    public function changeStatusToPost(Order $order , $code){

        $admin = AdminSession::get();

        $order->update([
            'status' => 4 ,
            'post_rahgiri' => $code ,
        ]);

        smsUserOrderToPost::dispatch($order->user_phone ,$order->getOrderId() , $code);
        Log::warning("admin: {$admin} ,  order-id:{$order->id} - user-phone:{$order->user_phone}  - newOrderStatus : 4, totalPrice:{$order->total_price} , code-rahgiri-post:{$code}");

        alert::admin(true,'سفارش به روز شد');
        return redirect()->back();
    }


}
