<?php

namespace App\Http\Controllers\Admin;

use App\functions\view\alert;
use App\functions\view\validate;
use App\User;
use App\UserPassword;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\UsersExport;

class userController extends Controller
{

    public function __construct (){
        $this->middleware('adminPermissionUsers');
    }

    public function index(){

        return view('admin.users.index' ,[
            'all' => User::all() ,
        ]) ;
    }

    public function excel(){

        return Excel::download(new UsersExport, 'users.xlsx') ;
    }

    public function store(Request $r){

        $name = $r->name ;
        $last_name = $r->last_name ;
        $phone = $r->phone ;
        $code_melli = $r->code_melli ;
        $password = $r->password ;

        validate::admin([$name ,$last_name ,$phone ,$code_melli ,$password ]);

        if (strlen($password) < 8 ){
            alert::admin(false,'رمز عبور باید بیشتر از 8 حرف باشد');
            return redirect()->back();
        }

        if (User::where('phone',$phone)->count() > 0){
            alert::admin(false,'کاربر با این شماره همراه ثبت شده است');
            return redirect()->back();
        }

        User::create([
            'name' => $name ,
            'last_name' => $last_name ,
            'phone' => $phone ,
            'email' => $code_melli ,
        ]);

        UserPassword::create([
            'phone' => $phone ,
            'password' => md5($password) ,
        ]);

        alert::admin(true,'کاربر ثبت شد');
        return redirect()->back();
    }

    public function modify(Request $r){

        $name = $r->name ;
        $last_name = $r->last_name ;
        $phone = $r->phone ;
        $code_melli = $r->code_melli ;

        validate::admin([$name ,$last_name ,$phone ,$code_melli ]);

        if (User::where('phone',$phone)->count() == 0){
            alert::admin(false,'کاربر با این شماره همراه ثبت نشده است');
            return redirect()->back();
        }

        User::findWithPhone($phone)->update([
            'name' => $name ,
            'last_name' => $last_name ,
            'phone' => $phone ,
            'email' => $code_melli ,
        ]);

        alert::admin(true,'کاربر ویرایش شد');
        return redirect()->back();
    }

    public function search(Request $r){

        $phone = $r->phone ;

        if ( !$phone  )
            return '-1' ;

        if ( User::where('phone',$phone)->count() == 0 )
            return '-2';

        $user = User::findWithPhone($phone);

        return $user ;
    }

    public function delete(User $user){

        $user->delete() ;
        $user->password()->delete();
        alert::admin(true,'حذف شد');;
         return redirect()->back();
    }
}
