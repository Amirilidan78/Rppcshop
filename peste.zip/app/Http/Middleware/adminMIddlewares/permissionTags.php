<?php

namespace App\Http\Middleware\adminMIddlewares;

use Closure;

class permissionTags
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $access = session("adminPermissions")['tags'] ;
        if($access == 1)
            return $next($request);
        else
            return redirect('/notAllow');
    }
}
