<?php

namespace App\Http\Middleware\adminMIddlewares;

use Closure;

class permissionProducts
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $access = session("adminPermissions")['products'] ;
        if($access == 1)
            return $next($request);
        else
            return redirect('/notAllow');
    }
}
