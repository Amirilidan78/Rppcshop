<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductAttrib extends Model
{
    protected $guarded = [] ;
    protected $table = 'products_attribs';
}
