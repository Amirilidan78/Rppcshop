<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminPassword extends Model
{
    protected $guarded = [] ;
    protected $table = 'admins_password' ;
}
