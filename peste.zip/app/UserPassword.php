<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPassword extends Model
{
    protected $guarded = [] ;
    protected $table = 'users_password' ;
}
