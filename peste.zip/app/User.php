<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $guarded = [] ;
    protected $table = 'users' ;

    public function password(){

        return $this->hasOne('App\UserPassword','phone','phone');
    }

    public function personals(){

        return $this->hasMany('App\UserPersonal','phone','phone');
    }

    public function orders(){

        return $this->hasMany('App\Order','user_phone','phone');
    }

    public function scopeFindWithPhone($query, $phone){
        return $query->where('phone', $phone)->first();
    }

}
